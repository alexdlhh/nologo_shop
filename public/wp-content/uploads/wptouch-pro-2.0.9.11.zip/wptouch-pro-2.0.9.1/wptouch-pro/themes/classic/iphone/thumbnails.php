<!-- Code for Using Thumbnails  -->
<div class="thumbnail-wrap">
	<img src="<?php wptouch_the_post_thumbnail(); ?>" class="attachment-post-thumbnail default-thumbnail" alt="post thumbnail" />	
</div>