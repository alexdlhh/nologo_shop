<div class="wptouch-section section-<?php wptouch_the_tab_setting_class_name(); ?>">
	<fieldset class="round-6">
		<legend class="round-4"><?php wptouch_the_tab_setting_desc(); ?></legend>
		
		<div class="wptouch-section-settings">