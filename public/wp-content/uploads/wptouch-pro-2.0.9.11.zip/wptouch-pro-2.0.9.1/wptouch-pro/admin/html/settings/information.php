<div class="<?php wptouch_the_theme_classes( "wptouch-theme-box round-8" ); ?>">
<h5>WPtouch 2.0 Pro</h5>
</div>