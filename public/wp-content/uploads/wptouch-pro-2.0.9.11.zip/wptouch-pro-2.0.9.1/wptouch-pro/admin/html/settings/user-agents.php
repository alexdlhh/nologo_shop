<table>
	<tr>
		<th><?php _e( "Device Classes", "wptouch-pro" ); ?></th>
		<th><?php _e( "User Agents", "wptouch-pro" ); ?></th>
	</tr>
		<tr>
			<td class="device-class-name"><?php _e( "iOS / Webkit", "wptouch-pro" ); ?></td>
			<td><?php _e( "iphone, ipod, aspen, incognito, webmate", "wptouch-pro" ); ?></td>
		</tr>
		<tr>
			<td class="device-class-name"><?php _e( "Android", "wptouch-pro" ); ?></td>
			<td><?php _e( "android, dream, cupcake, froyo", "wptouch-pro" ); ?></td>
		</tr>
		<tr>
			<td class="device-class-name"><?php _e( "Blackberry Storm/Torch", "wptouch-pro" ); ?></td>
			<td><?php _e( "blackberry9500, blackberry9520, blackberry9530, blackberry9550, blackberry9800", "wptouch-pro" ); ?></td>
		</tr>
		<tr>
			<td class="device-class-name"><?php _e( "Palm", "wptouch-pro" ); ?></td>
			<td><?php _e( "webos", "wptouch-pro" ); ?></td>
		</tr>
		<tr>
			<td class="device-class-name"><?php _e( "Samsung", "wptouch-pro" ); ?></td>
			<td><?php _e( "s8000, bada", "wptouch-pro" ); ?></td>
		</tr>
</table>