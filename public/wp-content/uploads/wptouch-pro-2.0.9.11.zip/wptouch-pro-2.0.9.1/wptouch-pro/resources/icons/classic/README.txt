* DO NOT REMOVE ANY INFORMATION WITHOUT AUTHOR'S PERMISSION

// Aquaticus Theme for iPhone or iPod Touch

Version: 1.0
Requirements: iPhone or iPod Touch Jailbreaked (Google is your friend)
Content in this release: 20 icons + Wallpaper + Dock
Extra icons: http://macthemes2.net/forum/viewtopic.php?id=16787254 [MacThemes]

// Contact

Marfil
marcelomarfil(at)me.com

Release v1 (07/22/08)

2008 Copyright Marcelo Marfil