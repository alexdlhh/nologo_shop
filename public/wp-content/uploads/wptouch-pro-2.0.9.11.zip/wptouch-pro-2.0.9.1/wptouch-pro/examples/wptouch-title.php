<head>
	<title><?php wptouch_title(); ?></title>
