<script type="text/javascript"><!--
window.googleAfmcRequest = {
  client: 'ca-mb-pub-9313067317467709',
  ad_type: 'text_image',
  output: 'html',
  channel: '9398242138',
  format: '320x50_mb',
  oe: 'utf8',
  color_border: '336699',
  color_bg: 'FFFFFF',
  color_link: '0000FF',
  color_text: '000000',
  color_url: '008000'
};
//--></script>
<script type="text/javascript" src="http://pagead2.googlesyndication.com/pagead/show_afmc_ads.js"></script>