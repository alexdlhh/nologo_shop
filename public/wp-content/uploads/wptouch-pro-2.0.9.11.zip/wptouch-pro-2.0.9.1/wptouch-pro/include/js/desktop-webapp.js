	if ( window.navigator.standalone ) {
		document.cookie = 'wptouch-pro-view=mobile; expires=Tue, 1 Jan 2013 20:00:00 UTC; path=/';
		window.location.href = window.location.href;
	}