
	$(document).ready(function()
	{
		var image_types = $(".image_types li a");
		
		image_types.each(function()
		{
			var $this = $(this);
			
			$this.click(function(ev)
			{
				ev.preventDefault();
				
				$(".image_types li").removeClass("active");
				$this.parent().addClass("active");
				
				var image_source = $this.attr("data-imagesrc");
				$(".view_image img").fadeTo(250, 0);
				
				var load_image = new Image();
				load_image.src = image_source;
				load_image.onload = function()
				{
					var w = this.width;
					
					w = w > 800 ? 800 : w;
					
					$(".view_image img").stop().fadeTo(250, 1).attr("src", image_source).attr("width", w);
					$(".view_image #name").css("width", (w-25) + "px");
					
					var pww = $(parent.window).width();
			    	var pwh = $(parent.window).height();
			    	   	
			    	var body_height = $("body").height() + 45;
			    	var frame = $(parent.document).find('#image_frame');
			    	
			    	frame.height(body_height + 20);
			    	
			    	var fw = w + 100;
			    	fw = fw < 450 ? 450: fw;
			    	frame.width(fw);
			    	
			    	var frame_width = frame.width();
			    	var frame_height = frame.height();
			    	    	
			    	var frame_top = parseInt(pwh/2 - frame_height/2) + $(parent.window).scrollTop();
			    	var frame_left = parseInt(pww/2 - frame_width/2);
			    	
			    	frame_top = frame_top < 0 ? 0 : frame_top;
			    	frame_left = frame_left < 0 ? 0 : frame_left;
			    	
			    	frame.css({top: frame_top, left: frame_left});
				}
			});
		});
	});