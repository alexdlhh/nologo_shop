<h1>Front-end Themes</h1>
<?php
		$fe_url = MBURL;
		$fe_path = MBPATH;
	
		$themes_dir =  MBPATH . "/themes/*";
		$browse_themes = glob($themes_dir);
		
		$themes_arr = array();
		
		foreach($browse_themes as $theme_path)
		{
			$theme_name = basename($theme_path);
			$theme_screenshot = null;
			
			if( file_exists($theme_path . "/screenshot.png") )
			{
				$theme_screenshot = $fe_url . "/themes/" . $theme_name . "/screenshot.png";
			}
			
			array_push($themes_arr, array("name" => $theme_name, "screenshot" => $theme_screenshot, "path" => $theme_path . "/"));
		}
		
		if( !file_exists(MBPATH."/themes/".get_option('mbg_current_theme')."/") )
		{
			update_option('mbg_current_theme', "");
		}
		
		?>
		<script type="text/javascript">
			$(document).ready(function()
			{
				$(".confirm_installation").click(function()
				{
					if( !confirm("Are you sure you want to install this theme?\n\nNote: All album thumbnails will be re-created and this may take some time during the process!") )
						return false;
				});
				
				$(".confirm_disabling").click(function()
				{
					if( !confirm("Are you sure you want to disable this theme?") )
						return false;
				});
			});
		</script>
		<h3>Set your preferred theme</h3>
		<?php
			if( count($themes_arr) )
			{
				$total_images = totalImages();
				$fe_config = $fe_path . "/config.php";
				
				if( file_exists($fe_config) )
					include($fe_config);
		?>
		<table cellpadding="0" cellspacing="0" border="0" width="100%">
		<?php
				foreach($themes_arr as $theme)
				{
					$theme_constraints = "No constraints defined!";
					
					if( file_exists($theme['path'] . "constraints.php") )
					{
						include($theme['path'] . "constraints.php");
						
						if( $THEME_THUMBNAIL1_SIZE || $THEME_THUMBNAIL2_SIZE || $THEME_THUMBNAIL3_SIZE )
						{
							$theme_constraints = "";
							
							if( $THEME_THUMBNAIL1_SIZE != null )
							{
								$thumbnail_size = explode("x", $THEME_THUMBNAIL1_SIZE);
								
								$thumb_width = $thumbnail_size[0];
								$thumb_height = $thumbnail_size[1];
								$thumb_fit_canvas = $thumbnail_size[2];
								
								if( $thumb_width && $thumb_height )
								{
									$size_1_details = "{$thumb_width}x{$thumb_height}";
									
									if( $thumb_fit_canvas )
										$size_1_details .= " fitted";
								}
								else
								if( $thumb_width )
								{
									$size_1_details = "{$thumb_width} pixels width";
								}
								else
								if( $thumb_height )
								{
									$size_1_details = "{$thumb_height} pixels height";
								}
								
								$theme_constraints .= "Thumbnail 1 ($size_1_details), ";
							}
								
							if( $THEME_THUMBNAIL2_SIZE != null )
							{
								$thumbnail_size = explode("x", $THEME_THUMBNAIL2_SIZE);
								
								$thumb_width = $thumbnail_size[0];
								$thumb_height = $thumbnail_size[1];
								$thumb_fit_canvas = $thumbnail_size[2];
								
								if( $thumb_width && $thumb_height )
								{
									$size_2_details = "{$thumb_width}x{$thumb_height}";
									
									if( $thumb_fit_canvas )
										$size_2_details .= " fitted";
								}
								else
								if( $thumb_width )
								{
									$size_2_details = "{$thumb_width} pixels width";
								}
								else
								if( $thumb_height )
								{
									$size_2_details = "{$thumb_height} pixels height";
								}
								
								$theme_constraints .= "Thumbnail 2 ($size_2_details), ";
							}
								
							if( $THEME_THUMBNAIL3_SIZE != null )
							{
								$thumbnail_size = explode("x", $THEME_THUMBNAIL3_SIZE);
								
								$thumb_width = $thumbnail_size[0];
								$thumb_height = $thumbnail_size[1];
								$thumb_fit_canvas = $thumbnail_size[2];
								
								if( $thumb_width && $thumb_height )
								{
									$size_3_details = "{$thumb_width}x{$thumb_height}";
									
									if( $thumb_fit_canvas )
										$size_3_details .= " fitted";
								}
								else
								if( $thumb_width )
								{
									$size_3_details = "{$thumb_width} pixels width";
								}
								else
								if( $thumb_height )
								{
									$size_3_details = "{$thumb_height} pixels height";
								}
								
								$theme_constraints .= "Thumbnail 3 ($size_3_details), ";
							}
							
							$theme_constraints = substr($theme_constraints, 0, -2);
						}
					}
			?>
			<tr class="radius<?php echo $theme['name'] == get_option('mbg_current_theme') ? ' installed_theme' : ''; ?>">
				<?php if( $theme['screenshot'] ){ ?>	
				<td class="theme_install bottompad toppadd leftpadd" width="180">
					<img src="<?php echo $theme['screenshot']; ?>" alt="theme-screenshot" width="180" height="134" align="left" />
				</td>
				<?php } ?>
				
				<td class="theme_install bottompad toppadd" valign="top">
					<div class="theme_entry">
						<div>Theme name:</div>
						<h1><?php echo $theme['name']; ?></h1>
						
						<div>Theme constraints:</div>
						<div class="constraints"><?php echo $theme_constraints; ?></div>
						
						<br />
						<?php if( $theme['name'] == get_option('mbg_current_theme') ){ ?>
						<span class="current_theme">SELECTED</span>
						<?php } else { ?>
						<form method="post" name="theme-settings-select-theme" action="">
							<input type="hidden" name="theme_name" value="<?php echo $theme['name']; ?>" />
							<input type="submit" name="set_theme" value="SET THIS THEME" class="button install<?php echo $total_images > 10 ? ' confirm_installation' : ''; ?>" />
						</form>
					</div>
					<?php } ?>
				</td>
			</tr>
		<?php
				}
		?>
		</table>
		
		
		<br />
		<div class="warning">
			Warning: You are not recommended to change default thumbnail sizes set from theme in use, in order to get album parser wokrs correctly - respectively [mbg] shortcode!
		</div>
		<?php
			}
			else
			{
				?>
				<div class="error_mbg">There are no themes available to install! Please insert themes in the themes/ directory on front-end framework.</div>
				<?php
			}
?>