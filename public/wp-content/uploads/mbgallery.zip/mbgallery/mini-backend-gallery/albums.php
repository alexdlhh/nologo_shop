<?php
	$q = mysql_query("SELECT *, (SELECT COUNT(*) FROM `".dbprefix()."images` WHERE `AlbumID` = t1.AlbumID) total_images FROM `".dbprefix()."albums` t1 ORDER BY `OrderID` ASC");
?>
<h1>Manage Albums <span class="create_new_album">(<a href="?page=create-new-album">Create New Album</a>)</span></h1>
<script type="text/javascript" src="<?php echo MBGURL; ?>/js/albums.js"></script>
<table class="data_table" width="100%" border="0" cellspacing="0" cellpadding="0">
 <thead>
  <tr>
    <th width="38" align="left">Cover</th>
    <th width="240" align="left">Album Name</th>
    <th width="140" align="left">Date Created</th>
    <th width="80" align="left">Images</th>
    <th align="left">Options</th>
  </tr>
 </thead>
 
 <tbody>
 <?php
 while($r = mysql_fetch_array($q))
 {
	 $id = $r['AlbumID'];
	 $name = $r['AlbumName'];
	 $description = $r['Description'];
	 
	 $date_c = date("M d, Y", $r['DateCreated']);
	 $total_images = $r['total_images'];
	 
	 $album_cover_img = MBGURL . "/css/images/album_cover.png";
	 if( $r['AlbumCover'] )
	 {
	 	$album_cover = getImage($r['AlbumCover']);
	 	$album_cover_img = MBGURL . "/" . $album_cover['DefaultThumbnail'];
	 }
	 
	 if( $description )
	 {
	 	$name .= '<p class="description">' .$description . '</p>';
	 }
 ?>
  <tr class="album_entry" data-albumid="<?php echo $id; ?>">
  	<td width="38">
		<a href="admin.php?page=<?php echo $_GET['page']; ?>&view_album=<?php echo $id; ?>" class="image_cover radius" title="Go to this album" style="padding:2px">
			<img src="<?php echo $album_cover_img; ?>" alt="album_cover" width="30" />
		</a>
  	</td>
    <td width="240"><a href="admin.php?page=<?php echo $_GET['page']; ?>&view_album=<?php echo $id; ?>"><?php echo $name; ?></a></td>
    <td width="140" class="gray"><?php echo $date_c; ?></td>
    <td width="80"><?php echo $total_images; ?></td>
    <td><a href="admin.php?page=<?php echo $_GET['page']; ?>&view_album=<?php echo $id; ?>" class="manage">Manage Images</a> <a href="?page=mini-backend-gallery&deletealbum=<?php echo $id; ?>" class="delete">Delete Album</a> <a href="?page=mini-backend-gallery&moveup=<?php echo $id; ?>" class="up">Up</a> <a href="?page=mini-backend-gallery&movedown=<?php echo $id; ?>" class="down">Down</a></td>
  </tr>
 <?php
 }
 
 if( !mysql_num_rows($q) )
 {
	 ?>
     <tr>
      <td colspan="5">There is no any album created. <a href="admin.php?page=create-new-album">Click here to create new album &raquo;</a></td>
     </tr>
     <?php
 }
 ?>
 </tbody>
</table>

<div class="loader">Loading...</div>