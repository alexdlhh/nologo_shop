<?php

	/**
	 * Mini Back-end Gallery
	 *
	 * Created by: Arlind Nushi
	 * Email: arlindd@gmail.com
	 */
	
	define("MBG_CONFIG_FILE", 1);
	 
	$db_host = DB_HOST;
	$db_user = DB_USER;
	$db_pass = DB_PASSWORD;
	$db_name = DB_NAME;
		
	// Naming convention
	$naming = get_option('mbg_naming');
	
	// Default Thumbnails (set empty if you don't want to create thumbnail)
	$thumbnail_1_size = get_option('mbg_thumbnail1_size');
	$thumbnail_2_size = get_option('mbg_thumbnail2_size');
	$thumbnail_3_size = get_option('mbg_thumbnail3_size');
	
	// Images upload path
	$images_path = "uploads/";
	
	/* Front-end Themes Framework Settings */
	$fe_installed = get_option("fe_installed");
	$fe_theme_selected = get_option("fe_theme_selected");
	$fe_url = get_option("fe_url");
	$fe_path = get_option("fe_path");
	$current_theme = get_option("current_theme");
	/* End of Front-end Theme Settings */
?>