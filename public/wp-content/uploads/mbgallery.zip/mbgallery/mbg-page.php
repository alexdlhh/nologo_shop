<link type="text/css" rel="stylesheet" href="<?php echo MBURL; ?>/css/mbg.css" />
<script type="text/javascript">
	jQuery(document).ready(function()
	{
		jQuery(".mbg_return_home").click(function(ev)
		{
			ev.preventDefault();
			
			window.location.href = "admin.php?page=mini-backend-gallery";
		});
	});
</script>

<div class="wrap">
	<div class="icon32 mbg_icon"></div>
	<h2 class="mbg_return_home">Mini Back-end Gallery</h2>
	<div class="spacer"></div>
	
	<div class="mbg_env">
		<ul class="mbg_top_menu">
			<li<?php echo $_GET['page'] == "mini-backend-gallery" ? ' class="active"' : ''; ?>><a href="admin.php?page=mini-backend-gallery"><img src="<?php echo MBURL; ?>/images/home.png" alt="home" width="16" height="16" /></a></li>
			<li<?php echo $_GET['page'] == "create-new-album" ? ' class="active"' : ''; ?>><a href="admin.php?page=create-new-album">Create New Album</a></li>
			<li<?php echo $_GET['page'] == "mbg-settings" ? ' class="active"' : ''; ?>><a href="admin.php?page=mbg-settings">Settings</a></li>
			<li<?php echo $_GET['page'] == "mbg-themes" ? ' class="active"' : ''; ?>><a href="admin.php?page=mbg-themes">Themes</a></li>
		</ul>
		<?php include(MBPATH."/mini-backend-gallery/admin.php"); ?>
	</div>
	
	<div class="clear"></div>
	<br />
	<div class="spacer"></div>
</div>