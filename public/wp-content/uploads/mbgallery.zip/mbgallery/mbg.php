<?php
/*
Plugin Name: Mini Back-end Gallery v2
Description: It's a WordPress based gallery plugin, which adds custom functionality to your site when it comes to managing and parsing images. It is very easy to manage, create and edit your albums and images. By just adding simple short-codes to your articles (posts or pages) you can show album sets and images. As special feature of this plugin are themes which they improve the way of showing your album images.
Version: 1.0
Plugin URI: http://arlindnushi.dervina.com/mbg-v2/
Author: Arlind Nushi
*/
	
	// Grant Access for Mini Back-end Gallery Functions/Requests
	define('WP_PLUGIN_ACCESS', 1);
	
	
	// Check if Mini-Backend Gallery is installed
	if( get_option('mbg_is_installed') != 1 )
	{
		include_once("mbg-install.php");
	}
	
	define("MBPATH", dirname(__FILE__));
	define("MBURL", plugins_url() . "/mbgallery");	
	
	function mbg_init()
	{
		global $submenu;
		
		// Create Menu Page
		add_menu_page(__('Mini Back-end Gallery'), __('MB Gallery'), 1, 'mini-backend-gallery', 'mbg_manage_albums_page', MBURL.'/images/mbg-icon.png');	
		
		// Sub pages
		add_submenu_page('mini-backend-gallery', 'Create New Album', 'Create New Album', 1, 'create-new-album', 'mbg_new_album_page');
		
		add_submenu_page('mini-backend-gallery', __('Settings'), __('Settings'), 1, 'mbg-settings', 'mbg_settings_page');
		add_submenu_page('mini-backend-gallery', __('Themes'), __('Themes'), 1, 'mbg-themes', 'mbg_themes_page');
		
		
		foreach($submenu as &$item)
		{
			if( $item[0][0] == __('MB Gallery') )
			{
				$item[0][0] = __('Manage Albums');
			}
		}
		
	}

	add_action('admin_menu', 'mbg_init');
	
	// Manage Albums Page
	function mbg_manage_albums_page()
	{
		mbg_call();
	}
	
	// Create New Albums Page
	function mbg_new_album_page()
	{
		mbg_call();
	}
	
	// Settings Page
	function mbg_settings_page()
	{
		mbg_call();
	}
	
	// Themes Page
	function mbg_themes_page()
	{
		mbg_call();
	}
	
	// Call Main Page
	function mbg_call()
	{
		global $menu;
		
		include("mbg-page.php");
	}
	
	// Get database prefix
	function dbprefix()
	{
		global $wpdb;
		return $wpdb->prefix . "mbg_";
	}
	
	/* Add Shortcodes from Themes */	
	$mbg_current_theme = get_option("mbg_current_theme");
	$theme_shortcodes_file = MBPATH."/themes/".$mbg_current_theme."/shortcodes.php";
	
	if( file_exists($theme_shortcodes_file) )
	{
		include_once($theme_shortcodes_file);
	}
	else
	{
		// Set Default Theme
		$themes_glob = glob(MBPATH."/themes/*");
		$theme_name = basename(reset($themes_glob));
		
		$load_constraints_file = MBPATH . "/themes/" . $theme_name . "/constraints.php";
		
		if( file_exists($load_constraints_file) )
		{
			include_once($load_constraints_file);
			
			if( isset($THEME_THUMBNAIL1_SIZE) )
				update_option("mbg_thumbnail1_size", $THEME_THUMBNAIL1_SIZE);
			
			if( isset($THEME_THUMBNAIL2_SIZE) )
				update_option("mbg_thumbnail2_size", $THEME_THUMBNAIL2_SIZE);
			
			if( isset($THEME_THUMBNAIL3_SIZE) )
				update_option("mbg_thumbnail3_size", $THEME_THUMBNAIL3_SIZE);
		}
		
		update_option("mbg_current_theme", $theme_name);
	}
?>