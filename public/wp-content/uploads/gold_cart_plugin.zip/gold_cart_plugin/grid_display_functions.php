<?php
// Version: 1.4
// Date: 25/6/2009
function product_display_grid($product_list, $group_type, $group_sql = '', $search_sql = '') {
  global $wpdb;
  /*
  All this does is sit here so that it can be detected by the gold files to turn grid view on.
  */  
  }  
?>
