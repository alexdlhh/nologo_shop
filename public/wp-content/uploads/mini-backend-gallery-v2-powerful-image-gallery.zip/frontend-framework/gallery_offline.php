<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link type="text/css" rel="stylesheet" href="css/main.css" />
</head>
<body>
	<div class="wrapper">
		<!-- Your logo here -->
		<a href="./">
			<img src="images/mbg-logo.png" alt="mbg-logo" width="453" height="31" />
		</a>
		
		<div class="content">
			<h1>You must configure front-end themes framework from gallery admin panel!</h1>
		</div>
		
		<div class="copyright">
			<img src="images/mbg-copyright.png" alt="mbg-copyright" width="265" height="12" /> Mini-backend Gallery v2 created by Arlind Nushi
		</div>
	</div>
</body>
</html>