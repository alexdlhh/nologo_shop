<?php

	/**
	 * Front-end Theme
	 *
	 * Mini Back-end Gallery
	 *
	 * Created by: Arlind Nushi
	 * Email: arlindd@gmail.com
	 */

	// Direct url to Mini Back-end Gallery
	$mini_backend_gallery_url = "";
	
	// Path to Mini Back-end Gallery
	$mini_backend_gallery_path = "";
	
	// Theme to use
	$current_theme = "";
?>