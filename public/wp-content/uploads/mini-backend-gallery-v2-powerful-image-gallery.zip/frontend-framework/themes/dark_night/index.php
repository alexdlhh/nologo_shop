<?php
	$albums = getAllAlbums();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $title; ?></title>

<link type="text/css" rel="stylesheet" href="css/main.css" />
<script type="text/javascript" src="js/jquery-1.5.2.min.js"></script>
<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>

<link type="text/css" rel="stylesheet" href="themes/dark_night/css/theme-1.css" />
<script type="text/javascript" src="themes/dark_night/js/jquery.center.js"></script>
<script type="text/javascript" src="themes/dark_night/js/jquery.expander.js"></script>
<script type="text/javascript" src="themes/dark_night/js/mbg-frontend-theme1.js"></script>

</head>
<body>
	<div class="wrapper">
		<!-- Your logo here -->
		<a href="./">
			<img src="images/mbg-logo.png" alt="mbg-logo" width="447" height="31" />
		</a>
		
		<div class="content">
			<?php
				if( count($albums) )
				{
					?>
					<ul class="albums">
					<?php
						foreach($albums as $album)
						{
							$album_id = $album['AlbumID'];
							$album_name = $album['AlbumName'];
							$album_cover = $album['AlbumCover'];
							
							$album_cover_img = "themes/dark_night/images/album-cover.png";
							
							if( $album_cover )
							{
								$album_cover_img = $mini_backend_gallery_url . $album_cover['Thumbnail1'];
							}
							
							$images_count = countAlbumImages($album_id);
					?>
						<li data-id="<?php echo $album_id; ?>">
							<div class="album_container">
								<a href="#" class="album_cover">
									<img src="<?php echo $album_cover_img; ?>" width="215" height="145" alt="" />
								</a>
								
								<a href="#" class="album_name"><?php echo $album_name; ?></a>
								<span class="album_details"><?php echo $images_count; ?> photo<?php echo $images_count != 1 ? 's' : ''; ?></span>
								
								<div class="clear"></div>
							</div>
						</li>
					<?php
						}
					?>
					</ul>
					
					<div class="clear"></div>
					<?php
				}
				else
				{
					?>
					<h1>There is no any album!</h1>
					<?php
				}
			?>
			<div class="loader"></div>
		</div>
		
		<div class="copyright">
			<img src="images/mbg-copyright.png" alt="mbg-copyright" width="265" height="12" /> Mini-backend Gallery v2 created by Arlind Nushi
		</div>
	</div>
</body>
</html>