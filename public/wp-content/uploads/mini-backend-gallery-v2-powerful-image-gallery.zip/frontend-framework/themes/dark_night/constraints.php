<?php

	/* Settings to be re-written on album thumbnail sizes */
	$THEME_THUMBNAIL1_SIZE = "215x146x1";
	$THEME_THUMBNAIL2_SIZE = "1280x960x";
	$THEME_THUMBNAIL3_SIZE = null;
?>