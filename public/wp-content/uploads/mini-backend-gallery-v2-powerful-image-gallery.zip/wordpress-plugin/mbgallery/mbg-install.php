<?php
	
	$create_albums_table = "CREATE TABLE `".dbprefix()."albums` ( `AlbumID` int(11) unsigned NOT NULL AUTO_INCREMENT, `AlbumName` varchar(255) NOT NULL, `Description` text NOT NULL, `DateCreated` int(20) NOT NULL, `Thumbnail1Size` varchar(10) DEFAULT NULL, `Thumbnail2Size` varchar(10) DEFAULT NULL, `Thumbnail3Size` varchar(10) DEFAULT NULL, `OrderID` int(11) NOT NULL DEFAULT '1', `AlbumCover` int(11) unsigned DEFAULT NULL, PRIMARY KEY (`AlbumID`), KEY `AlbumCover` (`AlbumCover`)) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1";	
	$create_images_table = "CREATE TABLE `".dbprefix()."images` (`ImageID` int(11) unsigned NOT NULL AUTO_INCREMENT, `AlbumID` int(11) unsigned NOT NULL, `ImagePath` varchar(255) NOT NULL, `Name` varchar(255) NOT NULL, `UploadDate` int(20) NOT NULL, `OrderID` int(20) NOT NULL, PRIMARY KEY (`ImageID`), KEY `AlbumID` (`AlbumID`)) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1";
	
	$album_cover_constraint = "ALTER TABLE `".dbprefix()."albums` ADD CONSTRAINT `".dbprefix()."albums_ibfk_1` FOREIGN KEY (`AlbumCover`) REFERENCES `".dbprefix()."images` (`ImageID`)";
	$album_images_constraint = "ALTER TABLE `".dbprefix()."images` ADD CONSTRAINT `".dbprefix()."images_ibfk_1` FOREIGN KEY (`AlbumID`) REFERENCES `".dbprefix()."albums` (`AlbumID`)";
	
	@mysql_query($create_albums_table);
	@mysql_query($create_images_table);
	@mysql_query($album_cover_constraint);
	@mysql_query($album_images_constraint);
	
	update_option("mbg_is_installed", 1);
?>