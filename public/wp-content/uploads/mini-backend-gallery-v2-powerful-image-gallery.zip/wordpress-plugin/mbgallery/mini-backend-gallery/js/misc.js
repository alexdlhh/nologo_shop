
	$(document).ready(function()
	{
		$('.data_table .delete').click(function()
		{
			if( !confirm('Are you sure you want to delete this album?') )
				return false;
		});
		
		$(".tooltip").tipsy({fade: true, gravity: "w", offset: 100}).click(function(ev)
		{
			ev.preventDefault();
		});
		
		$(".api_frame").fancybox({
			autoDimensions: false, 
			width: parseInt($(window).width() * 0.9), 
			height: parseInt($(window).height() * 0.9), 
			type: 'iframe'
		});
	});
	
	
	function showLoader(message)
	{
		$(".loader").show().html(message);
	}
	
	function hideLoader()
	{
		$(".loader").hide();
	}