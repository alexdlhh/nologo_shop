
	$(document).ready(function()
	{
		var image_cover = $(".image_cover");
		
		image_cover.click(function(ev)
		{
			ev.preventDefault();
			
			var album_id = $("#album_id").val();
			
			openFrame( mbg_plugin_url + "/admin.php?mbg_intern=1&page=albumcover&album_id=" + album_id + "&nox");
		});
	});