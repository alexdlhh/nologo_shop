
	$(document).ready(function()
	{
		var album_id = $("#album_id").val();
		
		$("#upload_image").uploadify(
		{
			'uploader': mbg_plugin_url + '/js/jquery.uploadify-v2.1.4/uploadify.swf',
    		'cancelImg' : mbg_plugin_url + '/js/jquery.uploadify-v2.1.4/cancel.png',
			'auto':true,
			'wmode':'transparent',
			'buttonText': 'Upload Images',
			'multi': true,
			'scriptData' : {"mbg_intern":"1", "album_id":album_id},
			'script': mbg_plugin_url + '/admin.php',
			'fileDataName': 'upload_image',
			'onError': function(event, ID, fileObj, errorOjb)
			{
			},
			'onComplete'  : function(event, ID, fileObj, response, data)
			{
				eval("response = eval("+response+")");
				if( response.errors )
				{
					alert("An error occured and image cannot be uploaded!\n\nError Code: [" + response.errors+ "]" );
				}
				else
				{
					
					var crop_url = mbg_plugin_url + '/admin.php?mbg_intern=1&page=cropimage&id='+response.ImageID+"&nox";
			
					var new_image_element = '<li class="images radius" data-imageid="'+response.ImageID+'">';
					new_image_element += '<img src="'+mbg_plugin_url+"/"+response.thumbnailUrl+'" width="110" height="95" alt="" />';
					new_image_element += '<div class="clear"></div>';
                    new_image_element += '<a href="#" class="edit_img">Edit</a>';
                    new_image_element += '<a href="#" class="delete_img">Delete</a>';
                    new_image_element += '<div class="check_button">';
                    new_image_element += '<input type="checkbox" name="selected_images[]" class="image_checkbox" id="image_id_'+response.ImageID+'" value="'+response.ImageID+'" />';
                    new_image_element += '<a href="'+crop_url+'" target="_blank" class="crop_image">Crop</a>';
                    new_image_element += '</div>';
					new_image_element += '</li>';
					
					var image_element = $(new_image_element).appendTo(".album_images");
					image_element.click(image_check_function);
					image_element.hide().show("puff");
					deleteImgEvent( image_element.children('.delete_img') );
					editImgEvent( image_element.children('.edit_img') );
					cropImgEvent( image_element.find('.crop_image') );
					
					addSortableEvent();
					
					var number = Number( $(".images_uploaded_num").html() );
					
					$(".select_unselect_all_items").show();
					
					if( number + 1 == 1 )
						$(".plural").text("");
					else
						$(".plural").text("s");
					
					$(".images_uploaded_num").html( number+1 );
					
					$(".noimages").remove();
				}
			}
		});
		
		addSortableEvent();
		
		$(".delete_img").each(function()
		{
			var $this = $(this);
			deleteImgEvent($this);
		});
		
		$(".edit_img").each(function()
		{
			var $this = $(this);
			editImgEvent($this);
		});
		
		$(".crop_image").each(function()
		{
			var $this = $(this);
			cropImgEvent($this);
		});
	});
	
	function deleteImgEvent($this)
	{
		$this.click(function()
		{
			var li_element = $(this).parent();
			var image_id = li_element.attr("data-imageid");
			
			if( confirm('Are you sure you want to delete this image?') )
			{
				$.ajax(
				{
					url: admin_url + "/admin.php?page=mini-backend-gallery&deleteimageid="+image_id,
					beforeSend: function()
					{
						showLoader("Deleting image...");
					},
					success: function(text)
					{
						li_element.hide("explode", function()
						{
							li_element.remove();
							updateImageNumber();
						});
						
						hideLoader();
					}
				});
			}
			
			return false;
		});
	}
	
	function editImgEvent($this)
	{
		$this.click(function(ev)
		{
			ev.preventDefault();
			
			var li_element = $(this).parent();
			var image_id = li_element.attr("data-imageid");
			
			var url = mbg_plugin_url + '/admin.php?mbg_intern=1&page=editimage&id='+image_id+"&nox";
			
			openFrame(url);
						
			return false;
		});
	}
	
	function openFrame(frame_url)
	{
		/** Version 1.1 Frame */		
		var page_disabler_opacity = 0.8;
		var page_disabler_delay = 500;
		
		var body = $("body");
			
		if( $(".page-disabler").length == 0 )
			var pd = $('<div class="page-disabler"></div>').appendTo( body );
		
		if( $(".frame-dialog").length == 0 )
			var frame = $('<iframe id="image_frame" width="900" frameborder="0" height="100" src="'+frame_url+'" class="frame-dialog"></iframe>').appendTo( $("body") );
			
		frame.fadeTo(0,0);
		frame.load(function()
		{
			frame.fadeTo(500, 1);
		});
		
		var win = $(window);
		var ww = win.width(),
			wh = win.height();
		
		pd.css({position:'fixed', top:0, left: 0, background: '#000', zIndex: 20000, display: 'block', opacity: 0});
		pd.fadeTo(page_disabler_delay, page_disabler_opacity, 'easeOutQuart');
		
		pd.width( ww ).height( wh );
		pd.unbind();
		pd.click(function()
		{
			var pd = $("body > .page-disabler");
			
			pd.stop(true, true).fadeOut(page_disabler_delay, function()
			{
				pd.remove();
			});
			
			frame.remove();
			body.unbind('keyup');
			win.unbind('resize');
			
		});
		
		
		var frame_top = parseInt(wh / 2 - frame.height() / 2);
		var frame_left = parseInt(ww / 2 - frame.width() / 2);
		frame_top = frame_top < 0 ? 0 : frame_top;
		frame_left = frame_left < 0 ? 0 : frame_left;
		
		frame.css({position:'absolute', top:frame_top, left: frame_left, zIndex: 20005, display: 'block'});
		
		// Events
		body.keyup(function(e)
		{
			if( e.keyCode == 27 )
			{
				pd.trigger('click');
			}
		});
		
		win.resize(function()
		{
			var ww = win.width(),
				wh = win.height();
			
			pd.width(ww).height(wh);
		});
		/** EOF Update */
	}
	
	function cropImgEvent($this)
	{
		$this.click(function(ev)
		{			
			ev.preventDefault();
			
			var image_id = $(this).parent().parent().attr("data-imageid");
			
			var url = mbg_plugin_url + '/admin.php?mbg_intern=1&page=cropimage&id='+image_id+"&nox";
			window.open(url, "editImageName", "width=900,height=650,scrollbars=yes");
			
			return false;
		});
	}
	
	var element_dragged = false;
	
	function addSortableEvent()
	{
		$(".album_images").sortable(
		{
			update: function()
			{
				element_dragged = true;
				
				var new_order = "";
				var incrementor = 0;
				
				$(".album_images li").each(function()
				{
					if( incrementor > 0 )
						new_order += ",";
						
					new_order += incrementor + "=" + $(this).attr("data-imageid");
					
					incrementor++;
				});
				
				$.ajax(
				{
					url: mbg_plugin_url + "/admin.php?mbg_intern=1&images_new_order=" + $("#album_id").val() + "&order_string=" + new_order,
					beforeSend: function()
					{
						showLoader("Saving current images order...");
					},
					success: function( resp )
					{
						hideLoader();
					}
				});
			}
		});
		
		$(".album_images").disableSelection();
	}

	
	function updateImageNumber()
	{
		var total_images = $(".album_images .image").length;
		$(".images_uploaded_num").text(total_images);
		
		if( total_images == 0 )
			$(".select_unselect_all_items").hide();
		else
			$(".select_unselect_all_items").show();
		
		if( total_images == 1 )
			$(".plural").text("");
		else
			$(".plural").text("s");
	}
	
	// Version 1.1
	var image_check_function = function()
	{
		var $this = $(this);
		var check_box = $this.find('.image_checkbox');
		
		if( element_dragged )
		{
			element_dragged = false;
			return;
		}
		
		if( $this.find('.rename_image').length != 0 )
		{
			return false;
		}
		
		if( check_box.attr("checked") == true )
		{
			check_box.attr("checked", false);
		}
		else
		{
			check_box.attr("checked", true);
		}
		
		elementsChecked();
	}
	
	$(document).ready(function()
	{
		if( $(".rename_image").length > 0 )
		{
			$(".check_button").css("paddingTop", "10px");
		}
		
		$(".album_images li").click(image_check_function);
		
		$(".rename_image").click(function()
		{
			$(this).find('input').focus();
		});
		
		$("#rename_images").click(function()
		{
			$("#group_action_type").val("do_rename");
		});
		
		$(".confirm").click(function()
		{
			if( !confirm('[DELETE] Are you sure you want to take this action?') )
			{
				return false;
			}
		});
		
		// Group Action Events
		$("#delete_btn").click(function()
		{
			$("#group_action_type").val("delete");
		});
		
		$("#rename_btn").click(function()
		{
			$("#group_action_type").val("rename");
		});
		
		$("#change_album_btn").click(function()
		{
			$("#group_action_type").val("move");
			$(".move_to_another_album").fadeIn("slow");
			$(this).fadeOut();
		});
		
		// Select - unselect all
		$(".select_unselect_all_items a").click(function(ev)
		{
			ev.preventDefault();
			
			var rel = $(this).attr("rel");
			
			switch( rel )
			{
				case "unselect":
					$(".image_checkbox").attr("checked", false);
					break;
				
				default:
					$(".image_checkbox").attr("checked", true);
			}
			
			elementsChecked();
			
			return false;
		});
	});
	
	function elementsChecked()
	{
		var checked_elements = $(".image_checkbox:checked");
		
		if( checked_elements.length > 0 )
		{
			$(".selection_action").slideDown("normal");
		}
		else
		{
			$(".selection_action").stop(true, true).slideUp("normal");
		}
	}
	
	$(document).ready(function()
	{
		$(".image_checkbox").mouseup(function()
		{
			if( !$(this).attr("checked") )
				$(this).attr("checked", true);
			else
				$(this).attr("checked", false);
		});
		
		$(".crop_image").click(function(ev)
		{
			ev.preventDefault();
			
			var image_id = $(this).parent().parent().attr("data-imageid");
						
			var url = mbg_plugin_url + '/admin.php?mbg_intern=1&page=cropimage&id='+image_id+"&nox";
			window.open(url, "editImageName", "width=900,height=650");
		});
		
		$(".short-code input").click(function(ev)
		{
			ev.preventDefault();
			
			$(this).select();
		});
	})