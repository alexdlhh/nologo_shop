<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Mini Back-end Gallery v2 - Examples</title>
<link href="css/api.css" rel="stylesheet" type="text/css" />
</head>

<body>
<h1>Mini Back-end Gallery v2 - WordPress Examples</h1>
<h5>Gallery module created by  Arlind Nushi</h5>

<p>You can include shortcodes in pages or posts, it's your decision.</p>

<p>This example will show all created albums:</p>
<div class="note">
	<blockquote>
		[mbg]
	</blockquote>
</div>

<br />

<p>This example will show just 5 albums in descending order and ordered by album name column, and will exclude album with id 7:</p>
<div class="note">
	<blockquote>
		[mbg count="5" orderby="name" order="desc" except="7"]
	</blockquote>
</div>

<br />

<p>This example will show all images from album with ID 3:</p>
<div class="note">
	<blockquote>
		[mbgalbum id="3"]
	</blockquote>
</div>

<br />

<p>This example will show 11 images from album with ID 8 in descending order. Else, it will show as thumbnails the size 2, and when you click any of the thumbnails you will see image size 3 in new window</p>
<div class="note">
	<blockquote>
		[mbgalbum id="3" count="11" order="desc" size="2" hrefsize="3" target="blank"]
	</blockquote>
</div>

<p>As you can see, the usage of these codes is very easy and you'll be familiar with them very fast.</p>

<p>Go back to  view MBGallery's shordcodes via <a href="api.php">API Page</a>.</p>
</body>
</html>