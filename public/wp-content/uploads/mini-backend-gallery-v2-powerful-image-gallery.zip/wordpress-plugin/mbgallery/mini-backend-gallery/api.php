<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Mini Back-end Gallery v2 (Wordpress edition)</title>
<link href="css/api.css" rel="stylesheet" type="text/css" />
</head>

<body>
<h1>Mini Back-end Gallery v2 - WordPress API</h1>
<h5>Gallery module created by  Arlind Nushi</h5>
<p>Defined shortcodes:</p>

	<div class="functions_env">
    	Album Shortcodes<br />
        <ul>
        	<li><a href="#mbg">[mbg]</a></li>
        </ul>
        
        <br />
        Image Shortcodes
        <ul>
        	<li><a href="#mbgalbum">[mbgalbum]</a></li>
        </ul>
	</div>
    
    
    <div class="function" id="mbg">
    	<h1>shortcode : [mbg count=" except=" albums=" orderby=" order="] - <a href="#top">top</a></h1>
        <p>Parse all or specified by attribute albums. Theme in use handles with albums and offers customized album view.</p>
        
        Shortcode parameters
        <div class="param"><span>count</span> - Number of albums to show (attribute `albums_count` has the same function) | Default: * all albums</div>
        <div class="param"><span>except</span> - Comma-separated album ID's to exclude from query | Default: none</div>
        <div class="param"><span>albums</span> - Include only selected album ID's (comma-separated) | Use only one of these attributes, `albums` or `except` in the same shortcode declaration!</div>
        <div class="param"><span>orderby (name|oid)</span> - Order albums by name or order id | Default: Order ID <em>oid</em></div>
        <div class="param"><span>order (desc|asc)</span> - Order type | Default: Ascending <em>asc</em></div>
        
        Notes
        <div class="param"><span>All these parameters are <b>OPTIONAL</b></span></div>
    </div>
    
    <div class="separator"></div>
    
    <div class="function" id="mbgalbum">
    	<h1>shortcode : [mbgalbum id=" count=" order=" size=" hrefimg=" target="] - <a href="#top">top</a></h1>
        <p>Get all images from specified album id. You can find this shortcode on every album manage page.</p>
        
        Shortcode parameters
        <div class="param"><span>id</span> - Album ID to get images from | Required</div>
        <div class="param"><span>count</span> - Number of images to show (attribute `images_count` has the same function) | Default: * all images in album</div>
        <div class="param"><span>order (desc|asc)</span> - Order type | Default: Ascending <em>asc</em></div>
        <div class="param"><span>size (d|1|2|3)</span> - Image size to show from available 1,2,3 and default thumbnail - d | Default: default thumbnail<em>d</em></div>
        <div class="param"><span>hrefimg (o|1|2|3)</span> - Image size to show on click from available 1,2,3 and original - o | Default: original size image<em>o</em></div>
        <div class="param"><span>target (blank|<em>empty</em>)</span> - When album image is clicked do you want to open it in new window? | Default: open in current window</div>
        
        Notes
        <div class="param"><span>Only <b>ID</b> attribute is required!</span></div>
    </div>


	<div class="note">
    	Some examples how you can use these short-codes can be found on <a href="example.php">this file</a>.
    </div>
	
</body>
</html>