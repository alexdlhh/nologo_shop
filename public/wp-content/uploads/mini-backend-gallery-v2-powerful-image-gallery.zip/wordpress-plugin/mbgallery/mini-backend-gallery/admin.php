<?php

	/**
	 * Mini Back-end Gallery
	 *
	 * Created by: Arlind Nushi
	 * Email: arlindd@gmail.com
	 */
	
	# MBG ADMIN AREA
	define("ADMIN_AREA", 1);
	
	
	# No direct access if not verified by session
	if( !defined("WP_PLUGIN_ACCESS") && $_REQUEST['mbg_intern'] != "1" )
		die("You cannot access directly this page!");
	
	# Direct Access Handle
	if( $_REQUEST['mbg_intern'] == "1" )
	{
		include_once("../../../../wp-config.php");
		
		// Table's Prefix Function
		if( !function_exists("dbprefix") )
		{
			function dbprefix()
			{
				global $table_prefix;
				return $table_prefix;
			}
		}
 		
 		// Else, do the rest of work
		if( !defined("MBG_CONFIG_FILE") )
			include_once("config.php");
		
		if( !class_exists("ImageTools") && !interface_exists("ImageToolsInterface") )
			include_once("inc/ImageTools.class.php");
		
		if( !function_exists("getAllAlbums") )
			include_once("functions.php");	
		
		if( !defined("MBG_MISC_AREA") )
			include_once("misc.php");
		
		if( !isset($_GET['nox']) )
		{
			@mysql_close();
			exit;
		}
		else
		{
			// Die if not authenticated
	 		if( !current_user_can('manage_options') )
	 			die("You cannot access directly this page!");
 		}
	}
		
	define("MBGPATH", MBPATH . "/mini-backend-gallery");
	define("MBGURL", MBURL . "/mini-backend-gallery");
	
	$action = $_GET['page'];
	$action = strtolower($action);
	
		if( !defined("MBG_CONFIG_FILE") )
			include_once(MBGPATH."/config.php");
		
		if( !class_exists("ImageTools") && !interface_exists("ImageToolsInterface") )
			include_once(MBGPATH."/inc/ImageTools.class.php");
		
		if( !function_exists("getAllAlbums") )
			include_once(MBGPATH."/functions.php");	
		
		if( !defined("MBG_MISC_AREA") )
			include_once(MBGPATH."/misc.php");
			
?>
<script type="text/javascript">
	var admin_url = "<?php echo get_bloginfo('wpurl'); ?>/wp-admin";
	var mb_plugin_url = "<?php echo MBURL; ?>";
	var mbg_plugin_url = "<?php echo MBGURL; ?>";
</script>
<script type="text/javascript" src="<?php echo MBGURL; ?>/js/jquery-1.4.4.min.js"></script>
<script type="text/javascript" src="<?php echo MBGURL; ?>/js/jquery-ui-1.8.9.custom.min.js"></script>
<script type="text/javascript" src="<?php echo MBGURL; ?>/js/jquery.uploadify-v2.1.4/swfobject.js"></script>
<script type="text/javascript" src="<?php echo MBGURL; ?>/js/jquery.uploadify-v2.1.4/jquery.uploadify.v2.1.4.min.js"></script>
<script type="text/javascript" src="<?php echo MBGURL; ?>/js/tipsy-0.1.7/javascripts/jquery.tipsy.js"></script>
<script type="text/javascript" src="<?php echo MBGURL; ?>/js/fancybox/jquery.easing-1.3.pack.js"></script>
<script type="text/javascript" src="<?php echo MBGURL; ?>/js/fancybox/jquery.fancybox-1.3.4.pack.js"></script>
<script type="text/javascript" src="<?php echo MBGURL; ?>/js/fancybox/jquery.mousewheel-3.0.4.pack.js"></script>
<script type="text/javascript" src="<?php echo MBGURL; ?>/js/misc.js"></script>
<link href="<?php echo MBGURL; ?>/css/ui-lightness/jquery-ui-1.8.9.custom.css" rel="stylesheet" type="text/css" />
<link href="<?php echo MBGURL; ?>/css/main.css" rel="stylesheet" type="text/css" />
<link href="<?php echo MBGURL; ?>/js/tipsy-0.1.7/stylesheets/tipsy.css" rel="stylesheet" type="text/css" />
<link href="<?php echo MBGURL; ?>/js/jquery.uploadify-v2.1.4/uploadify.css" rel="stylesheet" type="text/css" />
<link href="<?php echo MBGURL; ?>/js/fancybox/jquery.fancybox-1.3.4.css" rel="stylesheet" type="text/css" />
</head>

<body>
<?php    	
    	$hide_settings_arr = array("cropimage", "editimage", "albumcover");
    	
    	if( !in_array($_GET['page'], $hide_settings_arr) )
    	{
    ?>    
    
    <div class="main_content">
	    <?php
			if( defined("_SUCCESS_") )
			{
		?>
	    <div class="success">
	    	<?php echo _SUCCESS_; ?>
	    </div>
	    <?php
			}
		?>
	    
		<?php
			if( defined("_ERROR_") )
			{
		?>
	    <div class="error_mbg">
	    	<?php echo _ERROR_; ?>
	    </div>
	    <?php
			}
		
		
    	}
    	else
    	{
    	
			if( defined("_SUCCESS_") )
			{
			?>
		    <div class="success">
		    	<?php echo _SUCCESS_; ?>
		    </div>
		    <?php
			}
			
			if( defined("_ERROR_") )
			{
			?>
		    <div class="error_mbg">
		    	<?php echo _ERROR_; ?>
		    </div>
		    <?php
			}
			
    	}
		
		switch( $action )
		{
			case "create-new-album":
				include("create_new_album.php");
				break;
			
			case "editimage":
				include("editimage.php");
				break;
			
			case "cropimage":
				include("cropimage.php");
				break;
			
			case "mbg-settings":
				include("settings.php");
				break;
			
			case "albumcover":
				include("albumcover.php");
				break;
			
			case "mbg-themes":
				include("front-end.php");
				break;
			
			default:
				$view_album = $_GET['view_album'];
				
				if( isset($view_album) && is_numeric($view_album) )
				{
					include("album_manage.php");
				}
				else
				{
					include("albums.php");
				}
		}
	?>
    <?php
    
    	if( !in_array($_GET['page'], $hide_settings_arr) )
    	{
    ?>
    <div class="copyrights">
    &copy; Mini Back-end Gallery v2 created by <a href="mailto:arlindd@gmail.com">Arlind Nushi</a> - <a href="<?php echo MBGURL; ?>/api.php" class="api_frame">Need help? Click here</a>
    </div>
    <?php
    	}
    ?>
    </div>