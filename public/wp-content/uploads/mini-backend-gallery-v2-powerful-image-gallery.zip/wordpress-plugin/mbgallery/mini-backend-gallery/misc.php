<?php

	// Misc Area
	define("MBG_MISC_AREA", 1);
	
	// Check if its a legitimate request (a little security)
	if( !defined('ADMIN_AREA') )
		die("You can't access this file!");
		
	// Delete
	if( $id = $_GET['deletealbum'] )
	{
		if( deleteAlbum($id) )
		{
			define('_SUCCESS_', 'Album has been deleted successfully.');
		}
		else
		{
			define('_ERROR_', "Album doesn't exists or it has been deleted before!");
		}
	}
	
	// Move Up
	if( $id = $_GET['moveup'] )
	{
		moveAlbumUP($id);
	}
	
	// Move Down
	if( $id = $_GET['movedown'] )
	{
		moveAlbumDOWN($id);
	}
	
	// Create New Album
	if( isset($_POST['create_album']) )
	{
		$name = mysql_real_escape_string($_POST['album_name']);
		$description = mysql_real_escape_string($_POST['description']);
		
		$thumbnail1 = $_POST['thumbnail1'];
		$thumbnail1fit = $_POST['thumbnail1fit'];
		$size1W = strtolower($_POST['size1W']);
		$size1H = strtolower($_POST['size1H']);
		
		if( !$thumbnail1 )
			$thumbnail1fit = $size1W = $size1H = "";
		
		$thumbnail2 = $_POST['thumbnail2'];
		$thumbnail2fit = $_POST['thumbnail2fit'];
		$size2W = strtolower($_POST['size2W']);
		$size2H = strtolower($_POST['size2H']);
		
		if( !$thumbnail2 )
			$thumbnail2fit = $size2W = $size2H = "";
		
		$thumbnail3 = $_POST['thumbnail3'];
		$thumbnail3fit = $_POST['thumbnail3fit'];
		$size3W = strtolower($_POST['size3W']);
		$size3H = strtolower($_POST['size3H']);
		
		if( !$thumbnail3 )
			$thumbnail3fit = $size3W = $size3H = "";
		
		if( $name )
		{
			$date_created = time();
			$order_id = time();
			$q = mysql_query("INSERT INTO `".dbprefix()."albums`(`AlbumName`,`Description`,`DateCreated`,`OrderID`) VALUES('$name','$description','$date_created',$order_id)") or die(mysql_error());
			
			$last_id = mysql_insert_id();
			define("_SUCCESS_", "Album created successfully. <a href=\"admin.php?page=mini-backend-gallery&view_album=$last_id\">Go to album &raquo;</a>");
			
			// Thumbnail 1
			$size1_x = $size1W . "x" . $size1H . "x" . $thumbnail1fit;
			mysql_query("UPDATE `".dbprefix()."albums` SET `Thumbnail1Size` = '$size1_x' WHERE `AlbumID` = '$last_id'");
			
			
			// Thumbnail 2
			$size2_x = $size2W . "x" . $size2H . "x" . $thumbnail2fit;
			mysql_query("UPDATE `".dbprefix()."albums` SET `Thumbnail2Size` = '$size2_x' WHERE `AlbumID` = '$last_id'");
			
			
			// Thumbnail 3
			$size3_x = $size3W . "x" . $size3H . "x" . $thumbnail3fit;
			mysql_query("UPDATE `".dbprefix()."albums` SET `Thumbnail3Size` = '$size3_x' WHERE `AlbumID` = '$last_id'");
		}
	}
	
	// Start Uploading Files
	if( $upload_image = $_FILES['upload_image'] )
	{
		$album_id = $_POST['album_id'];
		$allowed_file_types = array("jpg","png","jpeg","gif");
		
		$file_name = $upload_image['name'];
		$file_type = strtolower(end(explode(".", $file_name)));
		$file_tmp  = $upload_image['tmp_name'];
		
		$path_to_upload_files = $images_path;
		
		if( in_array($file_type, $allowed_file_types) )
		{
			if( albumExists($album_id) )
			{
				$album = getAlbum($album_id);
				
				// Generate Name
				switch( strtolower($naming) )
				{
					case "hash":
					case "random":
						$new_name = substr(time(), 5) . '_' . substr(md5(time()+rand(1000,9999)), 0, 6) . '_' . substr(sha1(time()+rand(1000,9999)), 0, 6) . '.' . $file_type;
						break;
					
					case "normal":
						$new_name = $file_name;
						break;
						
					default:
						$new_name = str_replace(array(',',"'",'"'), '-', strtolower($file_name));
				}
				
				$album_path = $path_to_upload_files . 'album_' . $album_id . '/';
				$upload_file_path = $album_path . $new_name;
				
				if( !file_exists($album_path) )
				{
					mkdir($album_path);
				}
				
				move_uploaded_file($file_tmp, $upload_file_path);
				$imagesize = getimagesize($upload_file_path);
				
				// Create Default Thumbnail
				$dt_pref_size = array(110, 95);
				$dt_ps = getPreferedSize($dt_pref_size[0], $dt_pref_size[1], $imagesize[0], $imagesize[1]);
				
				$default_thumbnail = new ImageTools($upload_file_path);
				$default_thumbnail->resizeNewByWidth($dt_pref_size[0], $dt_pref_size[1], $dt_ps[0], "#FFF");
				$default_thumbnail->save($album_path, "th_$new_name", 85, true);
				
				
				// Create Defined Thumbnail 1
				$thumbnail1 = $album['Thumbnail1Size'];
				resizeImage($upload_file_path, $album_path."/th1_$new_name", $thumbnail1);
				
				
				// Create Defined Thumbnail 2
				$thumbnail2 = $album['Thumbnail2Size'];
				resizeImage($upload_file_path, $album_path."/th2_$new_name", $thumbnail2);
				
				
				// Create Defined Thumbnail 3
				$thumbnail3 = $album['Thumbnail3Size'];
				resizeImage($upload_file_path, $album_path."/th3_$new_name", $thumbnail3);
				
				
				addImage($album_id, $upload_file_path);
				
				$last_id = mysql_insert_id();
				
				$image = getImage($last_id);
				$image['errors'] = false;
				$image['thumbnailUrl'] = dirname($image['ImagePath']) . '/th_' . basename($image['ImagePath']);
				
				$json = json_encode($image);
				
				echo $json;
			}
			else
			{
				echo json_encode( array("errors" => "AlbumNotExists") );
			}
		}
		else
		{
			echo json_encode( array("errors" => "InvalidFileType") );
		}
		
		@mysql_close($connect);
		exit;
	}
	
	// Change Order of Images
	if( $_GET['images_new_order'] && $_GET['order_string'] )
	{
		$album_id = $_GET['images_new_order'];
		$order_string = $_GET['order_string'];
		
		$ids = explode(",", $order_string);
		
		foreach($ids as $id_str)
		{
			$order_row = explode("=", $id_str);
			
			$order_id = $order_row[0];
			$image_id = $order_row[1];
			
			mysql_query("UPDATE `".dbprefix()."images` SET `OrderID` = '$order_id' WHERE `ImageID` = '$image_id' AND `AlbumID` = '$album_id'");
		}
		
		@mysql_close($connect);
		exit;
	}
	
	// Change Order of Albums
	if( $_GET['albums_new_order'] && $_GET['order_string'] )
	{
		$order_string = $_GET['order_string'];
		
		$ids = explode(",", $order_string);
		
		foreach($ids as $id_str)
		{
			$order_row = explode("=", $id_str);
			
			$order_id = $order_row[0];
			$album_id = $order_row[1];
			
			mysql_query("UPDATE `".dbprefix()."albums` SET `OrderID` = '$order_id' WHERE `AlbumID` = '$album_id'");
		}
		
		@mysql_close($connect);
		exit;
	}
	
	// Delete Image from Album
	if( $image_id = $_GET['deleteimageid'] )
	{
		deleteImage($image_id);
		
		@mysql_close($connect);
		exit;
	}

	// Change Image Name
	if( isset($_POST['change_img_name']) )
	{
		$image_id = $_POST['image_id'];
		$name = $_POST['name'];
		
		if( $image_id )
		{
			setImageName($image_id, $name);
			define("_SUCCESS_", "Image name has been saved");
		}
	}
	
	// Edit Album Info
	if( isset($_POST['edit_album']) )
	{
		$album_id = $_GET['view_album'];
		$name = $_POST['album_name'];
		$description = $_POST['description'];
		
		$thumbnail1 = $_POST['thumbnail1'];
		$thumbnail1fit = $_POST['thumbnail1fit'];
		$size1W = $_POST['size1W'];
		$size1H = $_POST['size1H'];
		$size1 = $size1W . "x" . $size1H;
		$size1 = $thumbnail1 ? $size1 : null;
		
		if( $size1 )
			$size1 = $size1 . "x" . $thumbnail1fit;
		
		
		$thumbnail2 = $_POST['thumbnail2'];
		$thumbnail2fit = $_POST['thumbnail2fit'];
		$size2W = $_POST['size2W'];
		$size2H = $_POST['size2H'];
		$size2 = $size2W . "x" . $size2H;
		$size2 = $thumbnail2 ? $size2 : null;
		
		if( $size2 )
			$size2 = $size2 . "x" . $thumbnail2fit;
		
		
		$thumbnail3 = $_POST['thumbnail3'];
		$thumbnail3fit = $_POST['thumbnail3fit'];
		$size3W = $_POST['size3W'];
		$size3H = $_POST['size3H'];
		$size3 = $size3W . "x" . $size3H;
		$size3 = $thumbnail3 ? $size3 : null;
		
		if( $size3 )
			$size3 = $size3 . "x" . $thumbnail3fit;
		
		editAlbum($album_id, $name, $description, $size1, $size2, $size3);
		define("_SUCCESS_", "Album edited successfully");
	}
	
	// Save Settings
	if( isset($_POST['settings_save_changes']) )
	{
		$naming = $_POST['naming'];
		
		$thumbnail1sizeW = strtolower($_POST['thumbnail1sizeW']);
		$thumbnail1sizeH = strtolower($_POST['thumbnail1sizeH']);
		$thumbnail1fit = $_POST['thumbnail1fit'];
		
		$thumbnail2sizeW = strtolower($_POST['thumbnail2sizeW']);
		$thumbnail2sizeH = strtolower($_POST['thumbnail2sizeH']);
		$thumbnail2fit = $_POST['thumbnail2fit'];
		
		$thumbnail3sizeW = strtolower($_POST['thumbnail3sizeW']);
		$thumbnail3sizeH = strtolower($_POST['thumbnail3sizeH']);
		$thumbnail3fit = $_POST['thumbnail3fit'];
		
		if( !$thumbnail1sizeW && !$thumbnail1sizeH )
		{
			$thumbnail1size = "x";
		}
		else
		{
			$thumbnail1size = $thumbnail1sizeW . "x" . $thumbnail1sizeH . "x" . $thumbnail1fit;
		}
		
		if( !$thumbnail2sizeW && !$thumbnail2sizeH )
		{
			$thumbnail2size = "x";
		}
		else
		{
			$thumbnail2size = $thumbnail2sizeW . "x" . $thumbnail2sizeH . "x" . $thumbnail2fit;
		}
		
		if( !$thumbnail3sizeW && !$thumbnail3sizeH )
		{
			$thumbnail3size = "x";
		}
		else
		{
			$thumbnail3size = $thumbnail3sizeW . "x" . $thumbnail3sizeH . "x" . $thumbnail2fit;
		}
		
		// Save Settings, Update Options
		if( $naming )
			update_option("mbg_naming", $naming);
			
		if( $thumbnail1size )
			update_option("mbg_thumbnail1_size", $thumbnail1size);			
			
		if( $thumbnail2size )
			update_option("mbg_thumbnail2_size", $thumbnail2size);
			
		if( $thumbnail3size )
			update_option("mbg_thumbnail3_size", $thumbnail3size);
			
		
		define("_SUCCESS_", "Settings have been saved.");
	}
	
	// Delete group of images
	if( $_POST['take_group_action'] && $_POST['group_action_type'] == "delete" )
	{
		$selected_images = $_POST['selected_images'];
		
		if( count($selected_images) )
		{
			$deleted_images = 0;
			
			foreach($selected_images as $image)
			{
				if( imageExists($image) )
				{
					deleteImage($image);
					$deleted_images++;
				}
			}
			
			if( $deleted_images > 0 )
			{
				define("_SUCCESS_", "$deleted_images image".($deleted_images > 1 ? 's' : '')." have been deleted successfully.");
			}
			else
			{
				define("_ERROR_", "Images have been already deleted.");
			}
		}
	}
	
	// Rename group of images
	if( $_POST['take_group_action'] && $_POST['group_action_type'] == "rename" )
	{
		$selected_images = $_POST['selected_images'];
		
		if( count($selected_images) )
		{
			define("DO_RENAME", true);
		}
	}
	
	// Rename group of images (ACTION)
	if( $_POST['take_group_action'] && $_POST['group_action_type'] == "do_rename" )
	{
		$selected_images = $_POST['selected_images'];
		
		if( count($selected_images) )
		{
			foreach($selected_images as $image)
			{
				if( imageExists($image) && isset($_POST['rename_'.$image]) )
				{
					$new_name = $_POST['rename_' . $image];
					setImageName($image, $new_name);
				}
			}
			
			define("_SUCCESS_", "Image names have been changed");
			define("IMAGE_NAMES_CHANGED", true);
		}
	}	
	
	// Move group of images
	if( $_POST['take_group_action'] && $_POST['group_action_type'] == "move" )
	{
		$album_id = $_POST['album_id'];
		
		if( albumExists($album_id) )
		{
			$images_moved = 0;
			$selected_images = $_POST['selected_images'];
			
			if( count($selected_images) )
			{
				foreach($selected_images as $image)
				{
					moveImage($image, $album_id);
					$images_moved++;
				}
			}
			
			define("_SUCCESS_", "Selected images ($images_moved) have been moved to the selected album. <a href=\"admin.php?page=mini-backend-gallery&view_album=$album_id\">Go to album</a> &raquo;");
		}
		else
		{
			define("_ERROR_", "Cannot move images because the selected album currently doesn't exists!");
		}
	}
	
	// Crop Image
	if( isset($_POST['save_crop']) )
	{
		$crop_w = $_POST['crop_w'];
		$crop_h = $_POST['crop_h'];
		$crop_x1 = $_POST['crop_x1'];
		$crop_y1 = $_POST['crop_y1'];
		$crop_x2 = $_POST['crop_x2'];
		$crop_y2 = $_POST['crop_y2'];
		
		if( $crop_w && $crop_h && $crop_x1 < $crop_x2 && $crop_y1 < $crop_y2 )
		{
			$id = $_GET['id'];
			$image = getImage($id);
			
			$image_dir = dirname($image['ImagePath']) . "/";
			$image_name = basename($image['ImagePath']);
			
			$edit_image = new ImageTools($image['ImagePath']);
			$edit_image->cropImage($crop_x1, $crop_y1, $crop_w, $crop_h);
			$edit_image->save($image_dir, $image_name, 85, true);
			$edit_image->destroy();
			
			define("_SUCCESS_", "Image cropped successfully.");
		}
	}
	
	// Set album cover image
	if( $_GET['album_id'] && $_GET['set_cover'] && $_GET['cover_type'] )
	{
		echo setAlbumCover($_GET['album_id'], $_GET['set_cover'], ($_GET['cover_type'] == "set" ? true : false)) ? 1 : 0;
		exit;
	}
	
	
	// Set theme
	if( isset($_POST['set_theme']) && $_POST['theme_name'] )
	{
		$theme_name = $_POST['theme_name'];
		
		$theme_path = MBPATH . "/themes/$theme_name/";
		
		if( file_exists($theme_path. "index.php") )
		{
			$constraints_file = $theme_path . "constraints.php";
			
			if( file_exists($constraints_file) )
			{
				include($constraints_file);
			}
			
			update_option('mbg_current_theme', $theme_name);
			
			
			if( $THEME_THUMBNAIL1_SIZE != null )
			{
				update_option('mbg_thumbnail1_size', $THEME_THUMBNAIL1_SIZE);
				
				// Save for already-created albums
				changeThumbailSize(1, $THEME_THUMBNAIL1_SIZE);
			}
			
			if( $THEME_THUMBNAIL2_SIZE != null )
			{
				update_option('mbg_thumbnail2_size', $THEME_THUMBNAIL2_SIZE);
				
				// Save for already-created albums
				changeThumbailSize(2, $THEME_THUMBNAIL2_SIZE);
			}
			
			if( $THEME_THUMBNAIL3_SIZE != null )
			{
				update_option('mbg_thumbnail3_size', $THEME_THUMBNAIL3_SIZE);
				
				// Save for already-created albums
				changeThumbailSize(3, $THEME_THUMBNAIL3_SIZE);
			}
			
			define("_SUCCESS_", "Theme installed successfully!");
		}
		else
		{
			define("_ERROR_", "$theme_name is not valid MBG Theme!");
		}
	}

	
	// Logout
	if( isset($_GET['logout']) )
	{
		session_destroy();
		setcookie("token", "-");
		header("Location: index.php");
	}
?>