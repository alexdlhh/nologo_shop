<?php

	include("../../../../../wp-config.php");
	
	/* Accept JSON requests from gallery theme */
	
	// Get Album Info and Images
	if( $album_id = $_GET['get_album'] )
	{
		$album_info = array();
		$album_info['album_exists'] = false;
		
		if( albumExists($album_id) )
		{
			$mini_backend_gallery_url = MBURL . "/mini-backend-gallery/";
			$album_info['album_exists'] = true;
			
			$album = getAlbum($album_id);
			
			$album_info['AlbumID'] = $album['AlbumID'];
			$album_info['AlbumName'] = $album['AlbumName'];
			$album_info['AlbumDescription'] = $album['Description'];
			$album_info['DateCreated'] = date("d F Y / H:i", $album['DateCreated']);
			
			$album_info['hasImages'] = false;
			
			$images = getAlbumImages($album_id);
			
			if( ($total_images = count($images)) > 0 )
			{
				$album_info['hasImages'] = true;
				$album_info['imagesCount'] = $total_images;
				
				$images_arr = array();
				
				foreach($images as $image)
				{
					$image_entry = array("ImageID" => $image['ImageID'], "ImageName" => $image['Name'], "UploadDate" => $image['UploadDate']);
					
					if( $image['Thumbnail2'] )
					{
						$image_entry['ImageURL'] = $mini_backend_gallery_url . $image['Thumbnail2'];
						$image_entry['ThumbnailURL'] = $mini_backend_gallery_url . $image['DefaultThumbnail'];
						array_push($images_arr, $image_entry);
					}
				}
				
				$album_info['Images'] = $images_arr;
			}
		}
		
		echo json_encode($album_info);
	}
?>