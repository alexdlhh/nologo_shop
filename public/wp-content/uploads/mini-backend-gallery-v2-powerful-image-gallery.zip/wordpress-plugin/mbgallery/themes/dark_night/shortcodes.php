<?php
	
	$mbg_functions_imported = false;
	$mbgalbum_functions_imported = false;
	include(MBPATH."/mini-backend-gallery/functions.php"); # MBGALLERY FUNCTIONS
	
	// Import Functions
	
	add_shortcode('mbg', 'shortcode_mbg');
	add_shortcode('mbgalbum', 'shortcode_mbgalbum');
	
	function shortcode_mbg($atts, $content = null)
	{
		global $mbg_functions_imported;
	
		if( !$album_functions_imported )
		{
			
			include_once(MBPATH."/mini-backend-gallery/functions.php");
			
			$mbg_current_theme = get_option("mbg_current_theme");
			
			// JavaScript Files
			print('<script type="text/javascript" src="' .MBURL . '/themes/dark_night/js/jquery-1.5.2.min.js"></script>');
			print('<script type="text/javascript" src="' .MBURL . '/themes/dark_night/js/jquery.easing.1.3.js"></script>');
			print('<script type="text/javascript" src="' .MBURL . '/themes/dark_night/js/jquery.center.js"></script>');
			print('<script type="text/javascript" src="' .MBURL . '/themes/dark_night/js/jquery.expander.js"></script>');
			print('<script type="text/javascript" src="' .MBURL . '/themes/dark_night/js/mbg-frontend-theme1.js"></script>');
			
			// CSS Files
			print('<link type="text/css" rel="stylesheet" href="'.MBURL . '/themes/dark_night/css/theme-1.css" />');
			
			$mbg_functions_imported = true;
		}
		
		if( is_array($atts) )
			extract($atts);
		
		$build_query = "SELECT * FROM `".dbprefix()."albums` ";
		
		// Where Condition
		$where_condition = "WHERE 1 ";
		
		// Show Only or Except
		if( $albums )
		{
			if( preg_match("/^([0-9]+,?)+$/", $albums) )
			{
				if( substr($albums, -1, 1) == "," )
				{
					$albums = substr($albums, 0, -1);
				}
				
				$where_condition .= " AND `AlbumID` IN ($albums) ";
			}
		}
		else
		if( $except )
		{
			if( preg_match("/^([0-9]+,?)+$/", $except) )
			{
				if( substr($except, -1, 1) == "," )
				{
					$except = substr($except, 0, -1);
				}
				
				$where_condition .= " AND `AlbumID` NOT IN ($except) ";
			}
		}
		
		// Concatenate Where Condition
		$build_query = $build_query . $where_condition;
		
		// Ordering
		switch( strtolower($orderby) )
		{
			case "name":
			case "albumname":
				$order_column = "AlbumName";
				break;
				
			default:
				$order_column = "OrderID";
		}
		$order = strtoupper($order) == "DESC" ? "DESC" : "ASC";
		$build_query .= " ORDER BY `$order_column` $order ";
		
		// Limit
		$offset = is_numeric($albums_count) && $albums_count > 0 ? $albums_count : $count;
		$offset = !is_numeric($offset) || $offset < 1 ? null : $offset;
		
		if( $offset )
			$build_query .= " LIMIT 0,$offset";
		
		// Execute Query
		$q = mysql_query($build_query);
		
		if( mysql_num_rows($q) )
		{
			$theme_url = MBURL . '/themes/' . get_option('mbg_current_theme');
			
			$output_html = '<script type="text/javascript"> var mbg_theme_url = "'.$theme_url.'"; var mbg_uploads_url = "'.MBURL.'/mini-backend-gallery/uploads"; </script>';
			$output_html.= '<ul class="mbg_albums">';
			
			while($r = mysql_fetch_array($q))
			{
				$album_id = $r['AlbumID'];
				$album_name = $r['AlbumName'];
				$album_cover = $r['AlbumCover'];
				
				$album_cover_img = $theme_url . "/images/album-cover.png";
				
				if( $album_cover )
				{
					$album_cover = getImage($album_cover);
					$album_cover_img = MBURL . "/mini-backend-gallery/" . $album_cover['Thumbnail1'];
				}
				
				$total_images = countAlbumImages($album_id);
				
				$output_html.= '<li data-id="'.$album_id.'">';
				$output_html.= '<div class="album_container">';
				$output_html.= '<a href="#" class="album_cover">';
				$output_html.= '<img src="'.$album_cover_img.'" alt="" />';
				$output_html.= '<a>';
				$output_html.= '<a href="#" class="album_name">';
				$output_html.= $album_name;
				$output_html.= '</a>';
				$output_html.= '<span class="album_details">';
				$output_html.= $total_images . " " . ($total_images == 1 ? "photo" : "photos");
				$output_html.= '</span>';
				$output_html.= '<div class="clear"></div>';
				$output_html.= '</div>';
				$output_html.= '</li>';
			}
			
			$output_html.= '</ul>';
			
			
			if( !$album_functions_imported )
			{
				$output_html .= '<div class="loader"></div>';
			}
						
			return $output_html;
		}
		
		return null;
	}
	
	function shortcode_mbgalbum($atts, $content = null)
	{
		global $mbgalbum_functions_imported;
				
		if( is_array($atts) )
			extract($atts);
		
		if( !$album_functions_imported )
		{
			// CSS Files
			print('<link type="text/css" rel="stylesheet" href="'.MBURL . '/themes/dark_night/css/theme-1.css" />');
		}
		
		if( !is_numeric($id) )
			$id = 0;
		
		// Build Query
		$build_query = "SELECT * FROM `".dbprefix()."images` ";
		
		// Where Condition
		$where_condition = "WHERE `AlbumID` = '$id' ";
		
		// Order
		$order = strtoupper($order) == "DESC" ? "DESC" : "ASC";
		$build_query .= " ORDER BY `OrderID` $order ";
		
		// Limit
		$offset = is_numeric($images_count) && $images_count > 0 ? $images_count : $count;
		$offset = !is_numeric($offset) || $offset < 1 ? null : $offset;
		
		if( $offset )
			$build_query .= " LIMIT 0,$offset";
		
		$q = mysql_query($build_query);
		
		$output_html = "";
		
		if( mysql_num_rows($q) )
		{
			$output_html.= '<ul class="mbg_album">';
			
			$uploads_path = MBPATH . "/mini-backend-gallery/";
			
			while($r = mysql_fetch_array($q) )
			{
				$thumbnail_image = $r['ImagePath'];
				$images_dir = dirname($thumbnail_image) . "/";
				$image_name = basename($r['ImagePath']);
				
				$original_image = $images_dir . $image_name;
				$thumbnail0_image = $images_dir . 'th_' . $image_name;
				$thumbnail1_image = $images_dir . 'th1_' . $image_name;
				$thumbnail2_image = $images_dir . 'th2_' . $image_name;
				$thumbnail3_image = $images_dir . 'th3_' . $image_name;
				
				// Choose Image Size
				switch( $size )
				{
					case "1":
					case "th1":
						
						if( file_exists($uploads_path . $thumbnail1_image) )
						{
							$thumbnail_image = $thumbnail1_image;
						}
						else
						{
							$thumbnail_image = $thumbnail0_image;
						}
						
						break;
						
					case "2":
					case "th2":
						
						if( file_exists($uploads_path . $thumbnail2_image) )
						{
							$thumbnail_image = $thumbnail2_image;
						}
						else
						{
							$thumbnail_image = $thumbnail0_image;
						}
						
						break;
						
					case "3":
					case "th3":
						
						if( file_exists($uploads_path . $thumbnail3_image) )
						{
							$thumbnail_image = $thumbnail3_image;
						}
						else
						{
							$thumbnail_image = $thumbnail0_image;
						}
						
						break;
						
					default:
						$thumbnail_image = $thumbnail0_image;
				}
				
				$thumbnail_url = MBURL . "/mini-backend-gallery/" . $thumbnail_image;
				
				// Image Href
				switch( strtolower($hrefimg) )
				{
					case "1":
					case "th1":
						if( file_exists($uploads_path . $thumbnail1_image) )
						{
							$href_img_name = $thumbnail1_image;
						}
						else
						{
							$href_img_name = $original_image;
						}
						break;
					
					
					case "2":
					case "th2":
						if( file_exists($uploads_path . $thumbnail2_image) )
						{
							$href_img_name = $thumbnail2_image;
						}
						else
						{
							$href_img_name = $original_image;
						}
						break;
					
					
					case "3":
					case "th3":
						if( file_exists($uploads_path . $thumbnail3_image) )
						{
							$href_img_name = $thumbnail3_image;
						}
						else
						{
							$href_img_name = $original_image;
						}
						break;
						
					default:
						$href_img_name = $original_image;
				}
				
				$image_href = MBURL . "/mini-backend-gallery/" . $href_img_name;
				
				$output_html.= '<li data-id="'.$album_id.'">';
				$output_html.= '<a href="'.$image_href.'"'.(strtolower($target) == "blank" ? ' target="_blank"' : '').'>';
				$output_html.= '<img src="'.$thumbnail_url.'" />';
				
				if( $r['Name'] && strtolower($names) != "no" )
					$output_html .= '<span>'.$r['Name'].'</span>';
				
				$output_html.= '</a>';
				$output_html.= '</li>';
			}
			
			$output_html.= '<ul>';
			$output_html.= '<div class="clear"></div>';
		}
		
		return $output_html;
	}
?>