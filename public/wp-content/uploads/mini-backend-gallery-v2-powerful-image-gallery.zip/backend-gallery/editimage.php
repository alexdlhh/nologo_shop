<script type="text/javascript" src="js/editimage.js"></script>
<?php
	$id = $_GET['id'];

	if( imageExists($id) )
	{
		$image = getImage($id);
		
		$name = $image['Name'];
		
		$image_path = $image['ImagePath'];
		$thumbnail_0 = dirname($image_path) . '/th_' . basename($image_path);
		$thumbnail_1 = dirname($image_path) . '/th1_' . basename($image_path);
		$thumbnail_2 = dirname($image_path) . '/th2_' . basename($image_path);
		$thumbnail_3 = dirname($image_path) . '/th3_' . basename($image_path);
		
		$imagesize = getimagesize($image_path);
		
		$imagesize[0] = $imagesize[0] > 800 ? 800 : $imagesize[0];
		$imagesize[1] = $imagesize[1] > 700 ? 700 : $imagesize[1];
		
?>
<script type="text/javascript">
	$(window).load(function()
    {
    	framecenter();
    	$("body").css("background", "transparent");
    });
    
    function framecenter()
    {
    	parent.document.getElementById('image_frame').style.width = "<?php echo ($imagesize[0] < 430 ? 430 : $imagesize[0]) + 80; ?>px";
    	
    	var pww = $(parent.window).width();
    	var pwh = $(parent.window).height();
    	   	
    	var body_height = $("body").height() + 45;
    	var frame = $(parent.document).find('#image_frame');
    	
    	frame.height(body_height + 20);
    	
    	var frame_width = frame.width();
    	var frame_height = frame.height();
    	    	
    	var frame_top = parseInt(pwh/2 - frame_height/2) + $(parent.window).scrollTop();
    	var frame_left = parseInt(pww/2 - frame_width/2);
    	
    	frame_top = frame_top < 0 ? 0 : frame_top;
    	frame_left = frame_left < 0 ? 0 : frame_left;
    	
    	frame.css({top: frame_top, left: frame_left});
    }
    
</script>
		<ul class="image_types">
			<li class="active"><a href="#" data-imagesrc="<?php echo $image_path; ?>">Original Image</a></li>
			<?php
			
			if( file_exists($thumbnail_0) )
			{
				?>
				<li><a href="#" data-imagesrc="<?php echo $thumbnail_0; ?>">Thumbnail</a></li>
				<?php
			}
			
			if( file_exists($thumbnail_1) )
			{
				?>
				<li><a href="#" data-imagesrc="<?php echo $thumbnail_1; ?>">IMG1</a></li>
				<?php
			}
			
			if( file_exists($thumbnail_2) )
			{
				?>
				<li><a href="#" data-imagesrc="<?php echo $thumbnail_2; ?>">IMG2</a></li>
				<?php
			}
			
			if( file_exists($thumbnail_3) )
			{
				?>
				<li><a href="#" data-imagesrc="<?php echo $thumbnail_3; ?>">IMG3</a></li>
				<?php
			}
			
			?>
		</ul>
		
		<div class="clear"></div>
        <div class="view_image radius">
			<img src="<?php echo $image_path; ?>" width="<?php echo $imagesize[0]; ?>" />
			
			<form name="form1" method="post" action="">
				<input name="image_id" type="hidden" value="<?php echo $id; ?>">
				
				<label for="name">Image Name:</label>      
				<textarea name="name" id="name" style="padding:5px;" rows="5"><?php echo $name; ?></textarea><br>
				
				<input type="submit" class="save_changes" name="change_img_name" id="change_img_name" value="Save changes">
			</form>
        </div>
  <div class="clear"></div>
        
    
        <?php
	}
	else
	{
		?>
<div class="error">Image doesn't exists! Please go back.</div>
<?php
	}
?>