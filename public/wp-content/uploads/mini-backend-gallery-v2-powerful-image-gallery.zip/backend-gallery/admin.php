<?php

	/**
	 * Mini Back-end Gallery
	 *
	 * Created by: Arlind Nushi
	 * Email: arlindd@gmail.com
	 */

	session_start();
	define("ADMIN_AREA", 1);
	
	include("config.php");
	
	$action = $_GET['action'];
	$action = strtolower($action);
	
	include('mysql.open.php');
	include("inc/ImageTools.class.php");
	include("functions.php");
	
	if( !isLoggedIn($admin_username, $admin_password) )
	{
		if( $upload_image = $_FILES['upload_image'] )
		{
			include("misc.php");
		}
		else
			header("Location: index.php");
			
		exit;
	}
	
	include("misc.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $title; ?></title>
<script type="text/javascript" src="js/jquery-1.4.4.min.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.8.9.custom.min.js"></script>
<script type="text/javascript" src="js/jquery.uploadify-v2.1.4/swfobject.js"></script>
<script type="text/javascript" src="js/jquery.uploadify-v2.1.4/jquery.uploadify.v2.1.4.min.js"></script>
<script type="text/javascript" src="js/tipsy-0.1.7/javascripts/jquery.tipsy.js"></script>
<script type="text/javascript" src="js/misc.js"></script>
<link href="css/ui-lightness/jquery-ui-1.8.9.custom.css" rel="stylesheet" type="text/css" />
<link href="css/main.css" rel="stylesheet" type="text/css" />
<link href="js/tipsy-0.1.7/stylesheets/tipsy.css" rel="stylesheet" type="text/css" />
<link href="js/jquery.uploadify-v2.1.4/uploadify.css" rel="stylesheet" type="text/css" />
</head>

<body>
<?php
	if( file_exists("install.php") )
	{
		define("_ERROR_", "Please delete install.php file!");
	}
    	
    	$hide_settings_arr = array("cropimage", "editimage", "albumcover");
    	
    	if( !in_array($_GET['action'], $hide_settings_arr) )
    	{
    ?>
    <div class="mbg_header">
    	<a href="admin.php">
    		<img src="css/images/mbg-logo.png" alt="mbg-logo" width="448" height="32" />
    	</a>
    </div>
    
    
    <div class="main_content">
	    <?php
			if( defined("_SUCCESS_") )
			{
		?>
	    <div class="success">
	    	<?php echo _SUCCESS_; ?>
	    </div>
	    <?php
			}
		?>
	    
		<?php
			if( defined("_ERROR_") )
			{
		?>
	    <div class="error">
	    	<?php echo _ERROR_; ?>
	    </div>
	    <?php
			}
		?>
	
    <div class="main_menu_div">
		<a href="?action=new_album" class="button">Create New Album</a>
		<div class="clear"></div>
		<a href="?" class="button">Manage Albums</a>
		<div class="clear"></div>
		<a href="?action=front-end" class="button">Front-end Framework</a>
		<div class="clear"></div>
		<a href="?action=settings" class="button">General Settings</a>
		<div class="clear"></div>
		<a href="?logout" class="button">Logout</a>
    </div>
    
    <?php
    	}
    	else
    	{
    	
			if( defined("_SUCCESS_") )
			{
			?>
		    <div class="success">
		    	<?php echo _SUCCESS_; ?>
		    </div>
		    <?php
			}
			
			if( defined("_ERROR_") )
			{
			?>
		    <div class="error">
		    	<?php echo _ERROR_; ?>
		    </div>
		    <?php
			}
			
    	}
		
		switch( $action )
		{
			case "new_album":
				include("create_new_album.php");
				break;
			
			case "album":
				include("album_manage.php");
				break;
			
			case "editimage":
				include("editimage.php");
				break;
			
			case "cropimage":
				include("cropimage.php");
				break;
			
			case "settings":
				include("settings.php");
				break;
			
			case "albumcover":
				include("albumcover.php");
				break;
			
			case "front-end":
				include("front-end.php");
				break;
			
			default:
				include("albums.php");
		}
	?>
    <?php
    
    	if( !in_array($_GET['action'], $hide_settings_arr) )
    	{
    ?>
    <div class="copyrights">
    &copy; Mini Back-end Gallery v2 created by <a href="mailto:arlindd@gmail.com">Arlind Nushi</a> - <a href="api.php">API</a>
    </div>
    <?php
    	}
    ?>
    </div>
    
</body>
</html>
<?php
	@mysql_close($connect);
?>