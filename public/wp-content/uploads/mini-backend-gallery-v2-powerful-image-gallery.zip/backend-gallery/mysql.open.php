<?php
	$connect = @mysql_pconnect($db_host, $db_user, $db_pass);
	mysql_select_db($db_name, $connect);
?>