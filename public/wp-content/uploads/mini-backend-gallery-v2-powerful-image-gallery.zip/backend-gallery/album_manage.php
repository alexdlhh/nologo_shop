<?php
	
	$id = $_GET['id'];
	
	if( albumExists($id) )
	{
		$album = getAlbum($id);
		$images = getAlbumImages($id);
		
		$total_images = count($images);
		
		$album_cover = $album['AlbumCover'];
		$album_cover_img = "css/images/album_cover.png";
		
		if( is_array($album_cover) )
		{
			$album_cover_img = $album_cover['DefaultThumbnail'];
		}
?>
<script type="text/javascript" src="js/album_manage.js"></script>
<script type="text/javascript" src="js/album_cover.js"></script>

<table border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td valign="top">
			<a href="#" class="image_cover radius" title="Set or change album cover">
				<img src="<?php echo $album_cover_img; ?>" alt="album_cover" width="60" height="51" />
			</a>
		</td>
		<td valign="top">
			<h1 class="album_edit">
				<strong><?php echo $album['AlbumName']; ?></strong> 
				<br />
				<a class="album_edit" href="?action=album&id=<?php echo $id . (isset($_GET['edit']) ? '' : '&edit'); ?>">Edit</a>
				<span>/ <span class="images_uploaded_num"><?php echo $total_images; ?></span> image<span class="plural"><?php echo $total_images != 1 ? 's' : ''; ?></span></span>
			</h1>		
		</td>
	</tr>
</table>

<div class="separator"></div>
<br />
<form action="" method="post" enctype="multipart/form-data" name="uploadImageForm" id="uploadImageForm">
  <input type="hidden" name="album_id" id="album_id" value="<?php echo $album['AlbumID']; ?>">
  <input type="file" name="upload_image" id="upload_image" class="button">
</form>

<?php
	if( isset($_GET['edit']) )
	{
		include("edit_album.php");
	}
?>
<div class="clear"></div>

<form method="post" name="form2">
<div class="selection_action">
	<div>Selected items:</div>
	<input type="hidden" name="take_group_action" id="take_group_action" value="1" />
	<input type="hidden" name="group_action_type" id="group_action_type" value="none" />
	
	<input type="submit" name="delete" id="delete_btn" value="Delete" class="button confirm" />
	<input type="submit" name="rename" id="rename_btn" value="Rename" class="button" />
	<input type="button" name="change_album" id="change_album_btn" value="Move to another album" class="button" />
	
	<div class="move_to_another_album">
		<select name="album_id" class="change_album">
		<?php
			$albums = getAllAlbums();
			
			foreach($albums as $album)
			{
				?>
				<option<?php echo $_GET['id'] == $album['AlbumID'] ? ' selected' : ''; ?> value="<?php echo $album['AlbumID']; ?>"><?php echo $album['AlbumName']; ?></option>
				<?php
			}
		?>
		</select>
		
		<input type="submit" name="move_images" id="move_images_btn" value="Move album" class="button" />
	</div>
</div>
<?php
			?>
            <ul class="album_images">
            <?php
			
			foreach($images as $image)
			{
				$image_id = $image['ImageID'];
				$image_path = $image['ImagePath'];
				$name = $image['Name'];
				
				$thumbnail = dirname($image_path) . '/th_' . basename($image_path);
				
				?>
                <li class="image radius" data-imageid="<?php echo $image['ImageID']; ?>">
					<img src="<?php echo $thumbnail; ?>" width="110" height="95" alt="<?php echo addslashes($name); ?>" title="<?php echo addslashes($name); ?>" />
                    <div class="clear"></div>
                    <a href="admin.php?action=editimage&id=<?php echo $image['ImageID']; ?>" class="edit_img">Edit</a>
                    <a href="#" class="delete_img">Delete</a>
                    <div class="check_button">
                    	<input type="checkbox"<?php echo is_array($selected_images) && in_array($image_id, $selected_images) && !defined("IMAGE_NAMES_CHANGED") ? ' checked="checked"' : ''; ?> name="selected_images[]" class="image_checkbox" id="image_id_<?php echo $image_id; ?>" value="<?php echo $image_id; ?>" />
                    	<a href="#" class="crop_image">Crop</a>
                    	<div class="clear"></div>
                    </div>
                    
                    <?php
                    	if( defined("DO_RENAME") && in_array($image_id, $selected_images) )
                    	{
                    	?>
                    	<div class="rename_image">
                    		<input type="text" tabindex="1" name="rename_<?php echo $image_id; ?>" value="<?php echo $name; ?>" placeholder="Set image name" />
                    	</div>
                    	<?php
                    	}
                    ?>
                </li>
                <?php
			}
			
			if( !count($images) )
			{
				?>
                <li class="noimages">
                	There are no images in this album
                </li>
                <?php
			}
			
			?>
            </ul>
            
            <?php
            	if( defined("DO_RENAME") )
            	{
            	?>
            		<div class="clear"></div>
            		
            		<div class="rename_button_env">
            			<input type="submit" name="rename_images" id="rename_images" value="Save Changes" class="button" />
            		</div>
            	<?php
            	}
            ?>
</form>
            <div class="clear"></div>
            
   			<div class="select_unselect_all_items<?php echo !count($images) ? ' hide' : ''; ?>">
   				<a href="#" rel="select">Select all</a>  <a href="#" rel="unselect">Select none</a>
   			</div>
       		
            
            <a href="admin.php" class="go_back">&laquo; Go back</a>
            <div class="separator"></div>
            <?php
	}
	else
	{
?>
<br /><br />
<div class="error">Album doesn't exists! Please go back.</div>
<?php
	}
?>
<div class="loader">Loading...</div>