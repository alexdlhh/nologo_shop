-- phpMyAdmin SQL Dump
-- version 3.2.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 08, 2011 at 06:54 PM
-- Server version: 5.1.44
-- PHP Version: 5.3.2

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `mini_backend_gallery`
--

-- --------------------------------------------------------

--
-- Table structure for table `mbg_albums`
--

CREATE TABLE `mbg_albums` (
  `AlbumID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `AlbumName` varchar(255) NOT NULL,
  `Description` text NOT NULL,
  `DateCreated` int(20) NOT NULL,
  `Thumbnail1Size` varchar(10) DEFAULT NULL,
  `Thumbnail2Size` varchar(10) DEFAULT NULL,
  `Thumbnail3Size` varchar(10) DEFAULT NULL,
  `OrderID` int(11) NOT NULL DEFAULT '1',
  `AlbumCover` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`AlbumID`),
  KEY `AlbumCover` (`AlbumCover`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mbg_albums`
--


-- --------------------------------------------------------

--
-- Table structure for table `mbg_images`
--

CREATE TABLE `mbg_images` (
  `ImageID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `AlbumID` int(11) unsigned NOT NULL,
  `ImagePath` varchar(255) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `UploadDate` int(20) NOT NULL,
  `OrderID` int(20) NOT NULL,
  PRIMARY KEY (`ImageID`),
  KEY `AlbumID` (`AlbumID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mbg_images`
--


--
-- Constraints for dumped tables
--

--
-- Constraints for table `mbg_albums`
--
ALTER TABLE `mbg_albums`
  ADD CONSTRAINT `mbg_albums_ibfk_1` FOREIGN KEY (`AlbumCover`) REFERENCES `mbg_images` (`ImageID`);

--
-- Constraints for table `mbg_images`
--
ALTER TABLE `mbg_images`
  ADD CONSTRAINT `mbg_images_ibfk_1` FOREIGN KEY (`AlbumID`) REFERENCES `mbg_albums` (`AlbumID`);
