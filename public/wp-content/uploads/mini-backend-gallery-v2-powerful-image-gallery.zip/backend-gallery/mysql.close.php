<?php
	@mysql_close($connect);
?>