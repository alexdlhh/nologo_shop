<div class="gdsr-widget-controls">
<?php include(STARRATING_PATH.'widgets/top/part_basic.php'); ?>
<?php include(STARRATING_PATH.'widgets/top/part_filter.php'); ?>
</div>
<input type="hidden" id="gdstarr-submit" name="<?php echo $wpfn; ?>[submit]" value="1" />
