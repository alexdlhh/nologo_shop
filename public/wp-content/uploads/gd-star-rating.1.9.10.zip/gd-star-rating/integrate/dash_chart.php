<img src="<?php echo STARRATING_CHART_URL; ?>chart_pie_votes_summary.php" border="0" />
