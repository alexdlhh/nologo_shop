<?php
/*
Plugin Name: Shortcodes Pro 
Version: 1.0.7
Plugin URI: http://codecanyon.net/user/skmatt?ref=skmatt
Description: Shortcodes Pro gives you complete control of your shortcodes and rich editor buttons.
Author: Matt Varone
Author URI: http://www.twitter.com/wpcustomplugins
*/

/**
* Shortcodes Pro Initialize
*
* @package Shortcodes Pro
* @author Matt Varone
*/
		
/*
|--------------------------------------------------------------------------
| SHORTCODES PRO CONSTANTS
|--------------------------------------------------------------------------
*/

define('SHORTCODES_PRO_BASENAME', plugin_basename( __FILE__ ));
define('SHORTCODES_PRO_URL', plugins_url('',__FILE__));
define('SHORTCODES_PRO_PATH', plugin_dir_path(__FILE__));
define('SHORTCODES_PRO_VERSION', '1.0.7');
define('SHORTCODES_PRO_FOLDER', '/'.basename(dirname(__FILE__)));

/*
|--------------------------------------------------------------------------
| SHORTCODES PRO INCLUDES
|--------------------------------------------------------------------------
*/

require_once(SHORTCODES_PRO_PATH.'inc/shortcodespro-options.php');
require_once(SHORTCODES_PRO_PATH.'inc/class-shortcodespro-type.php');
require_once(SHORTCODES_PRO_PATH.'inc/class-shortcodespro-main.php');

/*
|--------------------------------------------------------------------------
| ADD THUMBNAILS SUPPORT
|--------------------------------------------------------------------------
*/
	
if ( !function_exists('shortcodes_pro_thumbnail_support') )
{
	function shortcodes_pro_thumbnail_support()
	{
		if (function_exists('add_theme_support'))
		add_theme_support('post-thumbnails');
	}
}

add_action( 'after_setup_theme', 'shortcodes_pro_thumbnail_support', 9999 );  

/*
|--------------------------------------------------------------------------
| SHORTCODES PRO MAIN CLASS INITIALIZE
|--------------------------------------------------------------------------
|
| Initializes the main Shortcodes Pro class.
|
*/

if (!function_exists('init_shortcodes_pro'))
{
	function init_shortcodes_pro()
	{
		new Shortcodes_Pro();
	}
	
	add_action('init', 'init_shortcodes_pro');
}

/*
|--------------------------------------------------------------------------
| SHORTCODES PRO ACTIVATION / DEACTIVATION
|--------------------------------------------------------------------------
*/

if ( !function_exists('shortcodes_pro_activation') )
{
	function shortcodes_pro_activation()
	{
		// check compatibility
		if ( version_compare( get_bloginfo('version' ),'3.0','<' ) ) 
		deactivate_plugins( basename( __FILE__ ) );
		
		// refresh cache
		delete_transient('sp.get.buttons');
		delete_transient('sp.get.buttons.main');
		delete_transient('sp.get.buttons.edit');		
	}
	
	register_activation_hook( __FILE__, 'shortcodes_pro_activation' );
}