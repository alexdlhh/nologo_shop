<?php
/**
* Shortcodes Pro Main Class
*
* @package Shortcodes Pro 
* @author Matt Varone
*/

if ( !class_exists('Shortcodes_Pro') )
{
	
	/* SHORTCODES PRO CLASS
	/////////////////////////////*/	
	class Shortcodes_Pro
	{	
		
		/* CLASS CONSTRUCTOR
		/////////////////////////////*/
	
		function Shortcodes_Pro()
		{
			
			if ( is_admin() )
			{
				
				$this->get_buttons();

				// Generate admin header
				add_action('admin_head', array(&$this, 'custom_plugin_header'));
				// Re-arrange options menu
				add_action('admin_init', array(&$this, 'arrange_menu'));
				// Modify plugin action links
				add_filter('plugin_action_links', array(&$this, 'set_settings_link'), 10, 2 );
				
				// TINY MCE BUTTONS
				if ( current_user_can('edit_posts') && 
					 current_user_can('edit_pages') && 
					 get_user_option('rich_editing') == 'true' )
				{
					
					add_filter('mce_external_plugins', array(&$this, 'add_plugins'));
					
					add_filter('mce_buttons',   array(&$this, 'register_buttons'),9999);
					add_filter('mce_buttons_2', array(&$this, 'register_buttons'),9999);
					add_filter('mce_buttons_3', array(&$this, 'register_buttons'),9999);
					add_filter('mce_buttons_4', array(&$this, 'register_buttons'),9999);
					
					add_filter('tiny_mce_version', array(&$this, 'refresh_mce_version'));
				}

			} 
			
		}
		
		function custom_plugin_header() 
		{
			?>
			<style type="text/css" media="screen">
				#toplevel_page_edit-post_type-shortcodepro div.wp-menu-image { background:transparent url("<?php echo SHORTCODES_PRO_URL.'/img/icon.jpg';?>") no-repeat center center;}
				#toplevel_page_edit-post_type-shortcodepro:hover div.wp-menu-image,
				#toplevel_page_edit-post_type-shortcodepro.wp-has-current-submenu div.wp-menu-image
				{ background:transparent url("<?php echo SHORTCODES_PRO_URL.'/img/icon-hover.jpg';?>") no-repeat center center; }	
			</style>
			<?php
		}
		
		function arrange_menu() 
		{	
			if (!empty($GLOBALS['menu']))
			{
				// Reverse menu array
				$menu = array_reverse($GLOBALS['menu'],true);
				$postype = 0;
				$options = 0;
				
				foreach ($menu as $pos => $vals) 
				{
					if ( $postype == 0 && $vals[0] == "Shortcodes" )
					$postype = $pos;
			
					if ( $options == 0 && $vals[0] == "Shortcodes Pro" )
					$options = $pos;

					if ( $postype > 0 && $options > 0)
					{
						// remove unwanted menu item
						unset($GLOBALS['menu'][$postype]);
						break;
					}
				} 
			}
		}
		
		function set_settings_link( $links, $file ) 
		{
			if ($file == SHORTCODES_PRO_BASENAME) 
			{	
				$add_link = '<a href="post-new.php?post_type=shortcodepro">' . __('Add') . '</a>';
				$settings_link = '<a href="options-general.php?page=shortcodes-pro/inc/shortcodespro-options.php">' . __('Settings') . '</a>';
				array_unshift( $links, $add_link, $settings_link );
			}
			
			return $links;
		}
		
		// Get all shortcodes with button=on
		function get_buttons()
		{
			
			$buttons = get_transient('sp.get.buttons.main');
			
			if ($buttons == "" OR empty($buttons)) 
			{
				
				for ($i=1; $i < 5; $i++) 
				{ 
						$args = array(
							'post_type' => 'shortcodepro',
							'posts_per_page' => -1,
							'post_status' => 'publish',
							'meta_query' => array(
								array(
									'key' => 'button',
									'value' => 'on',
								),
								array(
									'key' => 'row',
									'value' => 'row-'.$i,
								)
							),
							'orderby' => 'menu_order',
							'order'	=> 'ASC',
						 );


						$results =  new WP_Query( $args );
						
						if (is_object($results))
						{
							while ( $results->have_posts() ) : $results->the_post();
								
								$sep_after = get_post_meta($results->post->ID,'sep_after',true);
								
								if ( isset($sep_after) && $sep_after == 'yes' )
								$buttons['row-'.$i][] = array($results->post->post_name);
								else
								$buttons['row-'.$i][] = $results->post->post_name;
						
							endwhile;
						}

				}
				
				set_transient('sp.get.buttons.main',$buttons,3600); 
			
			}

			$this->buttons = $buttons;

		}

		
		function register_buttons($buttons) 
		{  
			
			$filter = current_filter();
					
			switch ($filter) 
			{
				
				case 'mce_buttons_2':
					$row = 'row-2';
				break;
				
				case 'mce_buttons_3':
					$row = 'row-3';
				break;
				
				case 'mce_buttons_4':
					$row = 'row-4';
				break;
				
				default:
					$row = 'row-1';
				break;
			}
									
			if (isset($this->buttons[$row]) && !empty($this->buttons[$row])) 
			{
				if ( $row != 'row-3' && $row != 'row-4' )
				array_push($buttons, 'separator');

				foreach ($this->buttons[$row] as $button)
				{

					if (is_array($button)) 
					{
						$safe_slug = $this->safe_slug($button[0]);
						array_push($buttons, $safe_slug);
						array_push($buttons, 'separator');
					} 
					else 
					{
						$safe_slug = $this->safe_slug($button);
						array_push($buttons, $safe_slug);
					}

				}

			}
									
			return $buttons;
	
		}
		
		function add_plugins($plugin_array) 
		{
			if (isset($this->buttons) && !empty($this->buttons)) 
			{				
				foreach ($this->buttons as $row)
				{
					foreach ($row as $buttons) 
					{
						if (is_array($buttons))
						$button_name = $buttons[0];	
						else
						$button_name = $buttons;	
			
						$safe_slug = str_replace('-','',$button_name);
						$plugin_array[$safe_slug] = plugins_url(SHORTCODES_PRO_FOLDER.'/inc/shortcodespro-edit-js.php');
					}
				} 			
			}
						
			return $plugin_array;
			
		}
		
		function refresh_mce_version($ver) 
		{
		  ++$ver;
		  return $ver;
		}
		
		function safe_slug($button)
		{
			return str_replace('-','',$button);
		}

	}		
}