<?php
/**
* Shortcodes Pro Edit JS
*
* @package Shortcodes Pro
* @author Matt Varone
*/

// set the correct header
header("Content-type: application/x-javascript");

// require wordpress
require_once('../../../../wp-load.php');

if (!defined('SHORTCODES_PRO_VERSION')) 
die('Shortcodes Pro error. Could not initialize WordPress');

$out = get_transient('sp.get.buttons.edit');

if ( $out == "" ) 
{
	// start the base class
	$sp_base = new ShortcodesPro_Base();

	// get all shortcode buttons
	$shortcodes = $sp_base->get_buttons();

	// check if we have shortcodes
	if (count($shortcodes) > 0) 
	{
		// start the output
		$out =  "(function() {\n";

		// loop trough each shortcode
		foreach ($shortcodes as $shortcode ) 
		{

			// create shortcode variables
			$shortcode_title  		= $shortcode->post_title;
			$shortcode_desc   		= get_post_meta($shortcode->ID,'desc',true);
			$shortcode_type   		= get_post_meta($shortcode->ID,'type',true);
			$shortcode_attributes	= get_post_meta($shortcode->ID,'attributes',true);
			$total_attributes		= get_post_meta($shortcode->ID,'totalattr',true);
			$shortcode_width_meta 	= get_post_meta($shortcode->ID,'width',true);
			$shortcode_height_meta 	= get_post_meta($shortcode->ID,'height',true);

			// create button title
			$button_title = ( $shortcode_desc ) ? $shortcode_title.': '.$shortcode_desc : $shortcode_title;

			// Verify shortcode with/height dimentions
			$shortcode_width  = ( (int)$shortcode_width_meta > 490 ) ? $shortcode_width_meta : 490;
			$shortcode_height = ( (int)$shortcode_height_meta > 300 ) ? $shortcode_height_meta : 300;

			// remove slashes from the slug
			$safe_slug = str_replace('-','',$shortcode->post_name);

			// verify the overlay is needed
			if ($shortcode_type == 'insert-custom-code') 
			{
				if ( $total_attributes == null OR (int)$total_attributes == 0 OR $shortcode_attributes != "on" )
				$shortcode_type = 'default';
			}
			
			// start this button output
			$out .= "tinymce.create('tinymce.plugins.".$safe_slug."', { init : function(ed, url) {
					ed.addButton('".$safe_slug."', { 
					title : '".$button_title."',\n";

			// check button image
			if ( function_exists('has_post_thumbnail') )
			{
				if (has_post_thumbnail($shortcode->ID)) 
				{
					$image_url = wp_get_attachment_image_src(get_post_thumbnail_id($shortcode->ID));  
					$out .= "image : '".$image_url[0]."',";
				}
			}

			// generate shortcode button behaviour 
			switch ($shortcode_type) 
			{
				//	INSERT CUSTOM CODE
				case 'insert-custom-code':
					$out .= "cmd: '".$safe_slug."',});\n";
					$out .= "ed.addCommand('".$safe_slug."', function() {
									ed.windowManager.open({
										file : url + '/shortcodespro-overlay.php?shortcode=".$shortcode->post_name."',
										width : ".$shortcode_width." + ed.getLang('".$safe_slug.".delta_width', 0),
										height : ".$shortcode_height." + ed.getLang('".$safe_slug.".delta_height', 0),
										inline : 1,
										scrollbars : 'yes',
									}, {
										plugin_url : url, 
										selection : ed.selection.getContent({format : 'raw'}),
									});
							});\n";
				break;

				//	WRAP CONTENT WITH
				default:
					$out .= "onclick : function() {  
						
						var sel = ed.selection.getContent({format : 'html'});
						var bm  = ed.selection.getBookmark();
						
						sel = sel.replace(/^\s+|\s+$/g, '');
						
						
						if ( sel.length > 0  ) 
						{
							var content = '[do action=\"".$shortcode->post_name."\"]' + sel + '[/do]';
							ed.execCommand('mceReplaceContent', false, content);
						} 
						else 
						{
							var content = '[do action=\"".$shortcode->post_name."\"/]';
					 		ed.selection.setContent('[do action=\"".$shortcode->post_name."\"/]');
						}
						
						ed.selection.moveToBookmark(bm);
						
						ed.save();
						
						}});\n";
				break;
			}

			// finish shortcode button declaration
			$out .= "ed.onNodeChange.add(function(ed, cm, n) {
			            	cm.setActive('".$safe_slug."', n.nodeName == 'IMG');
			            });
			        },
			        createControl : function(n, cm) {
			            return null;
			        },
			        getInfo : function() {
			            return {
			                longname : '".$shortcode_title."',
			                author : 'Shortcodes Pro',
			                authorurl : '".get_bloginfo('url')."',
			                infourl : 'http://codecanyon.net/item/shortcodes-pro-premium-plugin/178687?ref=sksmatt',
			                version : '".SHORTCODES_PRO_VERSION."'
			            };
			        }
			    });
			    tinymce.PluginManager.add('".$safe_slug."', tinymce.plugins.".$safe_slug.");\n";
		}

		// close js function
		$out .= "})();";
		
		set_transient('sp.get.buttons.edit',$out,3600);

		// echo the js content
		if ($out != "") echo $out;
	}
} else {
	echo $out;
}