/**
* Shortcodes Pro Sort JS
*
* @package Shortcodes Pro
* @author Matt Varone
*/

jQuery(document).ready(function($) 
{			
	// Sortable Rows
	
	var shortcodesRows = $('.target-row');
	shortcodesRows.each(function(){
		
		var data = $(this).attr('data');
		var	sortList = $(this);
		var loading = $('#loading-'+data);
		
		sortList.sortable({
			opacity: 0.6,
			helper: 'clone',
			placeholder: 'ui-state-highlight',
		}).bind('sortupdate',function (event,ui) {
			loading.show();
			$('#h3-'+data).addClass('update');
			opts = {
				url: ajaxurl,
				type: 'POST',
				async: true,
				cache: false,
				dataType: 'json',
				data:{
					action: 'shortcodespro_sort',
					order: sortList.sortable('toArray').toString()
				},	
				success: function(response) 
				{
					loading.hide();
					$('#h3-'+data).removeClass('update');
					return; 
				},
				error: function(xhr,textStatus,e) 
				{  
					alert('There was an error saving the updates: '+e);
					loading.hide();
					return; 
				}
			};
		
			$.ajax(opts);
			
		});
	});
	
	// Separator Draggable
	
	$( ".sep" ).draggable({
		connectToSortable: ".target-row",
		helper: "clone",
		revert: "invalid"
	});
	
	// Separator Remove
	
	$('.target-row #separator').live('dblclick',(function(){
		var parent = $(this).parent();
		
		$(this).fadeTo(200,0,function(){
			$(this).remove()
			parent.trigger('sortupdate');
			
		});
		
	}));

});