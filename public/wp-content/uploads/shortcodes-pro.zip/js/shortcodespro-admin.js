/**
* Shortcodes Pro Admin JS
*
* @package Shortcodes Pro
* @author Matt Varone
*/

jQuery(function() {

	var scp_class = '.shortcodespro-meta-box ';			// shortcodespro class
	var elements = [];									// behaviour elements
	var behavior_id = scp_class+'#type';				// behaviour dropdown id
	var attributes_id = scp_class+'#attributes';		// attributes checbox id
	var attributes_box = '#attributes-values';			// attributes panel id
	var attributes_row = scp_class+'.sscattributes';	// attributes row class
	var language_id = scp_class+'#language';			// language dropdown id
	var button_id = scp_class+'#button';
	var image_box = '#postimagediv';
	
	jQuery('#post_title').focus();
	
	// vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
	// BEHAVIOR DROPDOWN
	// vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
	
	// get all possible behaviour options
	jQuery(behavior_id + ' option').each(function() { 
	 elements.push( jQuery(this).attr('value') );
	});
	
	// check the behaviour dropdown
	jQuery(behavior_id).change(function(){
		// get the behaviour value
		var behaviour = jQuery(this).attr('value');
		// run the filter
		filterElements(behaviour);
	});	
	
	// run the filter as soon as page is loaded
	filterElements(jQuery(behavior_id).attr('value'));
	
	// vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
	// ATTRIBUTES CHECKBOX
	// vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
	
	// check the attributes checkbox
	jQuery(attributes_id).change(function(){
		// run the filter
		filterAttributes();
	});
	
	// run the filter as soon as page is loaded
	filterAttributes();
	
	// vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
	// CODE LANGUAGE DROPDOWN
	// vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
	
	// check the language dropdown
	jQuery(language_id).change(function(){
		// get the checkbox value
		var status = jQuery(attributes_id).attr('checked');
		// if checked filter the description with attributes
		if ( status === true ) 
		{
			// filter with attributes
			filterDesc(true);
		} else 
		{
			// filter descriptions
			filterDesc();
		}
	});
	
	filterAttributesTitle();
	
	// vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
	// CODE RICH EDITOR BUTTON DROPDOWN
	// vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv	
	
	filterRichEditorFields();
	
	jQuery('#button').change(function(){
		filterRichEditorFields();
	});
	
	// vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
	// ATTRIBUTES
	// vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
		
	jQuery('.add_attribute').live('click',
	function(){
			
			var slug   = jQuery('#att_name').val();
			var label  = jQuery('#att_label').val();
			var desc   = jQuery('#att_desc').val();
			var type   = jQuery('#att_type').val();
			var value  = jQuery('#att_value').val();
			var options = jQuery('#att_options').val();
			
			if ( slug.length < 1 || label.length < 1 || type.length < 1  || value.length < 1)
			{
				callForError();
				return false;
			}
			
			if ( type == "select" && options.length < 1 )
			{
				callForError();
				return false;
			}
			
			slug = stringToSlug(slug);
						
			var attribute = new Attribute(slug,label,desc,type,value,options);
			
			
			if ( jQuery('#att_slug_'+slug).length > 0 )
			{
				tb_remove();
				return false;
			}
			else 
			{
				addAttribute(attribute);
				filterAttributesTitle();
				tb_remove();
			}
	});
	
	jQuery('.update_attribute').live('click',
	function(){
						
			var old_slug = jQuery(this).attr("id").replace('att_','');
						
			var slug   = old_slug;
			var label  = jQuery('#att_label').val();
			var desc   = jQuery('#att_desc').val();
			var type   = jQuery('#att_type').val();
			var value  = jQuery('#att_value').val();
			var order  = jQuery('#att_order_'+old_slug).val();
			var options = jQuery('#att_options').val();
		;
						
			if (  label.length < 1 || type.length < 1 || value.length < 1 )
			{
				callForError();
				return false;
			}
			
			if ( type == "select" && options.length < 1 )
			{
				callForError();
				return false;
			}
						
			var attribute = new Attribute(slug,label,desc,type,value,options);
									
			updateAttribute(attribute,'#row_'+old_slug,order);
			
			tb_remove();
	});
	
	jQuery('.button.delete').live('click',
	function() {
		
			var answer = confirm("Delete this attribute?");
			if (answer) {
		
			var row = jQuery(this).parent().parent();
			var slug  = row.attr('id').replace('row_','');

			var attributes = jQuery('#attrvals').val();
			var attributes_a = attributes.replace('|%'+slug+'%','');
			
			jQuery('#attrvals').val(attributes_a);
			
			var total = jQuery('#totalattr').val();

			var c = parseFloat(total) - 1;
			jQuery('#totalattr').val(c);

			row.remove();
			
			filterAttributesTitle();
			
			} else {
				return false;
			}
			

	});
	
	jQuery('#att_type').live('change',
	function(){
		
			var selected = jQuery(this).val();
			filterOverlay(selected);
	});
	
	// vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
	// FUNCTIONS
	// vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv

	// filters the behaviour panels
	function filterElements(behaviour)
	{	
		// check if attributes panel is supported
		if ( behaviour !== 'insert-custom-code')
		{
			// hides attributes panel
			jQuery(attributes_box).hide(); 
			// disable the attribute checkbox after animation
			jQuery(attributes_row).stop().fadeTo(50, 0.5,function(){
				// disable checkbox
				jQuery(attributes_id).removeAttr('checked').attr('disabled', 'disabled');
				jQuery('.sscdesclong,.sscwidth,.sscheight').hide();
			});
		} else {
			// enable the attribute checkbox after animation
			jQuery(attributes_row).stop().fadeTo(50, 1,function(){
				// enable checkbox
				jQuery(attributes_id).removeAttr('disabled');
			});
		}
		
		// for each behaviour panel
		jQuery.each(elements, function(index, value) { 
			// if behaviour is selected
			if ( value === behaviour ) {
				// show behaviour panel
				jQuery('#'+value).show();
			} else {
				// hide behaviour panel
				jQuery('#'+value).hide();
			}
		});
	}
	
	function FormatNumberLength(num, length) {
	    var r = "" + num;
	    while (r.length < length) {
	        r = "0" + r;
	    }
	    return r;
	}
	
	// filters the attributes panels
	function filterAttributes()
	{
		// get the status of the checkbox
		var status = jQuery(attributes_id).attr('checked');

		// check if the status is true
		if ( status === true ) {
			// show attributes panel
			jQuery(attributes_box).show(); 
			
			if ( jQuery('#button').is(':checked') ) {
			jQuery('.sscdesclong,.sscwidth,.sscheight').show(); }
			// filter descriptions to show attributes
			filterDesc(true);
		} else {
			// hide attributes panel
			jQuery(attributes_box).hide(); 
			jQuery('.sscdesclong,.sscwidth,.sscheight').hide(); 
			// filter the description to hide attributes
			filterDesc();
		}
	}
	
	// filters the description panels
	function filterDesc(showAttributes)
	{
		// get the language dropdown value
		var language = jQuery(language_id).attr('value');
		
		switch ( language )
		{
			case 'php':
				jQuery('.sscinsert-php').show();
				jQuery('.sscinsert-css,.sscinsert-html').hide();
			break;
			
			case 'html':
				jQuery('.sscinsert-html').show();
				jQuery('.sscinsert-css,.sscinsert-php').hide();
			break;
			
			case 'css':
				jQuery('.sscinsert-css').show();
				jQuery('.sscinsert-html,.sscinsert-php').hide();
			break;
		} 
			
		if ( showAttributes === true) {
			// show attributes description
			jQuery(scp_class+'.attributes-desc').show(); 
		} else {
			// attributes not enabled
			jQuery(scp_class+'.attributes-desc').hide(); // hide attributes description
		}

	}
	
	function filterAttributesTitle()
	{
		var titles = jQuery('.scp-attributes-header');
		var total = jQuery('#totalattr').val();
				
		if ( total > 0 ) {
			titles.show();
		} else { 
			titles.hide();
		}
	}
	
	function filterRichEditorFields()
	{
		var fields = ".sscrowbutton,.sscdesc";
		var fields_atr = fields + ',.sscdesc,.sscdesclong,.sscwidth,.sscheight';
		
		if (jQuery('#button').is(':checked'))
		{
			
			if ( jQuery('#attributes').is(':checked') ) {
				jQuery(fields_atr).show();
			} else {
				jQuery(fields).show();
			}
			
		} else {
			jQuery(fields_atr).hide();
		}
	}
	
	function filterOverlay(selection)
	{
		if(selection=="select")
		{
			jQuery('.sscatt_options').show();
		} else {
			jQuery('.sscatt_options').hide();
		}
	}
	
	function Attribute(slug,label,desc,type,value,options)
	{
		this.slug = slug;
		this.label = label;
		this.desc = desc;
		this.type = type;
		this.value = value;
		this.options = options;		
	}
	
	function addAttribute(attribute)
	{
		
		var attributes = jQuery('#attrvals').val();
				
		var total = jQuery('#totalattr').val();
		var last = jQuery('#lastattr').val();
				
		var c = parseFloat(total) + 1;
		var l = parseFloat(last) + 1;
		
		var hidden = '<input type="hidden" name="att_desc_'+attribute.slug+'" value="'+attribute.desc+'" id="att_desc_'+attribute.slug+'"/><input type="hidden" name="att_type_'+attribute.slug+'" value="'+attribute.type+'" id="att_type_'+attribute.slug+'"/><input type="hidden" name="att_value_'+attribute.slug+'" value="'+attribute.value+'" id="att_value_'+attribute.slug+'"/><input type="hidden" name="att_options_'+attribute.slug+'" value="'+attribute.options+'" id="att_options_'+attribute.slug+'"/>';
				
		var prepend = '<tr class="sscrow" id="row_'+attribute.slug+'"><td width="25%"><input type="text" name="att_order_'+attribute.slug+'" id="att_order_'+attribute.slug+'" value="'+l+'" size="4" ></td><td width="25%"><input type="text" name="att_slug_'+attribute.slug+'" id="att_slug_'+attribute.slug+'" value="'+attribute.slug+'"readonly="readonly"></td><td width="25%"><input type="text" name="att_label_'+attribute.slug+'" id="att_label_'+attribute.slug+'" value="'+attribute.label+'"readonly="readonly"></td><td width="25%"><a title="Edit Attribute" class="edit button thickbox" href="admin-ajax.php?action=scpeditattribute&width=640&id='+attribute.slug+'">Edit</a> <a title="Delete Attribute" class="delete button" href="#">Delete</a>'+hidden+'</td></tr>';
				
		jQuery('.sscadd-new-attributed').before(prepend);
		
		jQuery('#totalattr').val(c);
		jQuery('#lastattr').val(l);
		jQuery('#attrvals').val(attributes+'|%'+attribute.slug+'%');
		
	}
	
	function updateAttribute(attribute,row,order)
	{
		var hidden = '<input type="hidden" name="att_desc_'+attribute.slug+'" value="'+attribute.desc+'" id="att_desc_'+attribute.slug+'"/><input type="hidden" name="att_type_'+attribute.slug+'" value="'+attribute.type+'" id="att_type_'+attribute.slug+'"/><input type="hidden" name="att_value_'+attribute.slug+'" value="'+attribute.value+'" id="att_value_'+attribute.slug+'"/><input type="hidden" name="att_options_'+attribute.slug+'" value="'+attribute.options+'" id="att_options_'+attribute.slug+'"/>';
		
		var prepend = '<tr class="sscrow" id="row_'+attribute.slug+'"><td width="25%"><input type="text" name="att_order_'+attribute.slug+'" id="att_order_'+attribute.slug+'" value="'+order+'" size="3"></td><td width="25%"><input type="text" name="att_slug_'+attribute.slug+'" id="att_slug_'+attribute.slug+'" value="'+attribute.slug+'"readonly="readonly"></td><td width="25%"><input type="text" name="att_label_'+attribute.slug+'" id="att_label_'+attribute.slug+'" value="'+attribute.label+'"readonly="readonly"></td><td width="25%"><a title="Edit Attribute" class="edit button thickbox" href="admin-ajax.php?action=scpeditattribute&width=640&id='+attribute.slug+'">Edit</a> <a title="Delete Attribute" class="delete button" href="#">Delete</a>'+hidden+'</td></tr>';

		jQuery(row).replaceWith(prepend);
		
	}
	
	function callForError()
	{
		jQuery('#errors').html('Please complete all required fields (*).');
	}
	
	function stringToSlug(str) {
	  str = str.replace(/^\s+|\s+$/g, '');
	  str = str.toLowerCase();

	  var from = "àáäâèéëêìíïîòóöôùúüûñç·/_,:;";
	  var to   = "aaaaeeeeiiiioooouuuunc------";
	  for (var i=0, l=from.length ; i<l ; i++) {
	    str = str.replace(new RegExp(from.charAt(i), 'g'), to.charAt(i));
	  }

	  str = str.replace(/[^a-z0-9]/g, '')
	    .replace(/\s+/g, '')
	    .replace(/-+/g, '');

	  return str;
	}
	
});