=== PHP MyVideoBlog Pro ===
Contributors: jotabiz 
Tags: autoblog, automatic, youtube, video blog
Requires at least: 2.6
Tested up to: 3.0.1
Stable tag: 3.2

== Description ==

Creates video blog with auto updates. The Plugin will crate posts with embed code of videos from several sources using your own keywords.

== Installation ==

Extract the zip file and just drop the "myvideoblog" directory in the wp-content/plugins/ directory of your WordPress installation and then activate the Plugin from Plugins page.
Read the pdf Instalation Guide for more details.
Support - Forum: http://www.phpmyvideoblog.com/forum