<?php
if ($videohost == "youtube.com") {
if ($jwplayer == "yes") {$embedcode = player_youtube_jwp($vidcod,$pwsize,$phsize,$siteurl);} else {$embedcode = player_youtube($vidcod,$pwsize,$phsize);}
}
else if ($videohost == "dailymotion.com") {
$embedcode = player_dailymotion($vidcod,$pwsize,$phsize);
}
else if ($videohost == "kewego.com") {
$embedcode = player_kewego($vidcod,$pwsize,$phsize);
}
else if ($videohost == "metacafe.com") {
$embedcode = player_metacafe($vidcod,$pwsize,$phsize);
}
else if ($videohost == "viddler.com") {
$embedcode = player_viddler($vidcod,$pwsize,$phsize);
}
else if ($videohost == "sevenload.com") {
$embedcode = player_sevenload($vidcod,$pwsize,$phsize);
}
else if ($videohost == "shufuni.com") {
$embedcode = player_shufuni($vidcod,$pwsize,$phsize);
}
else if ($videohost == "pornhub.com") {
$embedcode = player_pornhub($vidcod,$pwsize,$phsize);
}
else if ($videohost == "xvideos.com") {
$embedcode = player_xvideos($vidcod,$pwsize,$phsize);
}
else if ($videohost == "video.yahoo.com") {
$embedcode = player_yahoo($vidcod,$pwsize,$phsize);
}
else if ($videohost == "redtube.com") {
$embedcode = player_redtube($vidcod,$pwsize,$phsize);
}
else if ($videohost == "break.com") {
$embedcode = player_break($vidcod,$pwsize,$phsize);
}
else if ($videohost == "keezmovies.com") {
$embedcode = player_keezmovies($vidcod,$pwsize,$phsize);
}
else if ($videohost == "megaporn.com") {
$embedcode = player_megaporn($vidcod,$pwsize,$phsize);
}
else if ($videohost == "megavideo.com") {
$embedcode = player_megavideo($vidcod,$pwsize,$phsize);
}
else if ($videohost == "deviantclip.com") {
$embedcode = player_deviantclip($vidcod,$pwsize,$phsize);
}
else if ($videohost == "hulu.com") {
$embedcode = player_hulu($vidcod,$pwsize,$phsize);
}
else if ($videohost == "globo.com") {
$embedcode = player_globo($vidcod,$pwsize,$phsize);
}
else if ($videohost == "hardsextube.com") {
$embedcode = player_hardsextube($vidcod,$pwsize,$phsize);
}
else if ($videohost == "eporner.com") {
$embedcode = player_eporner($vidcod,$pwsize,$phsize);
}
else if ($videohost == "extremetube.com") {
$embedcode = player_extremetube($vidcod,$pwsize,$phsize);
}
?>