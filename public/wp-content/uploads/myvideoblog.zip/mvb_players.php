<?php
function player_youtube($vidcod,$pwsize,$phsize) {
$embedcode = '<object type="application/x-shockwave-flash" width="'.$pwsize.'" height="'.$phsize.'" data="http://www.youtube.com/v/'.$vidcod.'&fs=1&rel=0&iv_load_policy=3&ap=%2526fmt%3D22&ap=%2526fmt%3D18"><param name="movie" value="http://www.youtube.com/v/'.$vidcod.'&fs=1&rel=0&iv_load_policy=3&ap=%2526fmt%3D22&ap=%2526fmt%3D18" /><param name="allowFullScreen" value="true" /><param name="wmode" value="opaque"></param></object>';
return $embedcode;
}
function player_youtube_jwp($vidcod,$pwsize,$phsize,$siteurl) {
$embedcode = '<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" width="'.$pwsize.'" height="'.$phsize.'" id="single1" name="single1"><param name="movie" value="'.$siteurl.'/player.swf"><param name="allowfullscreen" value="true"><param name="allowscriptaccess" value="always"><param name="wmode" value="transparent"><param name="flashvars" value="file=http://www.youtube.com/watch?v='.$vidcod.'&backcolor=000000&frontcolor=FFFFFF"><embed id="single2" name="single2" src="'.$siteurl.'/player.swf" width="'.$pwsize.'" height="'.$phsize.'" bgcolor="#000000" allowscriptaccess="always" allowfullscreen="true" flashvars="file=http://www.youtube.com/watch?v='.$vidcod.'&backcolor=000000&frontcolor=FFFFFF"/></object>';
return $embedcode;
}
function player_dailymotion($vidcod,$pwsize,$phsize) {
$embedcode = '<object type="application/x-shockwave-flash" width="'.$pwsize.'" height="'.$phsize.'" data="http://www.dailymotion.com/swf/'.$vidcod.'"><param name="movie" value="http://www.dailymotion.com/swf/'.$vidcod.'" /><param name="allowFullScreen" value="true"></param><param name="wmode" value="opaque"></param></object>';
return $embedcode;
}
function player_kewego($vidcod,$pwsize,$phsize) {
$embedcode = '<object name="'.$vidcod.'" id="'.$vidcod.'" type="application/x-shockwave-flash" data="http://sa.kewego.com/swf/p3/epix.swf" width="'.$pwsize.'" height="'.$phsize.'"><param name="flashVars" value="language_code=en&playerKey=902e0deec887&skinKey=71703ed5cea1&sig='.$vidcod.'&autostart=false" /><param name="wmode" value="opaque"><param name="movie" value="http://sa.kewego.com/swf/p3/epix.swf" /><param name="allowFullScreen" value="true" /><param name="allowscriptaccess" value="always" /></object>';
return $embedcode;
}
function player_metacafe($vidcod,$pwsize,$phsize) {
$embedcode = '<object type="application/x-shockwave-flash" data="http://www.metacafe.com/fplayer/'.$vidcod.'/video.swf" width="'.$pwsize.'" height="'.$phsize.'"><param name="movie" value="http://www.metacafe.com/fplayer/'.$vidcod.'/video.swf" /><param name="AllowFullscreen" value="true" /><param name="wmode" value="opaque"></param></object>';
return $embedcode;
}
function player_viddler($vidcod,$pwsize,$phsize) {
$embedcode = '<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" width="'.$pwsize.'" height="'.$phsize.'" id="viddlerplayer-'.$vidcod.'">
  <param name="movie" value="http://www.viddler.com/simple/'.$vidcod.'/" /> 
  <param name="allowScriptAccess" value="always" /> 
  <param name="wmode" value="transparent" /> 
  <param name="allowFullScreen" value="true" /> 
  <embed src="http://www.viddler.com/simple/'.$vidcod.'/" width="'.$pwsize.'" height="'.$phsize.'" type="application/x-shockwave-flash" wmode="transparent" allowScriptAccess="always" allowFullScreen="true" name="viddlerplayer-'.$vidcod.'" /> 
  </object>';
return $embedcode;
}
function player_sevenload($vidcod,$pwsize,$phsize) {
$embedcode = '<object type="application/x-shockwave-flash" data="http://en.sevenload.com/pl/'.$vidcod.'/400x333/swf" width="'.$pwsize.'" height="'.$phsize.'"><param name="allowFullscreen" value="true" /><param name="allowScriptAccess" value="always" /><param name="movie" value="http://en.sevenload.com/pl/'.$vidcod.'/400x333/swf" /></object>';
return $embedcode;
}
function player_shufuni($vidcod,$pwsize,$phsize) {
$embedcode = '<object width="'.$pwsize.'" height="'.$phsize.'"><param name="movie" value="http://www.shufuni.com/Flash/flvplayer_0109.swf" flashvars="VideoCode='.$vidcod.'"></param><param name="allowFullScreen" value="true"><param name="allowScriptAccess" value="always" /><embed src="http://www.shufuni.com/Flash/flvplayer_0109.swf" type="application/x-shockwave-flash" width="'.$pwsize.'" height="'.$phsize.'" allowFullScreen="true" allowScriptAccess="always" flashvars="videoCode='.$vidcod.'"></embed></object>';
return $embedcode;
}
function player_pornhub($vidcod,$pwsize,$phsize) {
$embedcode = '<object type="application/x-shockwave-flash" data="http://ph-static.phncdn.com/flash/embed_player_v1.3.swf" width="'.$pwsize.'" height="'.$phsize.'"><param name="movie" value="http://ph-static.phncdn.com/flash/embed_player_v1.3.swf" /><param name="bgColor" value="#000000" /><param name="allowfullscreen" value="true" /><param name="allowScriptAccess" value="always" /><param name="FlashVars" value="options=http://www.pornhub.com/embed_player.php?id='.$vidcod.'"/></object>';
return $embedcode;
}
function player_xvideos($vidcod,$pwsize,$phsize) {
$embedcode = '<object width="'.$pwsize.'" height="'.$phsize.'" classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=8,0,0,0" ><param name="quality" value="high" /><param name="bgcolor" value="#000000" /><param name="allowScriptAccess" value="always" /><param name="movie" value="http://www.xvideos.com/sitevideos/flv_player_site_v4.swf" /><param name="allowFullScreen" value="true" /><param name="flashvars" value="id_video='.$vidcod.'" /><embed src="http://www.xvideos.com/sitevideos/flv_player_site_v4.swf" allowscriptaccess="always" width="'.$pwsize.'" height="'.$phsize.'" menu="false" quality="high" bgcolor="#000000" allowfullscreen="true" flashvars="id_video='.$vidcod.'" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" /></object>';
return $embedcode;
}
function player_yahoo($vidcod,$pwsize,$phsize) {
$embedcode = '<object width="'.$pwsize.'" height="'.$phsize.'"><param name="movie" value="http://d.yimg.com/static.video.yahoo.com/yep/YV_YEP.swf?ver=2.2.40" /><param name="allowFullScreen" value="true" /><param name="AllowScriptAccess" VALUE="always" /><param name="bgcolor" value="#000000" /><param name="flashVars" value="'.$vidcod.'" /><embed src="http://d.yimg.com/static.video.yahoo.com/yep/YV_YEP.swf?ver=2.2.40" type="application/x-shockwave-flash" width="'.$pwsize.'" height="'.$phsize.'" allowFullScreen="true" AllowScriptAccess="always" bgcolor="#000000" flashVars="'.$vidcod.'" ></embed></object>';
return $embedcode;
}
function player_redtube($vidcod,$pwsize,$phsize) {
$embedcode = '<object type="application/x-shockwave-flash" data="http://embed.redtube.com/player/?id='.$vidcod.'&style=redtube" width="'.$pwsize.'" height="'.$phsize.'"><param name="movie" value="http://embed.redtube.com/player/?id='.$vidcod.'&style=redtube" /><param name="allowFullScreen" value="true" /><param name="wmode" value="opaque" /></object>';
return $embedcode;
}
function player_break($vidcod,$pwsize,$phsize) {
$embedcode = '<object type="application/x-shockwave-flash" data="http://embed.break.com/'.$vidcod.'" width="'.$pwsize.'" height="'.$phsize.'"><param name="movie" value="http://embed.break.com/'.$vidcod.'" /><param name="AllowFullscreen" value="true" /><param name="wmode" value="opaque" /></object>';
return $embedcode;
}
function player_deviantclip($vidcod,$pwsize,$phsize) {
$embedcode = '<embed src="http://www.deviantclip.com/flashplayer/flvplayer.swf" width="'.$pwsize.'" height="'.$phsize.'" menu="false" quality="high" bgcolor="#ffffff" wmode="transparent" allowfullscreen="true" allowscriptaccess="always" flashvars="enablejs=true&autostart=false&mediaid='.$vidcod.'&displayclick=link&linktarget=_blank&backcolor=0xcd9b8d&frontcolor=0xebdbd4&lightcolor=0xffffff&streamer=lighttpd" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" />';
return $embedcode;
}
function player_keezmovies($vidcod,$pwsize,$phsize) {
$embedcode = '<object type="application/x-shockwave-flash" data="http://www.keezmovies.com/cdn_files/flash/player_embed.swf" width="'.$pwsize.'" height="'.$phsize.'"><param name="movie" value="http://www.keezmovies.com/cdn_files/flash/player_embed.swf" /><param name="bgColor" value="#000000" /><param name="allowfullscreen" value="true" /><param name="allowScriptAccess" value="always" /><param name="FlashVars" value="options=http://www.keezmovies.com/embed_player.php?id='.$vidcod.'"/></object>';
return $embedcode;
}
function player_megaporn($vidcod,$pwsize,$phsize) {
$embedcode = '<object type="application/x-shockwave-flash" data="http://www.megaporn.com/e/'.$vidcod.'" width="'.$pwsize.'" height="'.$phsize.'"><param name="movie" value="http://www.megaporn.com/e/'.$vidcod.'" /><param name="allowFullScreen" value="true" /><param name="wmode" value="opaque" /></object>';
return $embedcode;
}
function player_megavideo($vidcod,$pwsize,$phsize) {
$embedcode = '<object width="'.$pwsize.'" height="'.$phsize.'"><param name="movie" value="http://www.megavideo.com/v/'.$vidcod.'"></param><param name="allowFullScreen" value="true"></param><embed src="http://www.megavideo.com/v/'.$vidcod.'" type="application/x-shockwave-flash" allowfullscreen="true" width="'.$pwsize.'" height="'.$phsize.'"></embed></object>';
return $embedcode;
}
function player_globo($vidcod,$pwsize,$phsize) {
$embedcode = '<object width="'.$pwsize.'" height="'.$phsize.'"><param value="http://video.globo.com/Portal/videos/cda/player/player.swf" name="movie" /><param value="high" name="quality" /><param value="midiaId='.$vidcod.'&autoStart=false&width='.$pwsize.'&height='.$phsize.'" name="FlashVars" /><embed width="'.$pwsize.'" height="'.$phsize.'" flashvars="midiaId='.$vidcod.'&autoStart=false&width='.$pwsize.'&height='.$phsize.'" type="application/x-shockwave-flash" quality="high" src="http://video.globo.com/Portal/videos/cda/player/player.swf"></embed></object>';
return $embedcode;
}
function player_hulu($vidcod,$pwsize,$phsize) {
$embedcode = '<object width="'.$pwsize.'" height="'.$phsize.'"><param name="movie" value="http://www.hulu.com/embed/EQNyF-b6_Tqxpc2U_WORSw"></param><param name="allowFullScreen" value="true"></param><embed src="http://www.hulu.com/embed/'.$vidcod.'" type="application/x-shockwave-flash"  width="'.$pwsize.'" height="'.$phsize.'" allowFullScreen="true"></embed></object>';
return $embedcode;
}
function player_hardsextube($vidcod,$pwsize,$phsize) {
$embedcode = '<object width="'.$pwsize.'" height="'.$phsize.'"> <param name="movie" value="http://www.hardsextube.com/embed/'.$vidcod.'/"></param><param name="AllowScriptAccess" value="always"></param><param name="wmode" value="transparent"></param><embed src="http://www.hardsextube.com/embed/'.$vidcod.'/" type="application/x-shockwave-flash" wmode="transparent" AllowScriptAccess="always" width="'.$pwsize.'" height="'.$phsize.'"></embed></object>';
return $embedcode;
}
function player_eporner($vidcod,$pwsize,$phsize) {
$embedcode = '<object width="'.$pwsize.'" height="'.$phsize.'"><param name="movie" value="http://www.eporner.com/player/'.$vidcod.'"></param><param name="allowscriptaccess" value="always"></param><embed src="http://www.eporner.com/player/'.$vidcod.'" type="application/x-shockwave-flash" allowscriptaccess="always" width="'.$pwsize.'" height="'.$phsize.'"></embed></object>';
return $embedcode;
}
function player_extremetube($vidcod,$pwsize,$phsize) {
$embedcode = '<object type="application/x-shockwave-flash" data="http://xt-static.phncdn.com/flash/player_embed.swf" width="'.$pwsize.'" height="'.$phsize.'"><param name="movie" value="http://xt-static.phncdn.com/flash/player_embed.swf" /><param name="bgColor" value="#000000" /><param name="allowfullscreen" value="true" /><param name="allowScriptAccess" value="always" /><param name="FlashVars" value="options=http://www.extremetube.com/embed_player.php?id='.$vidcod.'"/></object>';
return $embedcode;
}
?>