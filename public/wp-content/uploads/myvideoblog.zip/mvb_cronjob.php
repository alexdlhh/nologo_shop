<?php
require_once(ABSPATH . 'wp-content/plugins/myvideoblog/mvb_functions.php');
$siteurl = get_option('siteurl');
$getkey = get_option('mvb_securitykey');
$default_cronfile = ABSPATH . 'wp-content/plugins/myvideoblog/mvb_cronserver.php';
$my_cronfile = ABSPATH . ''.$getkey.'.php';
if (!file_exists($my_cronfile)) {
@rename($default_cronfile, $my_cronfile);
}
?>
<div class=wrap>
<table width="100%"><tr><td>
<a href="http://www.phpmyvideoblog.com" target="_blank" title="PHPMyVideoBlog.com"><img src="<?php echo $siteurl?>/wp-content/plugins/myvideoblog/includes/mvb.gif" border="0" alt="PHPMyVideoBlog.com"></a>
</td><td>
[<a href="admin.php?page=myvideoblog/mvb_main.php">My Video Sources</a>]
[<a href="admin.php?page=MVB_Add_New_Feed">Add New Video Source</a>]
[<a href="admin.php?page=MVB_Settings">MVB Settings</a>]
[<a href="admin.php?page=MVB_Auto-Updates_Settings">Auto-Updates Settings</a>]
</td></tr></table>
<?php
if ($_REQUEST['action'] == "savecron") {
	if(!empty($_REQUEST['mvbcron_stop'])) {
		$timestamp = wp_next_scheduled('mvbcron_hook', array("mail_to" => get_option("mvbcron_mail")));
		/* This is where the event gets unscheduled */
		update_option("mvbcron_triggercount", "0");
		wp_unschedule_event($timestamp, "mvbcron_hook", array("mail_to" => get_option("mvbcron_mail")));
		delete_option("mvbcron_mail");
		delete_option("mvbcron_seconds");
		delete_option("mvbcron_triggercount");
	}
	if(!empty($_REQUEST['mvbcron_mail'])) {
		update_option("mvbcron_mail",$_REQUEST['mvbcron_mail']);
	}
	if(!empty($_REQUEST['mvbcron_seconds'])) {
		update_option("mvbcron_seconds",$_REQUEST['mvbcron_seconds']);
		/* This is where the actual recurring event is scheduled */
		if (!wp_next_scheduled('mvbcron_hook', array("mail_to" => get_option("mvbcron_mail")))) {
		$cron_time = $_REQUEST['mvbcron_style'];
		$cron_custom = $_REQUEST['mvbcron_cs'];
		wp_schedule_event(time()+$_REQUEST['mvbcron_seconds'], $cron_time, 'mvbcron_hook', array("mail_to" => get_option("mvbcron_mail")));
		}
	}
}

if ($_REQUEST['action'] == "createnewsk") {
$mynewsk = newsk();
$myoldsk = $_REQUEST['oldsk'];
update_option('mvb_securitykey', $mynewsk);
$cronfile = ABSPATH . 'wp-content/plugins/myvideoblog/mvb_cronserver.php';
$oldcronfile = ABSPATH . ''.$myoldsk.'.php';
$newcronfile = ABSPATH . ''.$mynewsk.'.php';
if (file_exists($oldcronfile)) {
rename($oldcronfile, $newcronfile);
echo "<br><center><font color=\"green\">NEW SECURITY KEY CREATED</font></center>";
} else if (file_exists($cronfile)) {
rename($cronfile, $newcronfile);
echo "<br><center><font color=\"green\">NEW SECURITY KEY CREATED</font></center>";
}

}
$mysk = get_option('mvb_securitykey');
$mycronmail = get_option('mvbcron_mail');
?>

<h2>Auto-Updates</h2>
<br>
<table class="widefat" cellspacing="0" style="width:60%">
<thead>
<th>
Via Wordpress Schedule
</th>
</thead>
<tr><td bgcolor="#E4F2FD" style="border-bottom-width:0px;">
MVB will run the updater when someone access your site.<br>
<form action="<?php echo $_SERVER["REQUEST_URI"]; ?>" method="post" name="cronform">
<input type="hidden" name="action" value="savecron">
<?php
if (wp_next_scheduled('mvbcron_hook', array("mail_to" => get_option("mvbcron_mail")))) {
?>
<p><b>Wordpress Schedule: <font color="green">Active.</font></b></b>
<?php
$crons = _get_cron_array();
			 foreach ( $crons as $timestamp => $cron ) {
				 if ( isset( $cron['mvbcron_hook'] ) ) {
					$timenow = date(get_option('date_format'));
					$timenow2 = date("H:i:s");
					echo "<br>Time now (server): $timenow $timenow2<br />";
					$triggered = date(get_option('date_format'),$timestamp);
					$triggered2 = date("H:i:s",$timestamp);
					echo "Next update: $triggered $triggered2<br />";
				 }
			 }
?>
<?php
if(get_option("mvbcron_triggercount") > 0) {
$totalupdates = get_option("mvbcron_triggercount");
echo "Total of updates: $totalupdates<br />";
}
?>
<form method="post" action="<?php echo $_SERVER["REQUEST_URI"]; ?>">
<input type="submit" name="mvbcron_stop" id="mvbcron_stop" class="button" value="Deactivate Wordpress Schedule" />
</form>
<?php
}
?>
<?php
if (!wp_next_scheduled('mvbcron_hook', array("mail_to" => get_option("mvbcron_mail")))) {
?>
<p><b>Wordpress Schedule: <font color="red">Inactive.</font></b></p>
Notification Email*:<br>
<input type="text" name="mvbcron_mail" size="50" value="">
<br><font size="1">* Leave blank to not receive notification email.</font><br><br>
Run cron: <select name="mvbcron_style">
<!--Run cron: <select name="mvbcron_style" onchange="customize_cron(this.value)">-->
<option value="daily">Daily</option>
<option value="twicedaily">Twice Daily</option>
<option value="once_half_hour">Once Half an Hour</option>
<option value="hourly">Hourly</option>
<option value="once_two_hour">Once Two Hours</option>
<option value="once_three_hour">Once Three Hours</option>
<option value="weekly">Weekly</option>
<!--<option value="custom_crontime">* Customize:</option>-->
</select>
<!--<br>Run cron every <input type="text" name="mvbcron_cs" id="mvbcron_cs" size="12" value="86400" disabled> seconds.-->
<br>
Seconds from now until this schedule should be started:<br>
<input type="text" name="mvbcron_seconds" size="10" value="10">
<br><br>
<input type="submit" name="submit" class="button-primary" value="Activate Wordpress Schedule">
</form>
<?php
}
?>
</td></tr></table>
<br>
<table class="widefat" cellspacing="0" style="width:60%">
<thead>
<th>
Via Server CronJobs
</th>
</thead>
<tr><td bgcolor="#E4F2FD" style="border-bottom-width:0px;">
Recommended. For advanced users only!<br><br>
This is the page that you need to create the cron:<br>
<?php
$cronfile = ABSPATH . ''.$mysk.'.php';
echo "<b>$cronfile</b>";
?>
<br><br>
<?php
$cronfile = ABSPATH . ''.$mysk.'.php';
if (!file_exists($cronfile)) {
echo "<font color=\"red\"><b>ATTENTION!</b><br>MVB could not create the cron file or file was not found!</font><br>You need to rename the file \"mvb_cronserver.php\" to \"$mysk.php\" and upload it to the main directory of your wordpress.";
}
?>
</td></tr></table>
<br>
<table class="widefat" cellspacing="0" style="width:60%">
<thead>
<th>
Security Key
</th>
</thead>
<tr><td bgcolor="#E4F2FD" style="border-bottom-width:0px;">
For security reasons, we need a key to prevent attacks.<br>
<b>Your current SK is: 
<?php
echo $mysk;
?>
</b><br><br>
To change your SK, just click the button below.
<br>
If you are using "Server CronJob", you will need to change your cronjob settings at your server panel.<br>
<br>
<form action="<?php echo $_SERVER["REQUEST_URI"]; ?>" method="post" name="myform">
<input type="hidden" name="action" value="createnewsk">
<input type="hidden" name="oldsk" value="<?php echo $mysk;?>">
<input type="submit" name="submit" class="button-primary" value="Generate a new security key">
</form>
</td></tr></table>
</div>
<?php
MyVideoBlog_showfooter();
?>