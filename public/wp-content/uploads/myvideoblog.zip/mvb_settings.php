<?php
require_once(ABSPATH . 'wp-content/plugins/myvideoblog/mvb_functions.php');
$siteurl = get_bloginfo('wpurl');
?>
<div class="wrap">
<table width="100%"><tr><td>
<a href="http://www.phpmyvideoblog.com" target="_blank" title="PHPMyVideoBlog.com"><img src="<?php echo $siteurl?>/wp-content/plugins/myvideoblog/includes/mvb.gif" border="0" alt="PHPMyVideoBlog.com"></a>
</td><td>
[<a href="admin.php?page=myvideoblog/mvb_main.php">My Video Sources</a>]
[<a href="admin.php?page=MVB_Add_New_Feed">Add New Video Source</a>]
[<a href="admin.php?page=MVB_Settings">MVB Settings</a>]
[<a href="admin.php?page=MVB_Auto-Updates_Settings">Auto-Updates Settings</a>]
</td></tr></table>

<?php
if($_REQUEST['action'] == "rebuild") {
$mytemplate = get_option('mvb_posttemplate');
$mytemplate = stripslashes($mytemplate);
$copyimages = get_option('mvb_copyimages');
$removeurls = get_option('mvb_removeurls');
$descsize = get_option('mvb_descsize');
$imglib = get_option('mvb_imglib');
$pwsize = get_option('mvb_pwsize');
$phsize = get_option('mvb_phsize');
$utf8_active = get_option('mvb_utf8_active');
$customfield_thumb = get_option('mvb_customfield_thumb');
$customfield_desc = get_option('mvb_customfield_desc');
$customfield_vid = get_option('mvb_customfield_vid');
$customfield_vidsource = get_option('mvb_customfield_vidsource');
$thumbs_dir = get_option('mvb_thumbs_dir');
$theme_setting = get_option('mvb_theme_setting');
$jwplayer = get_option('mvb_jwplayer');
$customfield_vidembed = get_option('mvb_customfield_vidembed');
$customfield_vidtime = get_option('mvb_customfield_vidtime');

$step = $_REQUEST['step'];
$getposts = $wpdb->get_results("SELECT ID, post_content, post_title, guid FROM ".$wpdb->prefix."posts WHERE post_type = 'post' ORDER BY ID DESC");
$total_results = $wpdb->num_rows;
$per_step = 500;
$steps = ceil($total_results / $per_step);
if(!isset($step)) { $step = 0; }
$start = $step * $per_step;
$getposts = $wpdb->get_results("SELECT ID, post_content, post_title, guid FROM ".$wpdb->prefix."posts WHERE post_type = 'post' ORDER BY ID DESC LIMIT ".$start.", ".$per_step."");

foreach ($getposts as $postinfo) {
$the_post_id = $postinfo->ID;
$the_post_content = $postinfo->post_content;
$the_post_title = $postinfo->post_title;
$the_post_guid = $postinfo->guid;

$getinfo = get_post_meta($the_post_id, mvb_vid_code, true);
$vidimage = get_post_meta($the_post_id, $customfield_thumb, true);
$viddesc = get_post_meta($the_post_id, $customfield_desc, true);
$vidsource = get_post_meta($the_post_id, $customfield_vidsource, true);
$vidurl = get_post_meta($the_post_id, $customfield_vid, true);
$vidtime = get_post_meta($the_post_id, $customfield_vidtime, true);

if (!$getinfo) {
continue;
}

if( strstr($getinfo,"|")){
$vidinfo  = explode('|', $getinfo);
$videohost = $vidinfo[0];
$vidcod = $vidinfo[1];
$vidcod = str_replace("http://www.youtube.com/v/", "", $vidcod);
$vidcod = str_replace("http://www.dailymotion.com/swf/video/", "", $vidcod);
$vidcod = str_replace("http://www.dailymotion.com/swf/", "", $vidcod);
$vidcod = str_replace("http://www.metacafe.com/fplayer/", "", $vidcod);
$vidcod = str_replace("/video.swf", "", $vidcod);
$vidcod = str_replace("&related=0", "", $vidcod);
$vidcod = str_replace("&f=gdata_videos", "", $vidcod);
$str_after = strstr($vidcod, "?f");
if ($str_after) {$vidcod = str_replace($str_after, "", $vidcod);}
update_post_meta($the_post_id, mvb_vid_code, $vidcod);
$videohost = str_replace("gdata.", '', $videohost);
$videohost = str_replace("en.", '', $videohost);
$videohost = str_replace("rss.", '', $videohost);
$videohost = str_replace("playervideo.", '', $videohost);
add_post_meta($the_post_id, $customfield_vidsource, $videohost, true);
}else{
$videohost = $vidsource;
$vidcod = $getinfo;
}

require(ABSPATH . 'wp-content/plugins/myvideoblog/mvb_showembed.php');
$new_embed = "<!--videoplayer-->".$embedcode."<!--endvideoplayer-->";

if (($imglib == "yes") OR (strstr($vidimage,"img_"))) {
$vidimage = strstr($vidimage,"img_");
$libimage = "".$thumbs_dir."/".$vidimage."";
$vidimage = "".$siteurl."/wp-content/".$thumbs_dir."/".$vidimage."";
update_post_meta($the_post_id, $customfield_thumb, $vidimage);
$libimage = str_replace("uploads/", '', $libimage);
update_post_meta($the_post_id+1, _wp_attached_file, $libimage);
}

$usetemplate = $mytemplate;
$usetemplate = str_replace("[videoimage]", $vidimage, $usetemplate);
$usetemplate = str_replace("[videotitle]", $the_post_title, $usetemplate);
$usetemplate = str_replace("[posturl]", $the_post_guid, $usetemplate);
$usetemplate = str_replace("[videodescription]", $viddesc, $usetemplate);
$usetemplate = str_replace("[videourl]", $vidurl, $usetemplate);
$usetemplate = str_replace("[videosource]", $vidsource, $usetemplate);
$usetemplate = str_replace("[hide]", "<!--more-->", $usetemplate);
$usetemplate = str_replace("[videoplayer]", $new_embed, $usetemplate);
$usetemplate = str_replace("[duration]", $vidtime, $usetemplate);
$usetemplate = addslashes($usetemplate);
$wpdb->query("UPDATE ".$wpdb->posts." SET post_content = '".$usetemplate."' WHERE ID = '".$the_post_id."'");

if(isset($customfield_vidembed)) {
update_post_meta($the_post_id, $customfield_vidembed, $new_embed);
}
update_post_meta($the_post_id, $customfield_desc, $viddesc);
update_post_meta($the_post_id, $customfield_vidsource, $vidsource);
update_post_meta($the_post_id, $customfield_vid, $vidurl);
update_post_meta($the_post_id, $customfield_vidtime, $vidtime);
}

echo "<p align=\"left\"><h2>Rebuild - Results</h2></p>";
echo "Rebuilding <b>".$per_step."</b> posts per step.<br>";
echo "Total posts in your blog: <b>".$total_results."</b> </font> <font size=1>(Only Posts created by MVB will be affected.)</font><br>";
if($step < ($steps - 1)) {
echo "Posts rebuilded so far: <b>".$start."</b></font><br>";


   $more = $step + 1;
   $urlself = "admin.php?page=MVB_Settings&action=rebuild&step=".$more."";
   echo "<a href=\"".$urlself."\">Next Step</a><br>";
} else {
echo "<font color=\"green\"><b>Rebuild completed!</b></font><br>";
}

} else if($_REQUEST['action'] == "savesettings") {
global $wpdb;
$savept = $_POST['showtemplate'];
$copyimg = $_POST['copyimages'];
$rurls = $_POST['removeurls'];
$descsize = $_POST['descsize'];
$imglib = $_POST['imglib'];
$pwsize = $_POST['pwsize'];
$phsize = $_POST['phsize'];
$utf8_active = $_POST['utf8_active'];
$customfield_thumb = $_POST['customfield_thumb'];
$customfield_desc = $_POST['customfield_desc'];
$customfield_vid = $_POST['customfield_vid'];
$customfield_vidsource = $_POST['customfield_vidsource'];
$thumbs_dir = $_POST['thumbs_dir'];
$theme_setting = $_POST['theme_setting'];
$jwplayer = $_POST['jwplayer'];
$customfield_vidembed = $_POST['customfield_vidembed'];
$customfield_vidtime = $_POST['customfield_vidtime'];
$maxpages = $_POST['maxpages'];

$old_customfield_thumb = get_option('mvb_customfield_thumb');
$old_customfield_vidembed = get_option('mvb_customfield_vidembed');
$old_customfield_desc = get_option('mvb_customfield_desc');
$old_customfield_vid = get_option('mvb_customfield_vid');
$old_customfield_vidsource = get_option('mvb_customfield_vidsource');
$old_customfield_vidtime = get_option('mvb_customfield_vidtime');
$old_thumbs_dir = get_option('mvb_thumbs_dir');

if($old_customfield_thumb != $customfield_thumb) {
$wpdb->query("UPDATE ".$wpdb->postmeta." SET meta_key = '".$customfield_thumb."' WHERE meta_key = '".$old_customfield_thumb."'");
}
if($old_customfield_desc != $customfield_desc) {
$wpdb->query("UPDATE ".$wpdb->postmeta." SET meta_key = '".$customfield_desc."' WHERE meta_key = '".$old_customfield_desc."'");
}
if($old_customfield_vid != $customfield_vid) {
$wpdb->query("UPDATE ".$wpdb->postmeta." SET meta_key = '".$customfield_vid."' WHERE meta_key = '".$old_customfield_vid."'");
}
if($old_customfield_vidsource != $customfield_vidsource) {
$wpdb->query("UPDATE ".$wpdb->postmeta." SET meta_key = '".$customfield_vidsource."' WHERE meta_key = '".$old_customfield_vidsource."'");
}
if($old_customfield_vidtime != $customfield_vidtime) {
$wpdb->query("UPDATE ".$wpdb->postmeta." SET meta_key = '".$customfield_vidtime."' WHERE meta_key = '".$old_customfield_vidtime."'");
}
if(($customfield_vidembed == "") AND (isset($old_customfield_vidembed))) {
$wpdb->query("DELETE FROM ".$wpdb->postmeta." WHERE meta_key = '".$old_customfield_vidembed."'");
} else if((isset($old_customfield_vidembed)) AND ($old_customfield_vidembed != $customfield_vidembed)) {
$wpdb->query("UPDATE ".$wpdb->postmeta." SET meta_key = '".$customfield_vidembed."' WHERE meta_key = '".$old_customfield_vidembed."'");
}
if($old_thumbs_dir != $thumbs_dir) {
$old_thumb_path = "".ABSPATH."wp-content/".$old_thumbs_dir."";
$thumb_path = "".ABSPATH."wp-content/".$thumbs_dir."";
if( strstr($old_thumb_path,"\\")){
$old_thumb_path = str_replace("/", "\\", $old_thumb_path);
}
if( strstr($thumb_path,"\\")){
$thumb_path = str_replace("/", "\\", $thumb_path);
}
if(rename($old_thumb_path, $thumb_path)) {
@rmdir($old_thumb_path);
} else {
echo "<br><font color=red><b>MVB could not change the directory of thumbnails. Please change it manually.</b></font><br><br>";
}
}
update_option('mvb_posttemplate', $savept);
update_option('mvb_copyimages', $copyimg);
update_option('mvb_removeurls', $rurls);
update_option('mvb_descsize', $descsize);
update_option('mvb_imglib', $imglib);
update_option('mvb_pwsize', $pwsize);
update_option('mvb_phsize', $phsize);
update_option('mvb_utf8_active', $utf8_active);
update_option('mvb_customfield_thumb', $customfield_thumb);
update_option('mvb_customfield_desc', $customfield_desc);
update_option('mvb_customfield_vid', $customfield_vid);
update_option('mvb_customfield_vidsource', $customfield_vidsource);
update_option('mvb_thumbs_dir', $thumbs_dir);
update_option('mvb_theme_setting', $theme_setting);
update_option('mvb_jwplayer', $jwplayer);
update_option('mvb_customfield_vidembed', $customfield_vidembed);
update_option('mvb_customfield_vidtime', $customfield_vidtime);
update_option('mvb_maxpages', $maxpages);


if(count($_POST))
{
	$len = count($_POST['proxy_ip']);
	$myproxies = array();
	for ($i=0; $i < $len; $i++)
	{
	$proxy_ip = $_POST['proxy_ip'][$i];
	$proxy_type = $_POST['proxy_type'][$i];
	$proxy_user = $_POST['proxy_user'][$i];
	$proxy_pw = $_POST['proxy_pw'][$i];
	if (!$proxy_ip) {continue;}
	$myproxies[] = "".$proxy_ip."|".$proxy_user.":".$proxy_pw."|".$proxy_type."";
	}
}
add_option('mvb_proxies', $myproxies);
update_option('mvb_proxies', $myproxies);

if($_POST['proxysources']) {
$proxysources = $_POST['proxysources'];
add_option('mvb_proxysources', $proxysources);
update_option('mvb_proxysources', $proxysources);
}
echo "<br><font color=green>New MVB Settings saved!</font><br>";

}

echo "<h2>MVB Settings</h2>";
$showtemplate = get_option('mvb_posttemplate');
$showtemplate = stripslashes($showtemplate);
$copyimages = get_option('mvb_copyimages');
$removeurls = get_option('mvb_removeurls');
$descsize = get_option('mvb_descsize');
$imglib = get_option('mvb_imglib');
$pwsize = get_option('mvb_pwsize');
$phsize = get_option('mvb_phsize');
$utf8_active = get_option('mvb_utf8_active');
$customfield_thumb = get_option('mvb_customfield_thumb');
$customfield_desc = get_option('mvb_customfield_desc');
$customfield_vid = get_option('mvb_customfield_vid');
$customfield_vidsource = get_option('mvb_customfield_vidsource');
$thumbs_dir = get_option('mvb_thumbs_dir');
$theme_setting = get_option('mvb_theme_setting');
$jwplayer = get_option('mvb_jwplayer');
$customfield_vidembed = get_option('mvb_customfield_vidembed');
$customfield_vidtime = get_option('mvb_customfield_vidtime');
$maxpages = get_option('mvb_maxpages');

if($copyimages == "yes") {$checkedyes = "checked";} else {$checkedyes = "";}
if($copyimages == "no") {$checkedno = "checked";} else {$checkedno = "";}
if($removeurls == "yes") {$checkedyes2 = "checked";} else {$checkedyes2 = "";}
if($removeurls == "no") {$checkedno2 = "checked";} else {$checkedno2 = "";}
if($imglib == "yes") {$checkedyes3 = "checked";} else {$checkedyes3 = "";}
if($imglib == "no") {$checkedno3 = "checked";} else {$checkedno3 = "";}
if($utf8_active == "yes") {$checkedyes4 = "checked";} else {$checkedyes4 = "";}
if($utf8_active == "no") {$checkedno4 = "checked";} else {$checkedno4 = "";}
if($theme_setting == "default") {$checked_default = "checked";} else {$checked_default = "";}
if($theme_setting == "press75") {$checked_press75 = "checked";} else {$checked_75 = "";}
if($theme_setting == "elegantthemes") {$checked_elegant = "checked";} else {$checked_elegant = "";}
if($theme_setting == "mvbgallery") {$checked_mvbgallery = "checked";} else {$checked_mvbgallery = "";}
if($theme_setting == "woothemes") {$checked_woothemes = "checked";} else {$checked_woothemes = "";}
if($theme_setting == "ithemes") {$checked_ithemes = "checked";} else {$checked_ithemes = "";}
if($theme_setting == "freewptube") {$checked_freewptube = "checked";} else {$checked_freewptube = "";}
if($theme_setting == "wptubeplatinum") {$checked_wptubeplatinum = "checked";} else {$checked_wptubeplatinum = "";}
if($jwplayer == "yes") {$checkedyes_jwp = "checked";} else {$checkedyes_jwp = "";}
if($jwplayer == "no") {$checkedno_jwp = "checked";} else {$checkedno_jwp = "";}
$formurl = $_SERVER["REQUEST_URI"];
$formurl = str_replace("&check=proxy", "", $formurl);
?>
<br>
<form action="<?php echo $formurl; ?>" method="post" name="myform">
<input type="hidden" name="action" value="savesettings">
<table class="widefat" style="border-width:0px;border-style:solid;border-spacing:0;width:100%;clear:both;margin:0;-moz-border-radius:0px;-khtml-border-radius:0px;-webkit-border-radius:0px;border-radius:0px;background-color:#F9F9F9;"><tr><td valign="top" style="border-bottom-width:0px;">
<table class="widefat" cellspacing="0">
<thead>
<th>
Predefined Theme Settings
</th>
</thead>
<tr><td>
<table><tr><td align="left" style="border-bottom-width:0px;">
<input value="default" type="radio" name="theme_setting" onClick="cf_mvb();" <?php echo $checked_default;?>>Default/Others
</td><td align="left" style="border-bottom-width:0px;">
<input value="mvbgallery" type="radio" name="theme_setting" onClick="cf_mvbgallery();" <?php echo $checked_mvbgallery;?>><a href="http://www.phpmyvideoblog.com/forum/thread-235.html" target="_blank"><b>MVB Gallery Theme</b></a>
</td><td align="left" style="border-bottom-width:0px;">
<input value="press75" type="radio" name="theme_setting" onClick="cf_press75();" <?php echo $checked_press75;?>><a href="http://www.phpmyvideoblog.com/press75" target="_blank"><b>Press75 Themes</b></a>
</td></tr>
<tr><td align="left" style="border-bottom-width:0px;">
<input value="elegantthemes" type="radio" name="theme_setting" onClick="cf_elegantthemes();" <?php echo $checked_elegant;?>><a href="http://www.phpmyvideoblog.com/elegant-themes" target="_blank"><b>ElegantThemes</b></a>
</td><td align="left" style="border-bottom-width:0px;">
<input value="woothemes" type="radio" name="theme_setting" onClick="cf_woothemes();" <?php echo $checked_woothemes;?>><a href="http://www.phpmyvideoblog.com/woothemes" target="_blank"><b>WooThemes</b></a>
</td><td align="left" style="border-bottom-width:0px;">
<input value="ithemes" type="radio" name="theme_setting" onClick="cf_ithemes();" <?php echo $checked_ithemes;?>><a href="http://www.phpmyvideoblog.com/ithemes" target="_blank"><b>Digital Gallery (iThemes)</b></a>
</td></tr>
<tr><td align="left" style="border-bottom-width:0px;">
<input value="freewptube" type="radio" name="theme_setting" onClick="cf_freewptube();" <?php echo $checked_freewptube;?>><a href="http://www.phpmyvideoblog.com/freewptube" target="_blank"><b>Free WP Tube</b></a>
</td><td align="left" style="border-bottom-width:0px;">
<input value="wptubeplatinum" type="radio" name="theme_setting" onClick="cf_wptubeplatinum();" <?php echo $checked_wptubeplatinum;?>><a href="http://www.phpmyvideoblog.com/wptubeplatinum" target="_blank"><b>WP Tube Platinum</b></a>
</td><td align="left" style="border-bottom-width:0px;">
<a href="#" onclick="mvbtoggle('ts_help'); return false;"><img src="<?php echo $siteurl?>/wp-content/plugins/myvideoblog/includes/info.png" border="0" alt="Tips" title="Tips"></a>
</td></tr></table>
<div id="ts_help" style="display:none;"><font size="1">There are some themes that needs to rebuild posts to fix thumbnails and embed codes.<br>Maybe you will need to adjust the size of the player, you will need to run the rebuild posts to update all old videos.</font></div>
</td></tr></table>
<br>
<table class="widefat" cellspacing="0">
<thead>
<th>
Extra Settings
</th>
</thead>
<tr><td>
<b>Copy thumbnails?</b> <input value="yes" type="radio" name="copyimages" <?php echo $checkedyes;?>>Yes
<input value="no" type="radio" name="copyimages" <?php echo $checkedno;?>>No
<br>(MVB will try to copy the thumbnail of each video to your server. Xvideos has hotlink protection, for this source MVB will always try to copy the thumbnail.)
<br><br>
<b>Thumbnails directory:</b> /wp-content/<input value="<?php echo $thumbs_dir;?>" size="25" type="text" name="thumbs_dir" id="thumbs_dir">
<?php
if($copyimages == "yes") {
$imgspath = ABSPATH . 'wp-content/'.$thumbs_dir.'';
if (!is_writable($imgspath)) {
echo "<br><font color=\"red\">Directory \"/wp-content/".$thumbs_dir."\" not found or is not writable! Please create it and chmod to 0777!</font>";
}
}
?>
<br><br>
<b>Add thumbnails to Media Library?</b> <input value="yes" type="radio" name="imglib" <?php echo $checkedyes3;?>>Yes
<input value="no" type="radio" name="imglib" <?php echo $checkedno3;?>>No
<br>(Ignore if you have selected to not copy thumbnails.)
<br>(This option only works if your thumbnails directory is inside of the directory of uploads. Example: wp-content/uploads/your-thumbs-directory)
<br><br>
<input value="no" type="hidden" name="utf8_active">
<b>Remove URLs?</b> <input value="yes" type="radio" name="removeurls" <?php echo $checkedyes2;?>>Yes
<input value="no" type="radio" name="removeurls" <?php echo $checkedno2;?>>No
<br>(MVB will try to remove any url from video description.)
<br><br>
<b>Description Size:</b> <input value="<?php echo $descsize;?>" size="3" type="text" name="descsize" maxlength="3"> Characters<br>
(0 = Unlimited - Not Recommended.)
<br><br>
<b>Use <a href="http://www.longtailvideo.com/players/jw-flv-player" target="_blank">JW Player</a> to play YouTube videos?</b> <input value="yes" type="radio" name="jwplayer" <?php echo $checkedyes_jwp;?>>Yes
<input value="no" type="radio" name="jwplayer" <?php echo $checkedno_jwp;?>>No
<br>(Download the JW Player and upload the files player.swf, yt.swf and swfobject.js to the main directory of your wordpress.)
<br><br>
<b>Player Size:</b> Width: <input value="<?php echo $pwsize;?>" size="3" type="text" name="pwsize" maxlength="3" id="pwsize"> Height: <input value="<?php echo $phsize;?>" size="3" type="text" name="phsize" maxlength="3" id="phsize">
<br><br>
<b>Max subpages:</b> <input value="<?php echo $maxpages;?>" size="3" type="text" name="maxpages" maxlength="1" id="maxpages">
<br>(The maximum number of subpages that MVB will try to follow to grab more videos if needed. A higher number needs more server resources. Take care.)
<br>
</td></tr></table>
<br>
<?php
$myproxies = get_option('mvb_proxies');
$proxysources = get_option('mvb_proxysources');
?>
<table class="widefat" cellspacing="0">
<thead>
<th>
Proxy Settings
</th>
</thead>
<tr><td>
<table style="border-bottom-width:0px;"><tr><td style="border-bottom-width:0px;">
<?php
if($myproxies) {
echo "<div id=\"showproxysources\" style=\"display:block;\">";
} else {
echo "<div id=\"showproxysources\" style=\"display:none;\">";
}
if ($proxysources) {
foreach ($proxysources as $i => $value) {
if ($proxysources[$i] == "youtube.com") {$yt_checked = "selected";}
else if ($proxysources[$i] == "dailymotion.com") {$dm_checked = "selected";}
else if ($proxysources[$i] == "metacafe.com") {$mc_checked = "selected";}
else if ($proxysources[$i] == "kewego.com") {$ke_checked = "selected";}
else if ($proxysources[$i] == "yahoo.com") {$ya_checked = "selected";}
else if ($proxysources[$i] == "viddler.com") {$vi_checked = "selected";}
else if ($proxysources[$i] == "sevenload.com") {$se_checked = "selected";}
else if ($proxysources[$i] == "globo.com") {$gl_checked = "selected";}
else if ($proxysources[$i] == "break.com") {$gl_checked = "selected";}
else if ($proxysources[$i] == "megavideo.com") {$gl_checked = "selected";}
else if ($proxysources[$i] == "hulu.com") {$gl_checked = "selected";}
else if ($proxysources[$i] == "megaporn.com") {$mp_checked = "selected";}
else if ($proxysources[$i] == "shufuni.com") {$sh_checked = "selected";}
else if ($proxysources[$i] == "pornhub.com") {$ph_checked = "selected";}
else if ($proxysources[$i] == "xvideos.com") {$xv_checked = "selected";}
else if ($proxysources[$i] == "redtube.com") {$rt_checked = "selected";}
else if ($proxysources[$i] == "deviantclip.com") {$dc_checked = "selected";}
else if ($proxysources[$i] == "keezmovies.com") {$km_checked = "selected";}
else if ($proxysources[$i] == "extremetube.com") {$gl_checked = "selected";}
else if ($proxysources[$i] == "hardsextube.com") {$gl_checked = "selected";}
else if ($proxysources[$i] == "eporner.com") {$gl_checked = "selected";}
}
}
?>
<div>
Use proxy with:
</div>
<select name="proxysources[]" size="50" multiple="mulitple" style="width:10em;height:15em;">
<option value="">--- None ---</option>
<option value="youtube.com" <?php echo $yt_checked;?>>YouTube</option>
<option value="dailymotion.com" <?php echo $dm_checked;?>>Dailymotion</option>
<option value="metacafe.com" <?php echo $mc_checked;?>>Metacafe</option>
<option value="kewego.com" <?php echo $ke_checked;?>>Kewego</option>
<option value="yahoo.com" <?php echo $ya_checked;?>>Yahoo! Video</option>
<option value="viddler.com" <?php echo $vi_checked;?>>Viddler</option>
<option value="sevenload.com" <?php echo $se_checked;?>>SevenLoad</option>
<option value="globo.com" <?php echo $gl_checked;?>>Globo</option>
<option value="break.com" <?php echo $gl_checked;?>>Break</option>
<option value="hulu.com" <?php echo $gl_checked;?>>Hulu</option>
<option value="megavideo.com" <?php echo $gl_checked;?>>MegaVideo</option>
<option value="megaporn.com" <?php echo $mp_checked;?>>MegaPorn</option>
<option value="shufuni.com" <?php echo $sh_checked;?>>Shufuni</option>
<option value="pornhub.com" <?php echo $ph_checked;?>>PornHub</option>
<option value="xvideos.com" <?php echo $xv_checked;?>>Xvideos</option>
<option value="redtube.com" <?php echo $rt_checked;?>>RedTube</option>
<option value="deviantclip.com" <?php echo $dc_checked;?>>DeviantClip</option>
<option value="keezmovies.com" <?php echo $km_checked;?>>KeezMovies</option>
<option value="eporner.com" <?php echo $gl_checked;?>>Eporner</option>
<option value="extremetube.com" <?php echo $gl_checked;?>>ExtremeTube</option>
<option value="hardsextube.com" <?php echo $gl_checked;?>>HardSexTube</option>
</select>
</div>
</td>
<td style="border-bottom-width:0px;">
<?php
if($myproxies) {
foreach ($myproxies as $i => $value) {
	$proxy = explode('|', $myproxies[$i]);
	if ($proxy[2] == "http") {
	$sel_http[$i] = "selected";
	} else if ($proxy[2] == "socks4") {
	$sel_socks4[$i] = "selected";
	} else if ($proxy[2] == "socks5") {
	$sel_socks5[$i] = "selected";
	}
	$userpwd = explode(':', $proxy[1]);
	$proxy_user = $userpwd[0];
	$proxy_pwd = $userpwd[1];
echo 'Ip:Port <input type="text" name="proxy_ip[]" size="25" value="'.$proxy[0].'">&nbsp;Type: <select name="proxy_type[]">';
echo '<option name="http" '.$sel_http[$i].'>http</option>';
echo '<option name="socks4" '.$sel_socks4[$i].'>socks4</option>';
echo '<option name="socks5" '.$sel_socks5[$i].'>socks5</option>';
echo '</select>';
if(($_GET['check']) AND ($_GET['check'] == "proxy")) {
$checking_proxy = checkProxy($proxy[0], $proxy[1], $proxy[2]);
if($checking_proxy == "1") {
echo "&nbsp; <font color=\"green\"><b>WORKING</b></font>";
} else {
echo "&nbsp; <font color=\"red\"><b>NOT WORKING</b></font>";
}
}
echo '<br>Username: <input type="text" name="proxy_user[]" value="'.$proxy_user.'"> &nbsp; Password <input type="text" name="proxy_pw[]" value="'.$proxy_pwd.'"><br><br>';
}
}
?>
<div id="newproxy">

</div>
<p id="addnew">
<a href="javascript:new_proxy()">Add New Proxy</a><?php if ($myproxies) { echo ' - <a href="admin.php?page=MVB_Settings&check=proxy">Check Proxies</a><br><font size="1">To remove a proxy, leave the ip:port empty and save the settings.<br>To disable the proxy service without removing them, in the listbox beside it, select None and uncheck all video sources.</font>';} ?>
</p>
<!-- Template -->
<div id="newproxytpl" style="display:none">
Ip:Port <input type="text" name="proxy_ip[]" size="25" value="">&nbsp;Type: <select name="proxy_type[]">
<option name="http" selected>http</option>
</select>
<br>
Username: <input type="text" name="proxy_user[]" value=""> &nbsp; Password <input type="text" name="proxy_pw[]" value="">
</div>
</td></tr></table>
</td></tr></table>
<p align="left">
<br>
&nbsp;&nbsp;&nbsp;<input type="submit" name="submit" class="button-primary" value="Save MVB Settings">
</p>
</td><td width="350" valign="top" style="border-bottom-width:0px;">
<table class="widefat" style="width:350px;" cellspacing="0">
<thead>
<th>
<b>MVB Post Template:</b>
</thead>
</th>
</table>
<div id="poststuff" style="width:350px;">
<center><textarea name="showtemplate" rows="8" cols="40"><?php echo $showtemplate;?></textarea></center>
<div id="smt" style="background-color:#E3E3E3;width:350px;">
<table><tr>
<td align="left">
Insert MVB Tags: <a href="#" onclick="mvbtoggle('mvb_pt_help'); return false;"><img src="<?php echo $siteurl?>/wp-content/plugins/myvideoblog/includes/help.png" border="0" alt="Click here for Help" title="Click here for Help"></a><br>
<b><a href="#" onclick="javascript:addtag('[posturl]');return false;">[posturl]</a> <a href="#" onclick="javascript:addtag('[videoimage]');return false;">[videoimage]</a> <a href="#" onclick="javascript:addtag('[videotitle]');return false;">[videotitle]</a> <a href="#" onclick="javascript:addtag('[videourl]');return false;">[videourl]</a>
<br><a href="#" onclick="javascript:addtag('[videodescription]');return false;">[videodescription]</a> <a href="#" onclick="javascript:addtag('[videosource]');return false;">[videosource]</a> <a href="#" onclick="javascript:addtag('[videoplayer]');return false;">[videoplayer]</a>
<br><a href="#" onclick="javascript:addtag('[duration]');return false;">[duration]</a> <a href="#" onclick="javascript:addtag('[hide]');return false;">[hide]</a></b></td></tr></table>
<div id="mvb_pt_help" style="background-color:#FFFFFF;width:100%;display:none;">
<font color="#808080"><b>[posturl]</b></font> The Post URL.<br>
<font color="#808080"><b>[videoimage]</b></font> Thumbnail URL.<br>
<font color="#808080"><b>[videotitle]</b></font> Video/Post Title.<br>
<font color="#808080"><b>[videodescription]</b></font> Video Description.<br>
<font color="#808080"><b>[videourl]</b></font> Original video URL from the source.(<i>Example: http://www.youtube.com/watch?v=NsIh0lycJdI</i>)<br>
<font color="#808080"><b>[videosource]</b></font> Video Source. (<i>Example: youtube.com</i>)<br>
<font color="#808080"><b>[videoplayer]</b></font> The player that shows the video.<br>
<font color="#808080"><b>[duration]</b></font> The duration time of the video.<br>
<font color="#808080"><b>[hide]</b></font> This will hide everything after this in the index page and index of each category.<br>[hide] = &lt;!--more--&gt;
<br><br>
<font color="red"><b>*</b></font> If you change the template, the OLD videos will not be changed!<br>
<font color="red"><b>*</b></font> Always make some tests before publishing videos with a different template!<br>
</div>
</div>
</div>
</div>
<br>
<table class="widefat" style="width:350px;" cellspacing="0">
<thead>
<th>
Tags for Themes: <a href="#" onclick="mvbtoggle('mvb_tft_help'); return false;"><img src="<?php echo $siteurl?>/wp-content/plugins/myvideoblog/includes/help.png" border="0" alt="Click here for Help" title="Click here for Help"></a>
</th>
</thead>
<tr><td>
You can create the "post template" directly in your wordpress theme. (<u>Advanced Users</u>)<br>
If your theme uses a different custom field, you can customize them here:<br><br>
<b>Custom Fields</b><br>
<b>Thumbnail:</b> <input value="<?php echo $customfield_thumb;?>" size="25" type="text" name="customfield_thumb" id="customfield_thumb"><br>
<b>Description:</b> <input value="<?php echo $customfield_desc;?>" size="25" type="text" name="customfield_desc" id="customfield_desc"><br>
<b>Video Source:</b> <input value="<?php echo $customfield_vidsource;?>" size="25" type="text" name="customfield_vidsource" id="customfield_vidsource"><br>
<b>Video URL:</b> <input value="<?php echo $customfield_vid;?>" size="25" type="text" name="customfield_vid" id="customfield_vid"><br>
<b>Video Duration:</b> <input value="<?php echo $customfield_vidtime;?>" size="25" type="text" name="customfield_vidtime" id="customfield_vidtime"><br>
<b>Embed code:</b> <input value="<?php echo $customfield_vidembed;?>" size="25" type="text" name="customfield_vidembed" id="customfield_vidembed"><br>
<div id="mvb_tft_help" style="background-color:#FFFFFF;width:100%;display:none;">
<br>
MVB tags for wordpress themes:<br>
<div id="thumb_saved" style="display:block;">
<font color="#808080"><b>&lt;?php echo post_custom('<?php echo $customfield_thumb;?>'); ?&gt;</b></font> Thumbnail URL.<br>
</div>
<div id="thumb_default" style="display:none;">
<font color="#808080"><b>&lt;?php echo post_custom('mvb_thumb_url'); ?&gt;</b></font> Thumbnail URL.<br>
</div>
<div id="thumb_p75" style="display:none;">
<font color="#808080"><b>&lt;?php echo post_custom('_p75_thumbnail'); ?&gt;</b></font> Thumbnail URL.<br>
</div>
<div id="thumb_elegant" style="display:none;">
<font color="#808080"><b>&lt;?php echo post_custom('Thumbnail'); ?&gt;</b></font> Thumbnail URL.<br>
</div>
<div id="thumb_mvbgallery" style="display:none;">
<font color="#808080"><b>&lt;?php echo post_custom('mvb_thumb_url'); ?&gt;</b></font> Thumbnail URL.<br>
</div>
<div id="thumb_woothemes" style="display:none;">
<font color="#808080"><b>&lt;?php echo post_custom('image'); ?&gt;</b></font> Thumbnail URL.<br>
</div>
<div id="thumb_freewptube" style="display:none;">
<font color="#808080"><b>&lt;?php echo post_custom('thumb'); ?&gt;</b></font> Thumbnail URL.<br>
</div>
<div id="thumb_wptubeplatinum" style="display:none;">
<font color="#808080"><b>&lt;?php echo post_custom('video_thumb'); ?&gt;</b></font> Thumbnail URL.<br>
</div>
<font color="#808080"><b>&lt;?php echo post_custom('<?php echo $customfield_desc;?>'); ?&gt;</b></font> Video Description.<br>
<font color="#808080"><b>&lt;?php echo post_custom('<?php echo $customfield_vidsource;?>'); ?&gt;</b></font> Video Source. (<i>Example: youtube.com</i>)<br>
<font color="#808080"><b>&lt;?php echo post_custom('<?php echo $customfield_vid;?>'); ?&gt;</b></font> Original video URL from the source.(<i>Example: http://www.youtube.com/watch?v=NsIh0lycJdI</i>)<br>
<font color="#808080"><b>&lt;?php echo post_custom('<?php echo $customfield_vidtime;?>'); ?&gt;</b></font> Video Duration.<br>
<font color="#808080"><b>&lt;?php mvb_embed_code('the_ID()', 430, 350); ?&gt;</b></font> The embed code that shows the video. You can change the player size:<br>
430 = Width and 350 = Height<br><br>
Default Wordpress tags:<br>
<font color="#808080"><b>&lt;?php the_title(); ?&gt;</b></font> Video/Post Title.<br>
<font color="#808080"><b>&lt;?php the_permalink(); ?&gt;</b></font> The Post URL.<br>
<font color="#808080"><b>&lt;?php the_content(); ?&gt;</b></font> <b>This tag shows the MVB Post Template!</b>
</div>
</td></tr></table>
<br><br>
</td></tr></table>
</form>
<br>
<h2>Rebuild posts:</h2>
<table class="widefat" width="100%" cellspacing="1">
<tr><td>
<form action="<?php echo $_SERVER["REQUEST_URI"]; ?>" method="post" name="rebuild">
<input type="hidden" name="action" value="rebuild">
This tool rebuilds all the old posts with the new settings above.<br>
Rebuilds only posts created with MVB 2.X. or MVB 3.X<br>
<font color="red">It's highly recommended to make a backup before using this tool.</font><br><br>
<input type="submit" name="submit" class="button-primary" value="Rebuild Posts">
</form>
</td></tr></table>
<?php
MyVideoBlog_showfooter();
?>