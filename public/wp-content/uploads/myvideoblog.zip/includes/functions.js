function Check(isGroup){

set = document.getElementsByName(isGroup.name);
isState = isGroup.checked;
for (i=0; i<set.length; i++)
{
set[i].checked = isState;
if (i != 0){set[i].checked = isState};
}
}

function delconfirm(url, confirmquestion)
{
 var deletefeed = confirm(confirmquestion);
 if (deletefeed== true)
 {
   window.location=url;
 }
}

function showsources(thesource)
{
  if (thesource == 'dailymotion')
	{
document.getElementById('yttype').style.display = 'none';
document.getElementById('ytdiv').style.display = 'none';
document.getElementById('redtype').style.display = 'none';
document.getElementById('phtype').style.display = 'none';
document.getElementById('userdiv').style.display = 'none';
document.getElementById('phdiv').style.display = 'none';
document.getElementById('redtubediv').style.display = 'none';
document.getElementById('shuftype').style.display = 'none';
document.getElementById('shufdiv').style.display = 'none';
document.getElementById('comments_div').style.display = 'none';
document.getElementById('ytlangdiv').style.display = 'none';
document.getElementById('dmorderdiv').style.display = 'block';
document.getElementById('dmlangdiv').style.display = 'block';
document.getElementById('hulutype').style.display = 'none';
document.getElementById('huluvidtype').style.display = 'none';
document.getElementById('huluorderdiv').style.display = 'none';
document.getElementById('huludiv').style.display = 'none';
document.getElementById('megaporntype').style.display = 'none';
document.getElementById('megaporndiv').style.display = 'none';
document.getElementById('megavideotype').style.display = 'none';
document.getElementById('megavideodiv').style.display = 'none';
document.getElementById('keydiv').style.display = 'block';
	}
	
  else if (thesource == 'shufuni')
	{
	gettype = document.getElementById('shuftypes').value;
document.getElementById('yttype').style.display = 'none';
document.getElementById('ytdiv').style.display = 'none';
document.getElementById('redtype').style.display = 'none';
document.getElementById('phtype').style.display = 'none';
document.getElementById('userdiv').style.display = 'none';
document.getElementById('phdiv').style.display = 'none';
document.getElementById('redtubediv').style.display = 'none';
document.getElementById('shuftype').style.display = 'block';
document.getElementById('shufdiv').style.display = 'none';
document.getElementById('comments_div').style.display = 'none';
document.getElementById('ytlangdiv').style.display = 'none';
document.getElementById('dmorderdiv').style.display = 'none';
document.getElementById('dmlangdiv').style.display = 'none';
document.getElementById('hulutype').style.display = 'none';
document.getElementById('huluvidtype').style.display = 'none';
document.getElementById('huluorderdiv').style.display = 'none';
document.getElementById('huludiv').style.display = 'none';
document.getElementById('megaporntype').style.display = 'none';
document.getElementById('megaporndiv').style.display = 'none';
document.getElementById('megavideotype').style.display = 'none';
document.getElementById('megavideodiv').style.display = 'none';
document.getElementById('keydiv').style.display = 'block';
	if (gettype == 'shufbycat') {
document.getElementById('shufdiv').style.display = 'block';
	}
	else {
document.getElementById('shufdiv').style.display = 'none';
	}
	}

  else if (thesource == 'pornhub')
	{
	gettype = document.getElementById('phtypes').value;
document.getElementById('yttype').style.display = 'none';
document.getElementById('ytdiv').style.display = 'none';
document.getElementById('shuftype').style.display = 'none';
document.getElementById('redtype').style.display = 'none';
document.getElementById('userdiv').style.display = 'none';
document.getElementById('shufdiv').style.display = 'none';
document.getElementById('redtubediv').style.display = 'none';
document.getElementById('phtype').style.display = 'block';
document.getElementById('phdiv').style.display = 'none';
document.getElementById('comments_div').style.display = 'none';
document.getElementById('ytlangdiv').style.display = 'none';
document.getElementById('dmorderdiv').style.display = 'none';
document.getElementById('dmlangdiv').style.display = 'none';
document.getElementById('hulutype').style.display = 'none';
document.getElementById('huluvidtype').style.display = 'none';
document.getElementById('huluorderdiv').style.display = 'none';
document.getElementById('huludiv').style.display = 'none';
document.getElementById('megaporntype').style.display = 'none';
document.getElementById('megaporndiv').style.display = 'none';
document.getElementById('megavideotype').style.display = 'none';
document.getElementById('megavideodiv').style.display = 'none';
document.getElementById('keydiv').style.display = 'block';
	if (gettype == 'phbycat') {
document.getElementById('phdiv').style.display = 'block';
	}
	else {
document.getElementById('phdiv').style.display = 'none';
	}
	}

  else if (thesource == 'redtube')
	{
	gettype = document.getElementById('redtypes').value;
document.getElementById('yttype').style.display = 'none';
document.getElementById('ytdiv').style.display = 'none';
document.getElementById('phtype').style.display = 'none';
document.getElementById('shuftype').style.display = 'none';
document.getElementById('userdiv').style.display = 'none';
document.getElementById('shufdiv').style.display = 'none';
document.getElementById('phdiv').style.display = 'none';
document.getElementById('redtype').style.display = 'block';
document.getElementById('redtubediv').style.display = 'none';
document.getElementById('comments_div').style.display = 'none';
document.getElementById('ytlangdiv').style.display = 'none';
document.getElementById('dmorderdiv').style.display = 'none';
document.getElementById('dmlangdiv').style.display = 'none';
document.getElementById('hulutype').style.display = 'none';
document.getElementById('huluvidtype').style.display = 'none';
document.getElementById('huluorderdiv').style.display = 'none';
document.getElementById('huludiv').style.display = 'none';
document.getElementById('megaporntype').style.display = 'none';
document.getElementById('megaporndiv').style.display = 'none';
document.getElementById('megavideotype').style.display = 'none';
document.getElementById('megavideodiv').style.display = 'none';
document.getElementById('keydiv').style.display = 'block';
	if (gettype == 'redbycat') {
document.getElementById('redtubediv').style.display = 'block';
	}
	else {
document.getElementById('redtubediv').style.display = 'none';
	}
	}
	
	else if (thesource == 'xvideos')
	{
document.getElementById('yttype').style.display = 'none';
document.getElementById('ytdiv').style.display = 'none';
document.getElementById('userdiv').style.display = 'none';
document.getElementById('shufdiv').style.display = 'none';
document.getElementById('phdiv').style.display = 'none';
document.getElementById('redtubediv').style.display = 'none';
document.getElementById('redtype').style.display = 'none';
document.getElementById('phtype').style.display = 'none';
document.getElementById('shuftype').style.display = 'none';
document.getElementById('comments_div').style.display = 'none';
document.getElementById('ytlangdiv').style.display = 'none';
document.getElementById('dmorderdiv').style.display = 'none';
document.getElementById('dmlangdiv').style.display = 'none';
document.getElementById('hulutype').style.display = 'none';
document.getElementById('huluvidtype').style.display = 'none';
document.getElementById('huluorderdiv').style.display = 'none';
document.getElementById('huludiv').style.display = 'none';
document.getElementById('megaporntype').style.display = 'none';
document.getElementById('megaporndiv').style.display = 'none';
document.getElementById('megavideotype').style.display = 'none';
document.getElementById('megavideodiv').style.display = 'none';
document.getElementById('keydiv').style.display = 'block';
	}
	
  else if (thesource == 'youtube')
	{
	
	gettype = document.getElementById('yttypes').value;
document.getElementById('shufdiv').style.display = 'none';
document.getElementById('phdiv').style.display = 'none';
document.getElementById('redtubediv').style.display = 'none';
document.getElementById('redtype').style.display = 'none';
document.getElementById('shuftype').style.display = 'none';
document.getElementById('phtype').style.display = 'none';
document.getElementById('yttype').style.display = 'block';
document.getElementById('comments_div').style.display = 'block';
document.getElementById('ytlangdiv').style.display = 'block';
document.getElementById('dmorderdiv').style.display = 'none';
document.getElementById('dmlangdiv').style.display = 'none';
document.getElementById('hulutype').style.display = 'none';
document.getElementById('huluvidtype').style.display = 'none';
document.getElementById('huluorderdiv').style.display = 'none';
document.getElementById('huludiv').style.display = 'none';
document.getElementById('megaporntype').style.display = 'none';
document.getElementById('megaporndiv').style.display = 'none';
document.getElementById('megavideotype').style.display = 'none';
document.getElementById('megavideodiv').style.display = 'none';
	if (gettype == 'byuser') {
document.getElementById('userdiv').style.display = 'block';
document.getElementById('ytdiv').style.display = 'none';
document.getElementById('keydiv').style.display = 'none';
	}
	else {
document.getElementById('userdiv').style.display = 'none';
document.getElementById('ytdiv').style.display = 'block';
document.getElementById('keydiv').style.display = 'block';	
	}
	}
	
	else if (thesource == 'megaporn')
	{
	gettype = document.getElementById('megaporntypes').value;
document.getElementById('megaporntype').style.display = 'block';
document.getElementById('yttype').style.display = 'none';
document.getElementById('ytdiv').style.display = 'none';
document.getElementById('userdiv').style.display = 'none';
document.getElementById('shufdiv').style.display = 'none';
document.getElementById('phdiv').style.display = 'none';
document.getElementById('redtubediv').style.display = 'none';
document.getElementById('redtype').style.display = 'none';
document.getElementById('phtype').style.display = 'none';
document.getElementById('shuftype').style.display = 'none';
document.getElementById('comments_div').style.display = 'none';
document.getElementById('ytlangdiv').style.display = 'none';
document.getElementById('dmorderdiv').style.display = 'none';
document.getElementById('dmlangdiv').style.display = 'none';
document.getElementById('hulutype').style.display = 'none';
document.getElementById('huluvidtype').style.display = 'none';
document.getElementById('huluorderdiv').style.display = 'none';
document.getElementById('huludiv').style.display = 'none';
document.getElementById('megavideotype').style.display = 'none';
document.getElementById('megavideodiv').style.display = 'none';
document.getElementById('keydiv').style.display = 'block';
	if (gettype == 'megapornbysearch') {
document.getElementById('keydiv').style.display = 'block';
document.getElementById('megaporndiv').style.display = 'none';
	}
	else {
document.getElementById('keydiv').style.display = 'none';
document.getElementById('megaporndiv').style.display = 'block';
	}
	}
	else if (thesource == 'megavideo')
	{
	gettype = document.getElementById('megavideotypes').value;
document.getElementById('megavideotype').style.display = 'block';
document.getElementById('yttype').style.display = 'none';
document.getElementById('ytdiv').style.display = 'none';
document.getElementById('userdiv').style.display = 'none';
document.getElementById('shufdiv').style.display = 'none';
document.getElementById('phdiv').style.display = 'none';
document.getElementById('redtubediv').style.display = 'none';
document.getElementById('redtype').style.display = 'none';
document.getElementById('phtype').style.display = 'none';
document.getElementById('shuftype').style.display = 'none';
document.getElementById('comments_div').style.display = 'none';
document.getElementById('ytlangdiv').style.display = 'none';
document.getElementById('dmorderdiv').style.display = 'none';
document.getElementById('dmlangdiv').style.display = 'none';
document.getElementById('hulutype').style.display = 'none';
document.getElementById('huluvidtype').style.display = 'none';
document.getElementById('huluorderdiv').style.display = 'none';
document.getElementById('huludiv').style.display = 'none';
document.getElementById('megaporntype').style.display = 'none';
document.getElementById('megaporndiv').style.display = 'none';
document.getElementById('keydiv').style.display = 'block';
	if (gettype == 'megavideobysearch') {
document.getElementById('keydiv').style.display = 'block';
document.getElementById('megavideodiv').style.display = 'none';
	}
	else {
document.getElementById('keydiv').style.display = 'none';
document.getElementById('megavideodiv').style.display = 'block';
	}
	}
	else if (thesource == 'deviantclip')
	{
	document.getElementById('yttype').style.display = 'none';
document.getElementById('ytdiv').style.display = 'none';
document.getElementById('userdiv').style.display = 'none';
document.getElementById('shufdiv').style.display = 'none';
document.getElementById('phdiv').style.display = 'none';
document.getElementById('redtubediv').style.display = 'none';
document.getElementById('redtype').style.display = 'none';
document.getElementById('phtype').style.display = 'none';
document.getElementById('shuftype').style.display = 'none';
document.getElementById('comments_div').style.display = 'none';
document.getElementById('ytlangdiv').style.display = 'none';
document.getElementById('dmorderdiv').style.display = 'none';
document.getElementById('dmlangdiv').style.display = 'none';
document.getElementById('hulutype').style.display = 'none';
document.getElementById('huluvidtype').style.display = 'none';
document.getElementById('huluorderdiv').style.display = 'none';
document.getElementById('megaporntype').style.display = 'none';
document.getElementById('megaporndiv').style.display = 'none';
document.getElementById('megavideotype').style.display = 'none';
document.getElementById('megavideodiv').style.display = 'none';
document.getElementById('huludiv').style.display = 'none';
document.getElementById('keydiv').style.display = 'block';
	}
		else if (thesource == 'keezmovies')
	{
	document.getElementById('yttype').style.display = 'none';
document.getElementById('ytdiv').style.display = 'none';
document.getElementById('userdiv').style.display = 'none';
document.getElementById('shufdiv').style.display = 'none';
document.getElementById('phdiv').style.display = 'none';
document.getElementById('redtubediv').style.display = 'none';
document.getElementById('redtype').style.display = 'none';
document.getElementById('phtype').style.display = 'none';
document.getElementById('shuftype').style.display = 'none';
document.getElementById('comments_div').style.display = 'none';
document.getElementById('ytlangdiv').style.display = 'none';
document.getElementById('dmorderdiv').style.display = 'none';
document.getElementById('dmlangdiv').style.display = 'none';
document.getElementById('hulutype').style.display = 'none';
document.getElementById('huluvidtype').style.display = 'none';
document.getElementById('huluorderdiv').style.display = 'none';
document.getElementById('huludiv').style.display = 'none';
document.getElementById('megaporntype').style.display = 'none';
document.getElementById('megaporndiv').style.display = 'none';
document.getElementById('megavideotype').style.display = 'none';
document.getElementById('megavideodiv').style.display = 'none';
document.getElementById('keydiv').style.display = 'block';
	}
		else if (thesource == 'globo')
	{
	document.getElementById('yttype').style.display = 'none';
document.getElementById('ytdiv').style.display = 'none';
document.getElementById('userdiv').style.display = 'none';
document.getElementById('shufdiv').style.display = 'none';
document.getElementById('phdiv').style.display = 'none';
document.getElementById('redtubediv').style.display = 'none';
document.getElementById('redtype').style.display = 'none';
document.getElementById('phtype').style.display = 'none';
document.getElementById('shuftype').style.display = 'none';
document.getElementById('comments_div').style.display = 'none';
document.getElementById('ytlangdiv').style.display = 'none';
document.getElementById('dmorderdiv').style.display = 'none';
document.getElementById('dmlangdiv').style.display = 'none';
document.getElementById('hulutype').style.display = 'none';
document.getElementById('huluvidtype').style.display = 'none';
document.getElementById('huluorderdiv').style.display = 'none';
document.getElementById('huludiv').style.display = 'none';
document.getElementById('megaporntype').style.display = 'none';
document.getElementById('megaporndiv').style.display = 'none';
document.getElementById('megavideotype').style.display = 'none';
document.getElementById('megavideodiv').style.display = 'none';
document.getElementById('keydiv').style.display = 'block';
	}
  else if (thesource == 'hulu')
	{
	gettype = document.getElementById('hulutypes').value;
document.getElementById('hulutype').style.display = 'block';
document.getElementById('huluvidtype').style.display = 'block';
document.getElementById('huluorderdiv').style.display = 'block';
document.getElementById('yttype').style.display = 'none';
document.getElementById('ytdiv').style.display = 'none';
document.getElementById('shuftype').style.display = 'none';
document.getElementById('redtype').style.display = 'none';
document.getElementById('userdiv').style.display = 'none';
document.getElementById('shufdiv').style.display = 'none';
document.getElementById('redtubediv').style.display = 'none';
document.getElementById('phtype').style.display = 'none';
document.getElementById('phdiv').style.display = 'none';
document.getElementById('comments_div').style.display = 'none';
document.getElementById('ytlangdiv').style.display = 'none';
document.getElementById('dmorderdiv').style.display = 'none';
document.getElementById('dmlangdiv').style.display = 'none';
document.getElementById('megaporntype').style.display = 'none';
document.getElementById('megaporndiv').style.display = 'none';
document.getElementById('megavideotype').style.display = 'none';
document.getElementById('megavideodiv').style.display = 'none';
document.getElementById('keydiv').style.display = 'block';
	if (gettype == 'hulubysearch') {
document.getElementById('keydiv').style.display = 'block';
document.getElementById('huludiv').style.display = 'none';
document.getElementById('huluvidtype').style.display = 'block';
	}
	else {
document.getElementById('keydiv').style.display = 'none';
document.getElementById('huludiv').style.display = 'block';
document.getElementById('huluvidtype').style.display = 'none';
	}
	}
  else  {
document.getElementById('yttype').style.display = 'none';
document.getElementById('ytdiv').style.display = 'none';
document.getElementById('userdiv').style.display = 'none';
document.getElementById('shufdiv').style.display = 'none';
document.getElementById('phdiv').style.display = 'none';
document.getElementById('redtubediv').style.display = 'none';
document.getElementById('redtype').style.display = 'none';
document.getElementById('phtype').style.display = 'none';
document.getElementById('shuftype').style.display = 'none';
document.getElementById('keydiv').style.display = 'block';
document.getElementById('comments_div').style.display = 'none';
document.getElementById('ytlangdiv').style.display = 'none';
document.getElementById('dmorderdiv').style.display = 'none';
document.getElementById('dmlangdiv').style.display = 'none';
document.getElementById('hulutype').style.display = 'none';
document.getElementById('huluvidtype').style.display = 'none';
document.getElementById('huluorderdiv').style.display = 'none';
document.getElementById('huludiv').style.display = 'none';
document.getElementById('megaporntype').style.display = 'none';
document.getElementById('megaporndiv').style.display = 'none';
document.getElementById('megavideotype').style.display = 'none';
document.getElementById('megavideodiv').style.display = 'none';
	}
}

function specificfeed() {
document.getElementById('showsf').style.display = 'block';
}

function ytchangetype(ytthetype)
{
  if (ytthetype == 'byuser')
	{
	document.getElementById('ytdiv').style.display = 'none';
	document.getElementById('keydiv').style.display = 'none';
	document.getElementById('userdiv').style.display = 'block';
	}
	
	else if (ytthetype == 'bytags')
	{
	document.getElementById('userdiv').style.display = 'none';
	document.getElementById('ytdiv').style.display = 'block';
	document.getElementById('keydiv').style.display = 'block';
	}
}

function redchangetype(redthetype)
{
  if (redthetype == 'redbycat')
	{
	document.getElementById('keydiv').style.display = 'none';
	document.getElementById('redtubediv').style.display = 'block';
	}
	
	else if (redthetype == 'redbysearch')
	{
	document.getElementById('keydiv').style.display = 'block';
	document.getElementById('redtubediv').style.display = 'none';
	}
}

function phchangetype(phthetype)
{
  if (phthetype == 'phbycat')
	{
	document.getElementById('keydiv').style.display = 'none';
	document.getElementById('phdiv').style.display = 'block';
	}
	
	else if (phthetype == 'phbysearch')
	{
	document.getElementById('keydiv').style.display = 'block';
	document.getElementById('phdiv').style.display = 'none';
	}
}

function shufchangetype(shufthetype)
{
  if (shufthetype == 'shufbycat')
	{
	document.getElementById('keydiv').style.display = 'none';
	document.getElementById('shufdiv').style.display = 'block';
	}
	
	else if (shufthetype == 'shufbysearch')
	{
	document.getElementById('keydiv').style.display = 'block';
	document.getElementById('shufdiv').style.display = 'none';
	}
}

function huluchangetype(huluthetype)
{
  if (huluthetype == 'hulubysearch')
	{
	document.getElementById('keydiv').style.display = 'block';
	document.getElementById('huludiv').style.display = 'none';
	document.getElementById('huluvidtype').style.display = 'block';
	}
	
	else if (huluthetype == 'hulubycat')
	{
	document.getElementById('keydiv').style.display = 'none';
	document.getElementById('huludiv').style.display = 'block';
	document.getElementById('huluvidtype').style.display = 'none';
	}
}

function megapornchangetype(megapornthetype)
{
  if (megapornthetype == 'megapornbysearch')
	{
	document.getElementById('keydiv').style.display = 'block';
	document.getElementById('megaporndiv').style.display = 'none';
	}
	
	else if (megapornthetype == 'megapornbycat')
	{
	document.getElementById('keydiv').style.display = 'none';
	document.getElementById('megaporndiv').style.display = 'block';
	}
}

function megavideochangetype(megavideothetype)
{
  if (megavideothetype == 'megavideobysearch')
	{
	document.getElementById('keydiv').style.display = 'block';
	document.getElementById('megavideodiv').style.display = 'none';
	}
	
	else if (megavideothetype == 'megavideobycat')
	{
	document.getElementById('keydiv').style.display = 'none';
	document.getElementById('megavideodiv').style.display = 'block';
	}
}

function showschedule()
{
	document.getElementById('schedulediv').style.display = 'block';
}

function hideschedule()
{
	document.getElementById('schedulediv').style.display = 'none';
}

function cf_mvb()
{
	var pt_mvb = "<p><a href=\"[posturl]\"><img src=\"[videoimage]\" alt=\"[videotitle]\" border=\"0\" align=\"left\" style=\"width:120px;height:80px;\"></a>[videodescription]<br clear=\"all\"></p>[hide]<p><center>[videoplayer]</center></p>";
	document.myform.thumbs_dir.value = "uploads/mvbthumbs";
	document.myform.showtemplate.value = pt_mvb;
	document.myform.customfield_thumb.value = "mvb_thumb_url";
	document.myform.customfield_desc.value = "mvb_vid_desc";
	document.myform.customfield_vidsource.value = "mvb_vid_source";
	document.myform.customfield_vid.value = "mvb_vid_url";
	document.myform.customfield_vidembed.value = "";
	document.myform.pwsize.value = "540";
	document.myform.phsize.value = "420";
	
	document.getElementById('thumb_saved').style.display = 'none';
	document.getElementById('thumb_default').style.display = 'block';
	document.getElementById('thumb_p75').style.display = 'none';
	document.getElementById('thumb_elegant').style.display = 'none';
	document.getElementById('thumb_mvbgallery').style.display = 'none';
	document.getElementById('thumb_woothemes').style.display = 'none';
	document.getElementById('thumb_freewptube').style.display = 'none';
	document.getElementById('thumb_wptubeplatinum').style.display = 'none';
}

function cf_press75()
{
	document.myform.thumbs_dir.value = "thumbnails";
	document.myform.showtemplate.value = "[videodescription]";
	document.myform.customfield_thumb.value = "_p75_thumbnail";
	document.myform.customfield_desc.value = "mvb_vid_desc";
	document.myform.customfield_vidsource.value = "mvb_vid_source";
	document.myform.customfield_vid.value = "mvb_vid_url";
	document.myform.customfield_vidembed.value = "_videoembed_manual";
	
	document.getElementById('thumb_saved').style.display = 'none';
	document.getElementById('thumb_default').style.display = 'none';
	document.getElementById('thumb_p75').style.display = 'block';
	document.getElementById('thumb_elegant').style.display = 'none';
	document.getElementById('thumb_mvbgallery').style.display = 'none';
	document.getElementById('thumb_woothemes').style.display = 'none';
	document.getElementById('thumb_freewptube').style.display = 'none';
	document.getElementById('thumb_wptubeplatinum').style.display = 'none';
}

function cf_elegantthemes()
{
	document.myform.thumbs_dir.value = "uploads/mvbthumbs";
	document.myform.showtemplate.value = "[videodescription]";
	document.myform.customfield_thumb.value = "Thumbnail";
	document.myform.customfield_desc.value = "mvb_vid_desc";
	document.myform.customfield_vidsource.value = "mvb_vid_source";
	document.myform.customfield_vid.value = "mvb_vid_url";
	document.myform.customfield_vidembed.value = "Video";
	
	document.getElementById('thumb_saved').style.display = 'none';
	document.getElementById('thumb_default').style.display = 'none';
	document.getElementById('thumb_p75').style.display = 'none';
	document.getElementById('thumb_elegant').style.display = 'block';
	document.getElementById('thumb_mvbgallery').style.display = 'none';
	document.getElementById('thumb_woothemes').style.display = 'none';
	document.getElementById('thumb_freewptube').style.display = 'none';
	document.getElementById('thumb_wptubeplatinum').style.display = 'none';
}

function cf_mvbgallery()
{

	var pt_mvbgallery = "<p>[videodescription]</p>[hide]<center>[videoplayer]</center>";
	document.myform.thumbs_dir.value = "uploads/mvbthumbs";
	document.myform.showtemplate.value = pt_mvbgallery;
	document.myform.customfield_thumb.value = "mvb_thumb_url";
	document.myform.customfield_desc.value = "mvb_vid_desc";
	document.myform.customfield_vidsource.value = "mvb_vid_source";
	document.myform.customfield_vid.value = "mvb_vid_url";
	document.myform.customfield_vidembed.value = "";
	document.myform.pwsize.value = "540";
	document.myform.phsize.value = "420";
	
	document.getElementById('thumb_saved').style.display = 'none';
	document.getElementById('thumb_default').style.display = 'none';
	document.getElementById('thumb_p75').style.display = 'none';
	document.getElementById('thumb_elegant').style.display = 'none';
	document.getElementById('thumb_mvbgallery').style.display = 'block';
	document.getElementById('thumb_woothemes').style.display = 'none';
	document.getElementById('thumb_freewptube').style.display = 'none';
	document.getElementById('thumb_wptubeplatinum').style.display = 'none';
}

function cf_woothemes()
{
	document.myform.thumbs_dir.value = "uploads/mvbthumbs";
	document.myform.showtemplate.value = "[videodescription]";
	document.myform.customfield_thumb.value = "image";
	document.myform.customfield_desc.value = "mvb_vid_desc";
	document.myform.customfield_vidsource.value = "mvb_vid_source";
	document.myform.customfield_vid.value = "mvb_vid_url";
	document.myform.customfield_vidembed.value = "embed";
	
	document.getElementById('thumb_saved').style.display = 'none';
	document.getElementById('thumb_default').style.display = 'none';
	document.getElementById('thumb_p75').style.display = 'none';
	document.getElementById('thumb_elegant').style.display = 'none';
	document.getElementById('thumb_mvbgallery').style.display = 'none';
	document.getElementById('thumb_woothemes').style.display = 'block';
	document.getElementById('thumb_freewptube').style.display = 'none';
	document.getElementById('thumb_wptubeplatinum').style.display = 'none';
}

function cf_ithemes()
{
	document.myform.thumbs_dir.value = "uploads/mvbthumbs";
	document.myform.showtemplate.value = "<p>[videodescription]</p>[hide]<center>[videoplayer]</center>";
	document.myform.customfield_thumb.value = "Thumbnail";
	document.myform.customfield_desc.value = "mvb_vid_desc";
	document.myform.customfield_vidsource.value = "mvb_vid_source";
	document.myform.customfield_vid.value = "mvb_vid_url";
	document.myform.customfield_vidembed.value = "";
	
	document.getElementById('thumb_saved').style.display = 'none';
	document.getElementById('thumb_default').style.display = 'none';
	document.getElementById('thumb_p75').style.display = 'none';
	document.getElementById('thumb_elegant').style.display = 'block';
	document.getElementById('thumb_mvbgallery').style.display = 'none';
	document.getElementById('thumb_woothemes').style.display = 'none';
	document.getElementById('thumb_freewptube').style.display = 'none';
	document.getElementById('thumb_wptubeplatinum').style.display = 'none';
}

function cf_freewptube()
{
	document.myform.thumbs_dir.value = "uploads/mvbthumbs";
	document.myform.showtemplate.value = "[videodescription]";
	document.myform.customfield_thumb.value = "thumb";
	document.myform.customfield_desc.value = "mvb_vid_desc";
	document.myform.customfield_vidsource.value = "mvb_vid_source";
	document.myform.customfield_vid.value = "mvb_vid_url";
	document.myform.customfield_vidembed.value = "video_code";
	document.myform.pwsize.value = "600";
	document.myform.phsize.value = "480";
	
	document.getElementById('thumb_saved').style.display = 'none';
	document.getElementById('thumb_default').style.display = 'none';
	document.getElementById('thumb_p75').style.display = 'none';
	document.getElementById('thumb_elegant').style.display = 'none';
	document.getElementById('thumb_mvbgallery').style.display = 'none';
	document.getElementById('thumb_woothemes').style.display = 'none';
	document.getElementById('thumb_freewptube').style.display = 'block';
	document.getElementById('thumb_wptubeplatinum').style.display = 'none';
}

function cf_wptubeplatinum()
{
	document.myform.thumbs_dir.value = "uploads/mvbthumbs";
	document.myform.showtemplate.value = "[videodescription]";
	document.myform.customfield_thumb.value = "video_thumb";
	document.myform.customfield_desc.value = "mvb_vid_desc";
	document.myform.customfield_vidsource.value = "mvb_vid_source";
	document.myform.customfield_vid.value = "mvb_vid_url";
	document.myform.customfield_vidembed.value = "Video";
	document.myform.pwsize.value = "545";
	document.myform.phsize.value = "440";
	
	document.getElementById('thumb_saved').style.display = 'none';
	document.getElementById('thumb_default').style.display = 'none';
	document.getElementById('thumb_p75').style.display = 'none';
	document.getElementById('thumb_elegant').style.display = 'none';
	document.getElementById('thumb_mvbgallery').style.display = 'none';
	document.getElementById('thumb_woothemes').style.display = 'none';
	document.getElementById('thumb_freewptube').style.display = 'none';
	document.getElementById('thumb_wptubeplatinum').style.display = 'block';
}

function customize_cron(thestyle)
{
  if (thestyle == 'custom_crontime')
	{
	document.cronform.mvbcron_cs.disabled = false;
	}
  else if (thestyle == 'daily')
	{
	document.cronform.mvbcron_cs.value = "86400";
	document.cronform.mvbcron_cs.disabled = true;
	}
  else if (thestyle == 'twicedaily')
	{
	document.cronform.mvbcron_cs.value = "43200";
	document.cronform.mvbcron_cs.disabled = true;
	}
  else if (thestyle == 'once_half_hour')
	{
	document.cronform.mvbcron_cs.value = "1800";
	document.cronform.mvbcron_cs.disabled = true;
	}
  else if (thestyle == 'hourly')
	{
	document.cronform.mvbcron_cs.value = "3600";
	document.cronform.mvbcron_cs.disabled = true;
	}
  else if (thestyle == 'once_two_hour')
	{
	document.cronform.mvbcron_cs.value = "7200";
	document.cronform.mvbcron_cs.disabled = true;
	}
  else if (thestyle == 'once_three_hour')
	{
	document.cronform.mvbcron_cs.value = "10800";
	document.cronform.mvbcron_cs.disabled = true;
	}
  else if (thestyle == 'weekly')
	{
	document.cronform.mvbcron_cs.value = "604800";
	document.cronform.mvbcron_cs.disabled = true;
	}
}

function insertAtCaret(areaId,text) {
	var txtarea = document.getElementById(areaId);
	var scrollPos = txtarea.scrollTop;
	var strPos = 0;
	var br = ((txtarea.selectionStart || txtarea.selectionStart == '0') ? 
		"ff" : (document.selection ? "ie" : false ) );
	if (br == "ie") { 
		txtarea.focus();
		var range = document.selection.createRange();
		range.moveStart ('character', -txtarea.value.length);
		strPos = range.text.length;
	}
	else if (br == "ff") strPos = txtarea.selectionStart;
	
	var front = (txtarea.value).substring(0,strPos);  
	var back = (txtarea.value).substring(strPos,txtarea.value.length); 
	txtarea.value=front+text+back;
	strPos = strPos + text.length;
	if (br == "ie") { 
		txtarea.focus();
		var range = document.selection.createRange();
		range.moveStart ('character', -txtarea.value.length);
		range.moveStart ('character', strPos);
		range.moveEnd ('character', 0);
		range.select();
	}
	else if (br == "ff") {
		txtarea.selectionStart = strPos;
		txtarea.selectionEnd = strPos;
		txtarea.focus();
	}
	txtarea.scrollTop = scrollPos;
}

function mvbtoggle(obj) {
var el = document.getElementById(obj);
if ( el.style.display != 'none' ) {
el.style.display = 'none';
}
else {
el.style.display = '';
}
}

var ct = 1;
function new_proxy()
{
	ct++;
	var div1 = document.createElement('div');
	div1.id = ct;
	var delLink = '<br><div style="text-align:left;"><a href="javascript:delIt('+ ct +')">Delete</a></div>';
	div1.innerHTML = document.getElementById('newproxytpl').innerHTML + delLink;
	document.getElementById('newproxy').appendChild(div1);
	document.getElementById('showproxysources').style.display = 'block';
}

function delIt(eleId)
{
	d = document;
	var ele = d.getElementById(eleId);
	var parentEle = d.getElementById('newproxy');
	parentEle.removeChild(ele);
}

function addtag(string) { 
    document.myform.showtemplate.value = document.myform.showtemplate.value + "" + string + ""; 
    document.myform.showtemplate.focus(); 
}