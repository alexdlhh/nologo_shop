<?php
$userAgent = "Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.2.6) Gecko/20100625 Firefox/3.6.6";
$showerrors = "0";
if ($showerrors == "1") {
error_reporting(E_ALL);
ini_set('display_errors', '1');
}
if ((ini_get('open_basedir') == "") OR (ini_get('safe_mode' == 'Off'))) {
set_time_limit(0);
$usefollow = "1";
}
require_once(ABSPATH . 'wp-content/plugins/myvideoblog/mvb_functions.php');
if (!function_exists('file_get_html')) {
require_once(ABSPATH . 'wp-content/plugins/myvideoblog/includes/simple_html_dom.php');
}

// Cheking configs and filters ------------------------------
$mytemplate = get_option('mvb_posttemplate');
$mytemplate = stripslashes($mytemplate);
$removeurls = get_option('mvb_removeurls');
$descsize = get_option('mvb_descsize');
$pwsize = get_option('mvb_pwsize');
$phsize = get_option('mvb_phsize');
$utf8_active = get_option('mvb_utf8_active');
$jwplayer = get_option('mvb_jwplayer');
$proxies = get_option('mvb_proxies');
$proxysources = get_option('mvb_proxysources');
$maxpages = get_option('mvb_maxpages');

$weekday = date("l");
$weekday = strtolower($weekday);

if ($type == "manual") {
$getfeeds = $wpdb->get_results("SELECT fid, feed, category, active, maxvideos, poststatus, commentstatus, pingstatus, blocktags, checktitle, checkdesc, checktags, postauthor, scheduletime, grab_comments, max_comments, aprove_comments FROM ".$wpdb->prefix."myvideoblog WHERE active = 'yes' ORDER BY RAND()", ARRAY_A);
} else if ($type == "processfeed") {
$getfeeds = $wpdb->get_results("SELECT fid, feed, category, active, maxvideos, poststatus, commentstatus, pingstatus, blocktags, checktitle, checkdesc, checktags, postauthor, scheduletime, grab_comments, max_comments, aprove_comments FROM ".$wpdb->prefix."myvideoblog WHERE fid = '$fid'", ARRAY_A);
} else {
$getfeeds = $wpdb->get_results("SELECT fid, feed, category, active, maxvideos, poststatus, commentstatus, pingstatus, blocktags, checktitle, checkdesc, checktags, postauthor, scheduletime, grab_comments, max_comments, aprove_comments FROM ".$wpdb->prefix."myvideoblog WHERE active = 'yes' AND $weekday = 'yes' ORDER BY RAND()", ARRAY_A);
}

$ftotaladded=0;
$ptotaladded=0;
$feednotfound=0;

if($descsize == "0") {$descsize = "10000";}

// Looping Souces ------------------------------

$mvbstats = array();
$notfoundstats = array();

if ($showoutput == "yes") {
echo "<p align=\"left\"><h2>Manual Update - Results</h2></p>";
flush_buffers();
}

foreach ($getfeeds as $myfeeds) {
	$url = $myfeeds[feed];
	$maxvideos = $myfeeds[maxvideos];
	$category = unserialize($myfeeds[category]);
	$category_next_page = $myfeeds[category];
	$poststatus = $myfeeds[poststatus];
	$commentstatus = $myfeeds[commentstatus];
	$pingstatus = $myfeeds[pingstatus];
	$checktitle = $myfeeds[checktitle];
	$checkdesc = $myfeeds[checkdesc];
	$checktags = $myfeeds[checktags];
	$postauthor = $myfeeds[postauthor];
	$scheduletime = $myfeeds[scheduletime];
	$grab_comments = $myfeeds[grab_comments];
	$max_comments = $myfeeds[max_comments];
	$aprove_comments = $myfeeds[aprove_comments];
	$blocktags = unserialize($myfeeds[blocktags]);
	$blocktags_next_page = $myfeeds[blocktags];
	$feedhost = strtolower($url);
	$feedhost = str_replace("http://", "", $feedhost);
	$feedhost = str_replace("www.", "", $feedhost);
	$feedhost = str_replace("playervideo.", "", $feedhost);
	$feedhost2 = strstr($feedhost, "/");
	if ($feedhost2) {$feedhost = str_replace($feedhost2, "", $feedhost);}
	if ($showoutput == "yes") {
	$showfeedhost = str_replace("en.", '', $feedhost);
	$showfeedhost = str_replace("gdata.", '', $showfeedhost);
	$showfeedhost = str_replace("rss.", '', $showfeedhost);
	$show_total_source++;
	echo "<p align=\"left\"><i><b>[".$show_total_source."] Connecting ".$showfeedhost."...</b></i> [<a href=\"".$url."\" target=\"_blank\" title=\"Go to ".$url."\">Check Link</a>]<br></p>";
	flush_buffers();
	}
	
	// Fetching Sources ------------------------------
$max = 1;
$grab_more = 0;
$grabbed = 0;

switch ($feedhost){
// Get Videos from Shufuni.com ------------------------------
case 'shufuni.com':
	$url = str_replace("http://www.shufuni.com/rssnews.xml?ct=", "http://www.shufuni.com/videos/?ct=", $url);
	$url = str_replace("&or=1", "", $url);
	$page_number = 1;
	do {
	if ($page_number > $maxpages+1) {break;}
	if ($page_number > "1") {
	if ($grab_next_page) {$url = $grab_next_page;}
	$show_total_source++;
	if ($showoutput == "yes") {
	echo "<p align=\"left\"><i><b>[".$show_total_source."] Connecting ".$showfeedhost." page ".$page_number."...</b></i> [<a href=\"".$url."\" target=\"_blank\" title=\"Go to ".$url."\">Check Link</a>]<br></p>";
	flush_buffers();
	}
	}
	$curlresult = connectSource($url, $userAgent, $usefollow, $proxies, $proxysources, $feedhost);
	if (!$curlresult) {$feednotfound++; $notfoundstats[] = $url; break;}
	$html= str_get_html($curlresult);
	$findtype = "SearchResult";
	$isbysearch = strpos($url, $findtype);
	if ($isbysearch === false) {
	$grab_infos = $html->find('a[class=lnkImgBorder]');
	$grab_vidtime = $html->find('div[class=TimeVideo]');
	$grab_next = $html->find('a[href*="&page"]', -1)->href;
	$check_next = $html->find('a[href*="&page"]', -1)->plaintext;
	if ($check_next == "Next &nbsp;") {$grab_next_page = "http://www.shufuni.com/videos/".$grab_next."";} else {unset($grab_next_page);}
	} else {
	$grab_infos = $html->find('a[class=SearchTitleVideo]');
	$grab_vidtime = $html->find('span[id$=Length]');
	$grab_next = $html->find('a[class=paging]', -1)->href;
	$check_next = $html->find('b[class=nextendprev]', -1)->plaintext;
	if ($check_next == "Next >>") {$grab_next_page = "http://www.shufuni.com/SearchResult.aspx".$grab_next."";} else {unset($grab_next_page);}
	}
	$grab_thumbs = $html->find('img[type=take]');
	$futuretime = 5; $pornmax = 1; $conta = 0; $grabbed_cp = 0;
foreach ($grab_infos as $element) {
	if($pornmax > $maxvideos) {break;} else {
	$title = $element->title;
	$vidurl_original = "http://www.shufuni.com".$element->href."";
	$thumbnail = $grab_thumbs[$conta]->src;
	$thumbnail = str_replace("wi110/hi83", "wi200/hi160", $thumbnail);
	$thumbnail = str_replace("wi160/hi120", "wi200/hi160", $thumbnail);
	$keywords = $grab_tags[$conta];
	$vidtime = $grab_vidtime[$conta]->plaintext;
	$title = fixEncoding($title);
	$checklink = sanitize_title($title);
	$cl2 = $wpdb->get_var("SELECT post_name FROM $wpdb->posts WHERE post_name = '$checklink'");
	if ($cl2) {$conta++; continue;}
	$curlresult = connectSource($vidurl_original, $userAgent, $usefollow, $proxies, $proxysources, $feedhost);
	if (!$curlresult) {$conta++; continue;}
	$sub_page= str_get_html($curlresult);
	$grab_desc = $sub_page->find('h2', 0);
	$description = $grab_desc->plaintext;
	preg_match_all("/href='\/searchresult.aspx\?search=(.*)'>(.*)<\/a>/Ui", $sub_page, $shuftags);
	$keywords = implode(" ", $shuftags[2]);
	$keywords = fixkeywords($keywords);
	$keywords = fixEncoding($keywords);
	$grab_embedcod = $sub_page->find('input[name$=EmbedCode]', 0);
	$embedcod = $grab_embedcod->value;
	$vidcod = strstr($embedcod, "videoCode=");
	$subvidcod = strstr($vidcod, "&quot;>");
	$vidcod = str_replace($subvidcod, "", $vidcod);
	$vidcod = str_replace("videoCode=", "", $vidcod);
	if (!$vidcod) {$conta++; continue;}
	if ($checktitle == "yes") {if (search_blocked_tags(strtolower($title), $blocktags)) {$conta++; continue;}}
	if ($checkdesc == "yes"){if (search_blocked_tags(strtolower($description), $blocktags)) {$conta++; continue;}}
	if ($checktags == "yes"){if (search_blocked_tags(strtolower($keywords), $blocktags)) {$conta++; continue;}}
	$postcontent = player_shufuni($vidcod,$pwsize,$phsize);
	$shufuni++;
	$mvbstats['Shufuni'] = $shufuni;
	savepost($category, $postname, $keywords, $thumbnail, $description, $postcontent, $poststatus, $title, $commentstatus, $pingstatus, $feedhost, $vidcod, $postauthor, $futuretime, $vidurl_original, $grab_comments, $max_comments, $aprove_comments, $vidtime);
$pornmax++; $conta++; $ptotaladded++; $grabbed++; $grabbed_cp++; $futuretime = $futuretime + $scheduletime;
	if ($showoutput == "yes") {
	echo "<p align=\"left\"><i><font color=\"green\">Video added:</font> ".$title." <font color=\"green\">(".$poststatus.")</font></i><br></p>";
	flush_buffers();
	}
	$grab_more = $maxvideos-$grabbed;
	if ($grab_more == "0") {break;}
	}
	$sub_page->clear(); 
	unset($sub_page);
}
	if (($grabbed_cp == "0") AND ($showoutput == "yes")) { echo "<p align=\"left\"><i>There is no new videos in this page.</i><br></p>"; flush_buffers();}
	$page_number++;
	$html->clear(); 
	unset($html);
	if (!$grab_next_page) {break;}
} while (($grab_more > "0") OR ($grabbed == "0"));
break;

// Get Videos from RedTube.com ------------------------------
case 'redtube.com':
	$page_number = 1;
	do {
	if ($page_number > $maxpages+1) {break;}
	if (($page_number > "1") AND ($showoutput == "yes")) {
	if ($grab_next_page) {$url = $grab_next_page;}
	$show_total_source++;
	if ($showoutput == "yes") {
	echo "<p align=\"left\"><i><b>[".$show_total_source."] Connecting ".$showfeedhost." page ".$page_number."...</b></i> [<a href=\"".$url."\" target=\"_blank\" title=\"Go to ".$url."\">Check Link</a>]<br></p>";
	flush_buffers();
	}
	}
	$curlresult = connectSource($url, $userAgent, $usefollow, $proxies, $proxysources, $feedhost);
	if (!$curlresult) {$feednotfound++; $notfoundstats[] = $url; break;}
	$html= str_get_html($curlresult);
	$grab_urls = $html->find('a[class=s]');
	$grab_infos = $html->find('img[class=t]');
	$grab_vidtime = $html->find('span[class=d]');
	$grab_next = $html->find('a[title="Next page"]', 0)->href;
	if ($grab_next) {$grab_next_page = $grab_next;} else {unset($grab_next_page);}
	$futuretime = 5; $pornmax = 1; $conta = 0; $grabbed_cp = 0;
foreach ($grab_infos as $element) {
	if($pornmax > $maxvideos) {break;} else {
	$title = fixEncoding($element->title);
	$checklink = sanitize_title($title);
	$cl2 = $wpdb->get_var("SELECT post_name FROM $wpdb->posts WHERE post_name = '$checklink'");
	if ($cl2) {$conta++; continue;}
	$thumbnail = $element->src;
	$vidcod = $element->id;
	if (!$vidcod) {$conta++; continue;}
	$description = "";
	$keywords = ereg_replace("[0123456789'.!#?$%\]","",$title);
	$keywords = fixpornkeywords($keywords);
	$keywords = fixEncoding($keywords);
	if ($checktitle == "yes") {if (search_blocked_tags(strtolower($title), $blocktags)) {$conta++; continue;}}
	if ($checkdesc == "yes"){if (search_blocked_tags(strtolower($description), $blocktags)) {$conta++; continue;}}
	if ($checktags == "yes"){if (search_blocked_tags(strtolower($keywords), $blocktags)) {$conta++; continue;}}
	$postcontent = player_redtube($vidcod,$pwsize,$phsize);
	$redtube++;
	$mvbstats['RedTube'] = $redtube;
	$vidurl_original = $grab_urls[$conta]->href;
	$vidtime = $grab_vidtime[$conta]->plaintext;
	savepost($category, $postname, $keywords, $thumbnail, $description, $postcontent, $poststatus, $title, $commentstatus, $pingstatus, $feedhost, $vidcod, $postauthor, $futuretime, $vidurl_original, $grab_comments, $max_comments, $aprove_comments, $vidtime);
	$pornmax++; $conta++; $ptotaladded++; $grabbed++; $grabbed_cp++; $futuretime = $futuretime + $scheduletime;
	if ($showoutput == "yes") {
	echo "<p align=\"left\"><i><font color=\"green\">Video added:</font> ".$title." <font color=\"green\">(".$poststatus.")</font></i><br></p>";
	flush_buffers();
	}
	$grab_more = $maxvideos-$grabbed;
	if ($grab_more == "0") {break;}
	}
}
	$html->clear(); 
	unset($html);
	if (($grabbed_cp == "0") AND ($showoutput == "yes")) { echo "<p align=\"left\"><i>There is no new videos in this page.</i><br></p>"; flush_buffers();}
	$page_number++;
	if (!$grab_next_page) {break;}
} while (($grab_more > "0") OR ($grabbed == "0"));
break;

// Get Videos from Xvideos.com ------------------------------
case 'xvideos.com':
	$page_number = 0;
	do {
	if (($page_number > $maxpages) OR ($page_number > "8")) {break;}
	if ($page_number > "0") {
	if ($grab_next_page) {$url = $grab_next_page;}
	$show_total_source++;
	if ($showoutput == "yes") {
	echo "<p align=\"left\"><i><b>[".$show_total_source."] Connecting ".$showfeedhost." page ".$page_number."...</b></i> [<a href=\"".$url."\" target=\"_blank\" title=\"Go to ".$url."\">Check Link</a>]<br></p>";
	flush_buffers();
	}
	}
	$curlresult = connectSource($url, $userAgent, $usefollow, $proxies, $proxysources, $feedhost);
	if (!$curlresult) {$feednotfound++; $notfoundstats[] = $url; break;}
	$html= str_get_html($curlresult);
	$grab_urls = $html->find('a[class=miniature]');
	$grab_titles = $html->find('span[class=red]');
	$grab_thumbs = $html->find('img[class=borderx]');
	$grab_vidtime = $html->find('strong');
	$grab_next = $html->find('a[class=nP]', 1)->href;
	if ($grab_next) {$grab_next_page = "http://www.xvideos.com".$grab_next."";} else {unset($grab_next_page);}
	$futuretime = 5; $pornmax = 1; $conta = 0; $grabbed_cp = 0;
foreach ($grab_urls as $element) {
	if($pornmax > $maxvideos) {break;} else {
	$title = $grab_titles[$conta]->plaintext;
	$title = fixEncoding($title);
	$checklink = sanitize_title($title);
	$cl2 = $wpdb->get_var("SELECT post_name FROM $wpdb->posts WHERE post_name = '$checklink'");
	if ($cl2) {$conta++; continue;}
	$thumbnail = $grab_thumbs[$conta]->src;
	$vidurl_original = $element->href;
	$vidcod = str_replace("http://www.xvideos.com/video", '', $vidurl_original);
	$vidcod2 = strstr($vidcod, "/");
	$vidcod = str_replace($vidcod2, "", $vidcod);
	$description = "";
	$subvid = connectSource($vidurl_original, $userAgent, $usefollow, $proxies, $proxysources, $feedhost);
	$sub_page = str_get_html($subvid);
	$getkeywords = $sub_page->find('a[href^=/tags/]');
	$keywords = strtolower(strip_tags(implode(",", $getkeywords)));
	if ($checktitle == "yes") {if (search_blocked_tags(strtolower($title), $blocktags)) {$conta++; continue;}}
	if ($checkdesc == "yes"){if (search_blocked_tags(strtolower($description), $blocktags)) {$conta++; continue;}}
	if ($checktags == "yes"){if (search_blocked_tags(strtolower($keywords), $blocktags)) {$conta++; continue;}}
	$postcontent = player_xvideos($vidcod,$pwsize,$phsize);
	$xvideos++;
	$mvbstats['Xvideos'] = $xvideos;
	$vidtime = str_replace("(", "", $grab_vidtime[$conta+4]->plaintext);
	$vidtime = str_replace(")", "", $vidtime);
	$vidtime = fixVidTime($vidtime);
	savepost($category, $postname, $keywords, $thumbnail, $description, $postcontent, $poststatus, $title, $commentstatus, $pingstatus, $feedhost, $vidcod, $postauthor, $futuretime, $vidurl_original, $grab_comments, $max_comments, $aprove_comments, $vidtime);
	$pornmax++; $conta++; $ptotaladded++; $grabbed++; $grabbed_cp++; $futuretime = $futuretime + $scheduletime;
	if ($showoutput == "yes") {
	echo "<p align=\"left\"><i><font color=\"green\">Video added:</font> ".$title." <font color=\"green\">(".$poststatus.")</font></i><br></p>";
	flush_buffers();
	}
	$grab_more = $maxvideos-$grabbed;
	if ($grab_more == "0") {break;}
	}
	$sub_page->clear(); 
	unset($sub_page);
}
	if (($grabbed_cp == "0") AND ($showoutput == "yes")) {echo "<p align=\"left\"><i>There is no new videos in this page.</i><br></p>"; flush_buffers();}
	$page_number++;
	$html->clear(); 
	unset($html);
	if (!$grab_next_page) {break;}
} while (($grab_more > "0") OR ($grabbed == "0"));
break;
// Get Videos from PornHub.com ------------------------------
case 'pornhub.com':
	$page_number = 1;
	do {
	if ($page_number > $maxpages+1) {break;}
	if ($page_number > "1") {
	if ($grab_next_page) {$url = $grab_next_page;}
	$show_total_source++;
	if ($showoutput == "yes") {
	echo "<p align=\"left\"><i><b>[".$show_total_source."] Connecting ".$showfeedhost." page ".$page_number."...</b></i> [<a href=\"".$url."\" target=\"_blank\" title=\"Go to ".$url."\">Check Link</a>]<br></p>";
	flush_buffers();
	}
	}
	$curlresult = connectSource($url, $userAgent, $usefollow, $proxies, $proxysources, $feedhost);
	if (!$curlresult) {$feednotfound++; $notfoundstats[] = $url; break;}
	$html= str_get_html($curlresult);
	$grab_urls = $html->find('a[class=img]');
	$grab_infos = $html->find('img[class=rotating]');
	$grab_vidtime = $html->find('var[class=duration]');
	$grab_next = $html->find('a[href*=page]');
	if ($grab_next) {$grab_next = array_reverse($grab_next); $grab_next_page = "http://www.pornhub.com".$grab_next[0]->href."";} else {unset($grab_next_page);}
	$futuretime = 5; $pornmax = 1; $conta = 0; $grabbed_cp = 0;
foreach ($grab_infos as $element) {
	if($pornmax > $maxvideos) {break;} else {
	$title = fixEncoding($element->alt);
	$checklink = sanitize_title($title);
	$cl2 = $wpdb->get_var("SELECT post_name FROM $wpdb->posts WHERE post_name = '$checklink'");
	if ($cl2) {$conta++; continue;}
	$thumbnail = $element->src;
	$vidurl_original = $grab_urls[$conta]->href;
	$vidcod = $element->id;
	if (!$vidcod) {$conta++; continue;}
	$description = "";
	$curlresult = connectSource($vidurl_original, $userAgent, $usefollow, $proxies, $proxysources, $feedhost);
	$sub_page= str_get_html($curlresult);
	$getkeywords = $sub_page->find('a[href^=/video/search]');
	$keywords = strtolower(strip_tags(implode(",", $getkeywords)));
	$keywords = fixEncoding($keywords);
	if ($checktitle == "yes") {if (search_blocked_tags(strtolower($title), $blocktags)) {$conta++; continue;}}
	if ($checkdesc == "yes"){if (search_blocked_tags(strtolower($description), $blocktags)) {$conta++; continue;}}
	if ($checktags == "yes"){if (search_blocked_tags(strtolower($keywords), $blocktags)) {$conta++; continue;}}
	$postcontent = player_pornhub($vidcod,$pwsize,$phsize);
	$pornhub++;
	$mvbstats['PornHub'] = $pornhub;
	$vidtime = $grab_vidtime[$conta]->plaintext;
	savepost($category, $postname, $keywords, $thumbnail, $description, $postcontent, $poststatus, $title, $commentstatus, $pingstatus, $feedhost, $vidcod, $postauthor, $futuretime, $vidurl_original, $grab_comments, $max_comments, $aprove_comments, $vidtime);
	$pornmax++; $conta++; $ptotaladded++; $grabbed++; $grabbed_cp++; $futuretime = $futuretime + $scheduletime;
	$sub_page->clear(); 
	unset($sub_page);
	if ($showoutput == "yes") {
	echo "<p align=\"left\"><i><font color=\"green\">Video added:</font> $title <font color=\"green\">($poststatus)</font></i><br></p>";
	flush_buffers();
	}
	$grab_more = $maxvideos-$grabbed;
	if ($grab_more == "0") {break;}
	}
}
	if (($grabbed_cp == "0") AND ($showoutput == "yes")) {echo "<p align=\"left\"><i>There is no new videos in this page.</i><br></p>"; flush_buffers();}
	$page_number++;
	$html->clear(); 
	unset($html);
	if (!$grab_next_page) {break;}
} while (($grab_more > "0") OR ($grabbed == "0"));
break;
// Get Videos from HardSexTube.com ------------------------------
case 'hardsextube.com':
	$page_number = 1;
	do {
	if ($page_number > $maxpages+1) {break;}
	if ($page_number > "1") {
	if ($grab_next_page) {$url = $grab_next_page;}
	$show_total_source++;
	if ($showoutput == "yes") {
	echo "<p align=\"left\"><i><b>[".$show_total_source."] Connecting ".$showfeedhost." page ".$page_number."...</b></i> [<a href=\"".$url."\" target=\"_blank\" title=\"Go to ".$url."\">Check Link</a>]<br></p>";
	flush_buffers();
	}
	}
	$curlresult = connectSource($url, $userAgent, $usefollow, $proxies, $proxysources, $feedhost);
	if (!$curlresult) {$feednotfound++; $notfoundstats[] = $url; break;}
	$html= str_get_html($curlresult);
	$grab_infos = $html->find('a[rel=external]');
	$grab_vidtime = $html->find('div[style*=width: 70px]');
	$grab_thumb = $html->find('img[style=vertical-align:top;]');
	$get_next = $html->find('a[href^=http://www.hardsextube.com/?p=Search]', 0)->href;
	$get_next1 = strstr($get_next, '/Submission_time/');
	$np_url = str_replace($get_next1, "", $get_next);
	$grab_next = "".$np_url."/Submission_time/:".$page_number."";
	if ($np_url) {$grab_next_page = $grab_next;} else {unset($grab_next_page);}
	$futuretime = 5; $pornmax = 1; $conta = 0; $grabbed_cp = 0;
foreach ($grab_infos as $element) {
	if($pornmax > $maxvideos) {break;} else {
	$title = fixEncoding($element->plaintext);
	$checklink = sanitize_title($title);
	$vidurl_original = $element->href;
	$cl2 = $wpdb->get_var("SELECT post_name FROM $wpdb->posts WHERE post_name = '$checklink'");
	if ($cl2) {$conta++; continue;}
	$vidtime = $grab_vidtime[$conta-4]->plaintext;
	$thumbnail = $grab_thumb[$conta]->src;
	if (!$vidtime) {$conta++; continue;}
	$curlresult = connectSource($vidurl_original, $userAgent, $usefollow, $proxies, $proxysources, $feedhost);
	$sub_page= str_get_html($curlresult);
	$getkeywords = $sub_page->find('meta[name=Keywords]', 0)->content;
	$keywords = fixkeywords($getkeywords);
	$getdesc = $sub_page->find('meta[name=Description]', 0)->content;
	$desfix1 = strstr($getdesc, ' -');
	$description = str_replace($desfix1, "", $getdesc);
	$getcod = str_replace("http://www.hardsextube.com/video/", "", $vidurl_original);
	$fixcod = strstr($getcod, '/');
	$vidcod = str_replace($fixcod, "", $getcod);
	if ($checktitle == "yes") {if (search_blocked_tags(strtolower($title), $blocktags)) {$conta++; continue;}}
	if ($checkdesc == "yes"){if (search_blocked_tags(strtolower($description), $blocktags)) {$conta++; continue;}}
	if ($checktags == "yes"){if (search_blocked_tags(strtolower($keywords), $blocktags)) {$conta++; continue;}}
	$postcontent = player_hardsextube($vidcod,$pwsize,$phsize);
	$hardsextube++;
	$mvbstats['Hardsextube'] = $hardsextube;
	savepost($category, $postname, $keywords, $thumbnail, $description, $postcontent, $poststatus, $title, $commentstatus, $pingstatus, $feedhost, $vidcod, $postauthor, $futuretime, $vidurl_original, $grab_comments, $max_comments, $aprove_comments, $vidtime);
	$pornmax++; $conta++; $ptotaladded++; $grabbed++; $grabbed_cp++; $futuretime = $futuretime + $scheduletime;
	$sub_page->clear(); 
	unset($sub_page);
	if ($showoutput == "yes") {
	echo "<p align=\"left\"><i><font color=\"green\">Video added:</font> $title <font color=\"green\">($poststatus)</font></i><br></p>";
	flush_buffers();
	}
	$grab_more = $maxvideos-$grabbed;
	if ($grab_more == "0") {break;}
	}
}
	if (($grabbed_cp == "0") AND ($showoutput == "yes")) {echo "<p align=\"left\"><i>There is no new videos in this page.</i><br></p>"; flush_buffers();}
	$page_number++;
	$html->clear(); 
	unset($html);
	if (!$grab_next_page) {break;}
} while (($grab_more > "0") OR ($grabbed == "0"));
break;
// Get Videos from DeviantClip.com ------------------------------
case 'deviantclip.com':
	$page_number = 1;
	do {
	if ($page_number > $maxpages+1) {break;}
	if ($page_number > "1") {
	if ($grab_next_page) {$url = $grab_next_page;}
	$show_total_source++;
	if ($showoutput == "yes") {
	echo "<p align=\"left\"><i><b>[".$show_total_source."] Connecting ".$showfeedhost." page ".$page_number."...</b></i> [<a href=\"".$url."\" target=\"_blank\" title=\"Go to ".$url."\">Check Link</a>]<br></p>";
	flush_buffers();
	}
	}
	$curlresult = connectSource($url, $userAgent, $usefollow, $proxies, $proxysources, $feedhost);
	if (!$curlresult) {$feednotfound++; $notfoundstats[] = $url; break;}
	$html= str_get_html($curlresult);
	$grab_urls = $html->find('a[href^=/Media]');
	$grab_infos = $html->find('img[id^=media]');
	$grab_stats = $html->find('span[class=stats]');
	$grab_next = $html->find('a[rel=Next]', 0)->href;
	if ($grab_next) {$grab_next_page = "http://www.deviantclip.com".$grab_next."";} else {unset($grab_next_page);}
	$futuretime = 5; $pornmax = 1; $conta = 0; $grabbed_cp = 0;
foreach ($grab_infos as $element) {
	if($pornmax > $maxvideos) {break;} else {
	$title = fixEncoding($element->title);
	$checklink = sanitize_title($title);
	$cl2 = $wpdb->get_var("SELECT post_name FROM $wpdb->posts WHERE post_name = '$checklink'");
	if ($cl2) {$conta++; continue;}
	$vidcod = $element->id;
	$vidcod = str_replace("media-", "", $vidcod);
	if (!$vidcod) {$conta++; continue;}
	$thumbnail = $element->src;
	$vidurl_original = "http://www.deviantclip.com".$grab_urls[$conta]->href."";
	$is_picture = $grab_stats[$conta];
	$checkpic = array(pics, pic);
	if (search_blocked_tags(strtolower($is_picture), $checkpic)) {$conta++; continue;}
	$postcontent = player_deviantclip($vidcod,$pwsize,$phsize);
	$curlresult = connectSource($vidurl_original, $userAgent, $usefollow, $proxies, $proxysources, $feedhost);
	if (preg_match("/Sorry, embeds are not available for WMVs/i", $curlresult)) {$conta++; continue;}
	$sub_page= str_get_html($curlresult);
	$description = $sub_page->find('div[class="main-sectiondescription"]', 0)->plaintext;
	$getkeywords = $sub_page->find('a[href^=/search/]');
	$keywords = strtolower(strip_tags(implode(",", $getkeywords)));
	$keywords = str_replace(",see all related videos", "", $keywords);
	if ($checktitle == "yes") {if (search_blocked_tags(strtolower($title), $blocktags)) {$conta++; continue;}}
	if ($checkdesc == "yes"){if (search_blocked_tags(strtolower($description), $blocktags)) {$conta++; continue;}}
	if ($checktags == "yes"){if (search_blocked_tags(strtolower($keywords), $blocktags)) {$conta++; continue;}}
	$deviantclip++;
	$mvbstats['DeviantClip'] = $deviantclip; 
	$description = trim(substr((str_replace("\n", ' ', str_replace("\r", ' ', strip_tags(StupefyEntities($description))))),0,$descsize))."";
	$vidtime = $grab_stats[$conta]->plaintext;
	if (preg_match("/(.*)m (.*)s(.*)/Ui", $vidtime, $makevidtime)) {
	if (($makevidtime[2] == "1") OR ($makevidtime[2] == "2") OR ($makevidtime[2] == "3") OR ($makevidtime[2] == "4")  OR ($makevidtime[2] == "5") OR ($makevidtime[2] == "6") OR ($makevidtime[2] == "7") OR ($makevidtime[2] == "8") OR ($makevidtime[2] == "0") OR ($makevidtime[2] == "0")) {
	$vidtime = "".$makevidtime[1].":0".$makevidtime[2]."";
	} else {
	$vidtime = "".$makevidtime[1].":".$makevidtime[2]."";
	}
	}
	savepost($category, $postname, $keywords, $thumbnail, $description, $postcontent, $poststatus, $title, $commentstatus, $pingstatus, $feedhost, $vidcod, $postauthor, $futuretime, $vidurl_original, $grab_comments, $max_comments, $aprove_comments, $vidtime);
	$sub_page->clear(); 
	unset($sub_page);
	$pornmax++; $conta++; $ptotaladded++; $grabbed++; $grabbed_cp++; $futuretime = $futuretime + $scheduletime;
	if ($showoutput == "yes") {
	echo "<p align=\"left\"><i><font color=\"green\">Video added:</font> $title <font color=\"green\">($poststatus)</font></i><br></p>";
	flush_buffers();
	}
	$grab_more = $maxvideos-$grabbed;
	if ($grab_more == "0") {break;}
	}
}
	if (($grabbed_cp == "0") AND ($showoutput == "yes")) {echo "<p align=\"left\"><i>There is no new videos in this page.</i><br></p>"; flush_buffers();}
	$page_number++;
	$html->clear(); 
	unset($html);
	if (!$grab_next_page) {break;}
} while (($grab_more > "0") OR ($grabbed == "0"));
break;

// Get Videos from KeezMovies.com ------------------------------
case 'keezmovies.com':
	$page_number = 1;
	do {
	if ($page_number > $maxpages+1) {break;}
	if ($page_number > "1") {
	if ($grab_next_page) {$url = $grab_next_page;}
	$show_total_source++;
	if ($showoutput == "yes") {
	echo "<p align=\"left\"><i><b>[".$show_total_source."] Connecting ".$showfeedhost." page ".$page_number."...</b></i> [<a href=\"".$url."\" target=\"_blank\" title=\"Go to ".$url."\">Check Link</a>]<br></p>";
	flush_buffers();
	}
	}
	$curlresult = connectSource($url, $userAgent, $usefollow, $proxies, $proxysources, $feedhost);
	if (!$curlresult) {$feednotfound++; $notfoundstats[] = $url; break;}
	$html= str_get_html($curlresult);
	$grab_infos = $html->find('a[class=img]');
	$grab_thumbs = $html->find('img[class=rotating]');
	$grab_vidtime = $html->find('var[class=duration]');
	$grab_next = $html->find('a[href*=page]');
	if ($grab_next) {$grab_next = array_reverse($grab_next); $grab_next_page = "http://www.keezmovies.com".$grab_next[0]->href."";} else {unset($grab_next_page);}
	preg_match_all("/href=\"(.*)\" class=\"img\" title=\"(.*)\"/Ui", $curlresult, $theinfo);
	preg_match_all("/img src=[\"]?([^\" >]+)[\" >] alt=\"(.*)\" class=\"rotating\"/Ui", $curlresult, $thethumb);
	$futuretime = 5; $pornmax = 1; $conta = 0; $grabbed_cp = 0;
foreach ($grab_infos as $element) {
	if($pornmax > $maxvideos) {break;} else {
	$title = fixEncoding($element->title);
	$checklink = sanitize_title($title);
	$cl2 = $wpdb->get_var("SELECT post_name FROM $wpdb->posts WHERE post_name = '$checklink'");
	if ($cl2) {$conta++; continue;}
	$vidurl_original = $element->href;
	$vidtime = $grab_vidtime[$conta]->plaintext;
	$thumbnail = $grab_thumbs[$conta]->src;
	$fixthumb = strstr($thumbnail, "?");
	$thumbnail = str_replace($fixthumb, "", $thumbnail);
	$thumbnail = str_replace("small", "large", $thumbnail);
	if (strpos($vidurl_original, "pornhub")) {continue;}
	if (strpos($vidurl_original, "tube8")) {continue;}
	if (strpos($vidurl_original, "extremetube")) {continue;}
	if (strpos($vidurl_original, "videobash")) {continue;}
	$curlresult = connectSource($vidurl_original, $userAgent, $usefollow, $proxies, $proxysources, $feedhost);
	$html_subpage= str_get_html($curlresult);
	$description = $html_subpage->find('meta[name=description]', 0)->content;
	$vidcod = $html_subpage->find('input[id=video_id]', 0)->value;
	$keywords = $html_subpage->find('h2[class=regular]', 0)->plaintext;
	$keywords = fixEncoding($keywords);
	if (!$vidcod) {$conta++; continue;}
	if ($checktitle == "yes") {if (search_blocked_tags(strtolower($title), $blocktags)) {$conta++; continue;}}
	if ($checkdesc == "yes"){if (search_blocked_tags(strtolower($description), $blocktags)) {$conta++; continue;}}
	if ($checktags == "yes"){if (search_blocked_tags(strtolower($keywords), $blocktags)) {$conta++; continue;}}
	$postcontent = player_keezmovies($vidcod,$pwsize,$phsize);
	$keezmovies++;
	$mvbstats['KeezMovies'] = $keezmovies;
	$description = trim(substr((str_replace("\n", ' ', str_replace("\r", ' ', strip_tags(StupefyEntities($description))))),0,$descsize))."";
	savepost($category, $postname, $keywords, $thumbnail, $description, $postcontent, $poststatus, $title, $commentstatus, $pingstatus, $feedhost, $vidcod, $postauthor, $futuretime, $vidurl_original, $grab_comments, $max_comments, $aprove_comments, $vidtime);
	$pornmax++; $conta++; $ptotaladded++; $grabbed++; $grabbed_cp++; $futuretime = $futuretime + $scheduletime;
	if ($showoutput == "yes") {
	echo "<p align=\"left\"><i><font color=\"green\">Video added:</font> $title <font color=\"green\">($poststatus)</font></i><br></p>";
	flush_buffers();
	}
	$html_subpage->clear(); 
	unset($html_subpage);
	$grab_more = $maxvideos-$grabbed;
	if ($grab_more == "0") {break;}
	}
}
	if (($grabbed_cp == "0") AND ($showoutput == "yes")) {echo "<p align=\"left\"><i>There is no new videos in this page.</i><br></p>"; flush_buffers();}
	$page_number++;
	$html->clear(); 
	unset($html);
	if (!$grab_next_page) {break;}
} while (($grab_more > "0") OR ($grabbed == "0"));
break;

// Get Videos from MegaPorn.com ------------------------------
case 'megaporn.com':
	$page_number = 1;
	do {
	if ($page_number > $maxpages+1) {break;}
	if ($page_number > "1") {
	if ($grab_next_page) {$url = $grab_next_page;}
	$show_total_source++;
	if ($showoutput == "yes") {
	echo "<p align=\"left\"><i><b>[".$show_total_source."] Connecting ".$showfeedhost." page ".$page_number."...</b></i> [<a href=\"".$url."\" target=\"_blank\" title=\"Go to ".$url."\">Check Link</a>]<br></p>";
	flush_buffers();
	}
	}
	$curlresult = connectSource($url, $userAgent, $usefollow, $proxies, $proxysources, $feedhost);
	if (!$curlresult) {$feednotfound++; $notfoundstats[] = $url; break;}
	$findcat = "categories"; $iscategory = strpos($url, $findcat);
	$findchannel = "channels"; $ischannel = strpos($url, $findchannel);
	$html= str_get_html($curlresult);
	if (($iscategory === false) AND ($ischannel === false)) {
	$grab_thumbs = $html->find('img[width=125]');
	$grab_infos = $html->find('a[style^=font-size:14px]');
	$grab_desc = $html->find('div[class=v4]');
	$grab_vidtime = $html->find('font[style^=font-weight:bold]');
	} else {
	$grab_thumbs = $html->find('img[width=120]');
	$grab_infos = $html->find('a[style^=color:#F21F77]');
	preg_match_all("/<div style=\"position:absolute; left:13px; top:158px; width:130px; text-align:left; font-size:11px;\"><font color=\"#000000\">(.*)<\/font>(.*)<\/div>/Uis", $html, $thetime);
	}
	$grab_next = $html->find('a[accesskey=n]');
	if ($grab_next) {$grab_next = array_reverse($grab_next); $grab_next_page = "http://www.megaporn.com/video/".$grab_next[0]->href."";} else {unset($grab_next_page);}

	$futuretime = 5; $pornmax = 1; $conta = 0; $grabbed_cp = 0;
foreach ($grab_infos as $element) {
	if($pornmax > $maxvideos) {break;} else {
	$title = fixEncoding($element->plaintext);
	$checklink = sanitize_title($title);
	$cl2 = $wpdb->get_var("SELECT post_name FROM $wpdb->posts WHERE post_name = '$checklink'");
	if ($cl2) {$conta++; continue;}
	$thumbnail = $grab_thumbs[$conta]->src;
	if (($iscategory === false) AND ($ischannel === false)) {
	$vidtime = $grab_vidtime[$conta]->plaintext;
	} else {
	$vidtime = $thetime[2][$conta];
	}
	$description = $grab_desc[$conta]->plaintext;
	$keywords = preg_replace("/[0123456789'.!#?$%]/","",$title);
	$keywords = fixpornkeywords($keywords);
	$keywords = fixEncoding($keywords);
	if ($checktitle == "yes") {if (search_blocked_tags(strtolower($title), $blocktags)) {$conta++; continue;}}
	if ($checkdesc == "yes"){if (search_blocked_tags(strtolower($description), $blocktags)) {$conta++; continue;}}
	if ($checktags == "yes"){if (search_blocked_tags(strtolower($keywords), $blocktags)) {$conta++; continue;}}
	$vidurl_original = "http://www.megaporn.com/video/".$grab_infos[$conta]->href."";
	$curlresult = connectSource($vidurl_original, $userAgent, $usefollow, $proxies, $proxysources, $feedhost);
	preg_match("/value=\"http:\/\/www.megaporn.com\/e\/(.*)\"/Ui", $curlresult, $thevidcod);
	$vidcod = $thevidcod[1];
	if (!$vidcod) {$conta++; continue;}
	$postcontent = player_megaporn($vidcod,$pwsize,$phsize);
	$megaporn++;
	$mvbstats['MegaPorn'] = $megaporn;
	$description = trim(substr((str_replace("\n", ' ', str_replace("\r", ' ', strip_tags(StupefyEntities($description))))),0,$descsize))."";
	savepost($category, $postname, $keywords, $thumbnail, $description, $postcontent, $poststatus, $title, $commentstatus, $pingstatus, $feedhost, $vidcod, $postauthor, $futuretime, $vidurl_original, $grab_comments, $max_comments, $aprove_comments, $vidtime);
	$pornmax++; $conta++; $ptotaladded++; $grabbed++; $grabbed_cp++; $futuretime = $futuretime + $scheduletime;
	if ($showoutput == "yes") {
	echo "<p align=\"left\"><i><font color=\"green\">Video added:</font> $title <font color=\"green\">($poststatus)</font></i><br></p>";
	flush_buffers();
	}
	$grab_more = $maxvideos-$grabbed;
	if ($grab_more == "0") {break;}
	}
}
	if (($grabbed_cp == "0") AND ($showoutput == "yes")) {echo "<p align=\"left\"><i>There is no new videos in this page.</i><br></p>"; flush_buffers();}
	$page_number++;
	$html->clear(); 
	unset($html);
	if (!$grab_next_page) {break;}
} while (($grab_more > "0") OR ($grabbed == "0"));
break;

// Get Videos from MegaVideo.com ------------------------------
case 'megavideo.com':
	$page_number = 1;
	do {
	if ($page_number > $maxpages+1) {break;}
	if ($page_number > "1") {
	if ($grab_next_page) {$url = $grab_next_page;}
	$show_total_source++;
	if ($showoutput == "yes") {
	echo "<p align=\"left\"><i><b>[".$show_total_source."] Connecting ".$showfeedhost." page ".$page_number."...</b></i> [<a href=\"".$url."\" target=\"_blank\" title=\"Go to ".$url."\">Check Link</a>]<br></p>";
	flush_buffers();
	}
	}
	$curlresult = connectSource($url, $userAgent, $usefollow, $proxies, $proxysources, $feedhost);
	if (!$curlresult) {$feednotfound++; $notfoundstats[] = $url; break;}
	$findcat = "categories"; $iscategory = strpos($url, $findcat);
	$findchannel = "channels"; $ischannel = strpos($url, $findchannel);
	$html= str_get_html($curlresult);
	if (($iscategory === false) AND ($ischannel === false)) {
	$grab_thumbs = $html->find('img[width=125]');
	$grab_infos = $html->find('a[style^=font-size:14px]');
	$grab_desc = $html->find('div[class=v4]');
	$grab_vidtime = $html->find('font[style^=font-weight:bold]');
	} else {
	$grab_thumbs = $html->find('img[width=120]');
	$grab_infos = $html->find('a[style^=color:#FD0819]');
	preg_match_all("/<div style=\"position:absolute; left:13px; top:158px; width:130px; text-align:left; font-size:11px;\"><font color=\"#000000\">(.*)<\/font>(.*)<\/div>/Uis", $html, $thetime);
	}
	$grab_next = $html->find('a[accesskey=n]');
	if ($grab_next) {$grab_next = array_reverse($grab_next); $grab_next_page = "http://www.megavideo.com/".$grab_next[0]->href."";} else {unset($grab_next_page);}
	$futuretime = 5; $pornmax = 1; $conta = 0; $grabbed_cp = 0;
foreach ($grab_infos as $element) {
	if($pornmax > $maxvideos) {break;} else {
	$title = fixEncoding($element->plaintext);
	$checklink = sanitize_title($title);
	$cl2 = $wpdb->get_var("SELECT post_name FROM $wpdb->posts WHERE post_name = '$checklink'");
	if ($cl2) {$conta++; continue;}
	$thumbnail = $grab_thumbs[$conta]->src;
	if (($iscategory === false) AND ($ischannel === false)) {
	$vidtime = $grab_vidtime[$conta]->plaintext;
	} else {
	$vidtime = $thetime[2][$conta];
	}
	$description = $grab_desc[$conta]->plaintext;
	$keywords = ereg_replace("[0123456789'.!#?$%\]","",$title);
	$keywords = fixpornkeywords($keywords);
	$keywords = fixEncoding($keywords);
	if ($checktitle == "yes") {if (search_blocked_tags(strtolower($title), $blocktags)) {$conta++; continue;}}
	if ($checkdesc == "yes"){if (search_blocked_tags(strtolower($description), $blocktags)) {$conta++; continue;}}
	if ($checktags == "yes"){if (search_blocked_tags(strtolower($keywords), $blocktags)) {$conta++; continue;}}
	$vidurl_original = "http://www.megavideo.com/".$grab_infos[$conta]->href."";
	$curlresult = connectSource($vidurl_original, $userAgent, $usefollow, $proxies, $proxysources, $feedhost);
	preg_match("/value=\"http:\/\/www.megavideo.com\/v\/(.*)\"/Ui", $curlresult, $thevidcod);
	$vidcod = $thevidcod[1];
	if (!$vidcod) {$conta++; continue;}
	$postcontent = player_megavideo($vidcod,$pwsize,$phsize);
	$megavideo++;
	$mvbstats['MegaVideo'] = $megavideo;
	$description = trim(substr((str_replace("\n", ' ', str_replace("\r", ' ', strip_tags(StupefyEntities($description))))),0,$descsize))."";
	savepost($category, $postname, $keywords, $thumbnail, $description, $postcontent, $poststatus, $title, $commentstatus, $pingstatus, $feedhost, $vidcod, $postauthor, $futuretime, $vidurl_original, $grab_comments, $max_comments, $aprove_comments, $vidtime);
	$pornmax++; $conta++; $ptotaladded++; $grabbed++; $grabbed_cp++; $futuretime = $futuretime + $scheduletime;
	if ($showoutput == "yes") {
	echo "<p align=\"left\"><i><font color=\"green\">Video added:</font> $title <font color=\"green\">($poststatus)</font></i><br></p>";
	flush_buffers();
	}
	$grab_more = $maxvideos-$grabbed;
	if ($grab_more == "0") {break;}
	}
}
	if (($grabbed_cp == "0") AND ($showoutput == "yes")) {echo "<p align=\"left\"><i>There is no new videos in this page.</i><br></p>"; flush_buffers();}
	$page_number++;
	$html->clear(); 
	unset($html);
	if (!$grab_next_page) {break;}
} while (($grab_more > "0") OR ($grabbed == "0"));
break;

// Get Videos from Globo.com ------------------------------
case 'globo.com':
	$page_number = 1;
	do {
	if ($page_number > $maxpages+1) {break;}
	if ($page_number > "1") {
	if ($grab_next_page) {$url = $grab_next_page;}
	$show_total_source++;
	if ($showoutput == "yes") {
	echo "<p align=\"left\"><i><b>[".$show_total_source."] Connecting ".$showfeedhost." page ".$page_number."...</b></i> [<a href=\"".$url."\" target=\"_blank\" title=\"Go to ".$url."\">Check Link</a>]<br></p>";
	flush_buffers();
	}
	}
	$curlresult = connectSource($url, $userAgent, $usefollow, $proxies, $proxysources, $feedhost);
	if (!$curlresult) {$feednotfound++; $notfoundstats[] = $url; break;}
	$findme = "N&atilde;o foram encontrados resultados";
	if (strpos($curlresult, $findme)) {$feednotfound++; $notfoundstats[] = $url; break;}
	$html= str_get_html($curlresult);
	$grab_infos = $html->find('a[class=crop-foto]');
	$grab_thumbs = $html->find('img[width=90]');
	$grab_desc = $html->find('div.conteudo-texto p');
	$grab_vidtime = $html->find('span[class=tempo]');
	$grab_next = $page_number+1;
	if ($grab_next) {$url2 = strstr($url, "&p="); $url = str_replace($url2, "", $url); $grab_next_page = "".$url."&p=".$grab_next."";} else {unset($grab_next_page);}
	$futuretime = 5; $pornmax = 1; $conta = 0; $grabbed_cp = 0;
foreach ($grab_infos as $element) {
	if($pornmax > $maxvideos) {break;} else {
	$title = fixEncoding($element->title);
	$checklink = sanitize_title($title);
	$cl2 = $wpdb->get_var("SELECT post_name FROM $wpdb->posts WHERE post_name = '$checklink'");
	if ($cl2) {$conta++; continue;}
	$thumb_small = $grab_thumbs[$conta]->src;
	$thumb_cod = str_replace("http://video.globo.com/GMC/foto/0,,", "", $thumb_small);
	$thumb_cod = str_replace(",00.jpg", "", $thumb_cod);
	$thumb_cod = $thumb_cod +3;
	$thumbnail = "http://video.globo.com/GMC/foto/0,,".$thumb_cod.",00.jpg";
	$vidtime = $grab_vidtime[$conta]->plaintext;
	$vidtime = fixVidTime($vidtime);
	$description = $grab_desc[$conta]->plaintext;
	$vidurl_original = $element->href;
	$curlresult = connectSource($vidurl_original, $userAgent, $usefollow, $proxies, $proxysources, $feedhost);
	$html_subpage= str_get_html($curlresult);
	$grab_embedcod = $html_subpage->find('input[class=texto texto-embed]', 0);
	$embedcod = $grab_embedcod->value;
	$vidcod = strstr($embedcod, "midiaId=");
	$subvidcod = strstr($vidcod, "&amp;");
	$vidcod = str_replace($subvidcod, "", $vidcod);
	$vidcod = str_replace("midiaId=", "", $vidcod);
	if (!$vidcod) {$conta++; continue;}
	preg_match_all("/href=\"\/Videos\/Busca\/(.*)\?t=(.*)\" title=\"(.*)\">(.*)<\/a>/Ui", $html_subpage, $globotags);
	$keywords = implode(", ", $globotags[2]);
	$keywords = fixEncoding($keywords);
	if ($checktitle == "yes") {if (search_blocked_tags(strtolower($title), $blocktags)) {$conta++; continue;}}
	if ($checkdesc == "yes"){if (search_blocked_tags(strtolower($description), $blocktags)) {$conta++; continue;}}
	if ($checktags == "yes"){if (search_blocked_tags(strtolower($keywords), $blocktags)) {$conta++; continue;}}
	$postcontent = player_globo($vidcod,$pwsize,$phsize);
	$globo++;
	$mvbstats['Globo'] = $globo;
	$description = trim(substr((str_replace("\n", ' ', str_replace("\r", ' ', strip_tags(StupefyEntities($description))))),0,$descsize))."";
	savepost($category, $postname, $keywords, $thumbnail, $description, $postcontent, $poststatus, $title, $commentstatus, $pingstatus, $feedhost, $vidcod, $postauthor, $futuretime, $vidurl_original, $grab_comments, $max_comments, $aprove_comments, $vidtime);
	$pornmax++; $conta++; $ptotaladded++; $grabbed++; $grabbed_cp++; $futuretime = $futuretime + $scheduletime;
	$html_subpage->clear(); 
	unset($html_subpage);
	if ($showoutput == "yes") {
	echo "<p align=\"left\"><i><font color=\"green\">Video added:</font> $title <font color=\"green\">($poststatus)</font></i><br></p>";
	flush_buffers();
	}
	$grab_more = $maxvideos-$grabbed;
	if ($grab_more == "0") {break;}
	}
}
	if (($grabbed_cp == "0") AND ($showoutput == "yes")) {echo "<p align=\"left\"><i>There is no new videos in this page.</i><br></p>"; flush_buffers();}
	$page_number++;
	$html->clear(); 
	unset($html);
	if (!$grab_next_page) {break;}
	else if($vids_now == $vids_total) {
	if($showoutput == "yes") {echo "<p align=\"left\"><i>No more pages to follow.</i><br></p>"; flush_buffers();}
	break;
	}
} while (($grab_more > "0") OR ($grabbed == "0"));
break;
// Get Videos from ExtremeTube.com ------------------------------
case 'extremetube.com':
	$page_number = 1;
	do {
	if ($page_number > $maxpages+1) {break;}
	if ($page_number > "1") {
	if ($grab_next_page) {$url = $grab_next_page;}
	$show_total_source++;
	if ($showoutput == "yes") {
	echo "<p align=\"left\"><i><b>[".$show_total_source."] Connecting ".$showfeedhost." page ".$page_number."...</b></i> [<a href=\"".$url."\" target=\"_blank\" title=\"Go to ".$url."\">Check Link</a>]<br></p>";
	flush_buffers();
	}
	}
	$curlresult = connectSource($url, $userAgent, $usefollow, $proxies, $proxysources, $feedhost);
	if (!$curlresult) {$feednotfound++; $notfoundstats[] = $url; break;}
	$html= str_get_html($curlresult);
	$grab_urls = $html->find('a[onmouseover^=startThumbChange]');
	$grab_thumbs = $html->find('img[class=thumb-list-img]');
	$grab_vidtime = $html->find('div[class=time-video absolute]');
	$get_total = preg_match("/<p>Showing (.*) to (.*) of (.*) videos.<\/p>/Ui", $html, $matches);
	$vids_now = $matches[2];
	$vids_total = $matches[3];
	$grab_next = $html->find('a[href*=&page]');
	$grab_next = array_reverse($grab_next);
	$fixnext = $grab_next[0]->href;
	$fixnext2 = $page_number+1;
	if ($grab_next) {$url2 = strstr($fixnext, "&page="); $url = str_replace($url2, "", $fixnext); $grab_next_page = "".$url."&page=".$fixnext2."";} else {unset($grab_next_page);}

	$futuretime = 5; $pornmax = 1; $conta = 0; $grabbed_cp = 0;
foreach ($grab_thumbs as $element) {
	if($pornmax > $maxvideos) {break;} else {
	$title = fixEncoding($element->alt);
	$checklink = sanitize_title($title);
	$cl2 = $wpdb->get_var("SELECT post_name FROM $wpdb->posts WHERE post_name = '$checklink'");
	if ($cl2) {$conta++; continue;}
	$thumbnail = $element->src;
	$vidurl_original = $grab_urls[$conta]->href;
	if ((strpos($vidurl_original, "pornhub")) OR (strpos($vidurl_original, "tube8")) OR (strpos($vidurl_original, "keezmovies"))) {$conta++; continue;}
	$vidtime = $grab_vidtime[$conta]->plaintext;
	$description = "";
	$curlresult = connectSource($vidurl_original, $userAgent, $usefollow, $proxies, $proxysources, $feedhost);
	$sub_page= str_get_html($curlresult);
	$vidcod = $sub_page->find('param[name=FlashVars]', 0)->value;
	$vidcod = str_replace("options=http://www.extremetube.com/embed_player.php?id=", "", $vidcod);
	$keywords = $sub_page->find('div[class=tag-content-box]', 0)->plaintext;
	$keywords = fixEncoding($keywords);
	if ($checktitle == "yes") {if (search_blocked_tags(strtolower($title), $blocktags)) {$conta++; continue;}}
	if ($checkdesc == "yes"){if (search_blocked_tags(strtolower($description), $blocktags)) {$conta++; continue;}}
	if ($checktags == "yes"){if (search_blocked_tags(strtolower($keywords), $blocktags)) {$conta++; continue;}}
	$postcontent = player_extremetube($vidcod,$pwsize,$phsize);
	$pornhub++;
	$mvbstats['PornHub'] = $pornhub;
	savepost($category, $postname, $keywords, $thumbnail, $description, $postcontent, $poststatus, $title, $commentstatus, $pingstatus, $feedhost, $vidcod, $postauthor, $futuretime, $vidurl_original, $grab_comments, $max_comments, $aprove_comments, $vidtime);
	$pornmax++; $conta++; $ptotaladded++; $grabbed++; $grabbed_cp++; $futuretime = $futuretime + $scheduletime;
	$sub_page->clear(); 
	unset($sub_page);
	if ($showoutput == "yes") {
	echo "<p align=\"left\"><i><font color=\"green\">Video added:</font> $title <font color=\"green\">($poststatus)</font></i><br></p>";
	flush_buffers();
	}
	$grab_more = $maxvideos-$grabbed;
	if ($grab_more == "0") {break;}
	}
}
	if (($grabbed_cp == "0") AND ($showoutput == "yes")) {echo "<p align=\"left\"><i>There is no new videos in this page.</i><br></p>"; flush_buffers();}
	$page_number++;
	$html->clear(); 
	unset($html);
	if (!$grab_next_page) {break;}
} while (($grab_more > "0") OR ($grabbed == "0"));
break;
// Get Videos from EPorner.com ------------------------------
case 'eporner.com':
	$page_number = 0;
	do {
	if ($page_number > $maxpages*200) {break;}
	if ($page_number > "0") {
	if ($grab_next_page) {$url = $grab_next_page;}
	$page_number2 = $page_number / 200 +1;
	$show_total_source++;
	if ($showoutput == "yes") {
	echo "<p align=\"left\"><i><b>[".$show_total_source."] Connecting ".$showfeedhost." Feed ".$page_number2."...</b></i> [<a href=\"".$url."\" target=\"_blank\" title=\"Go to ".$url."\">Check Link</a>]<br></p>";
	flush_buffers();
	}
	}
	$curl_feed = connectSource($url, $userAgent, $usefollow, $proxies, $proxysources, $feedhost);
	if (!$curl_feed) {$feednotfound++;$notfoundstats[] = $url;break;}
	$html= str_get_html($curl_feed);
	$grab_id = $html->find('id');
	$grab_title = $html->find('title');
	$grab_keywords = $html->find('keywords');
	$grab_vidlink = $html->find('loc');
	$grab_thumb = $html->find('imgthumb');
	$grab_vidtime = $html->find('lenghtmin');
	$grab_next = $page_number+200;
	if ($grab_next) {$url2 = strstr($url, "/200/"); $url = str_replace($url2, "", $url); $grab_next_page = "".$url."/200/".$grab_next."/adddate";} else {unset($grab_next_page);}
	$futuretime = 5; $pornmax = 1; $conta = 0; $grabbed_cp = 0;
	foreach ($grab_id as $element) {
	if($pornmax > $maxvideos) {
	break;
	} else {
	$vidcod = $element->plaintext;
	$title = $grab_title[$conta]->plaintext;
	$title = fixEncoding($title);
	$checklink =  sanitize_title($title);
	if (!$checklink) {$conta++; continue;}
	$cl = $wpdb->get_var("SELECT post_name FROM $wpdb->posts WHERE post_name = '$checklink'");
	if ($cl) {$conta++; continue;}
	$keywords = $grab_keywords[$conta]->plaintext;
	$keywords = fixkeywords($keywords);
	$keywords = fixEncoding($keywords);
	$vidurl_original = $grab_vidlink[$conta]->plaintext;
	$thumbnail = $grab_thumb[$conta]->plaintext;
	$vidtime = $grab_vidtime[$conta]->plaintext;
	$description = "";
	if ($checktitle == "yes") {if (search_blocked_tags(strtolower($title), $blocktags)) {$conta++; continue;}}
	if ($checktags == "yes"){if (search_blocked_tags(strtolower($keywords), $blocktags)) {$conta++; continue;}}
	$postcontent = player_eporner($vidcod,$pwsize,$phsize);
	$eporner++;
	$mvbstats['Eporner'] = $eporner;
	savepost($category, $postname, $keywords, $thumbnail, $description, $postcontent, $poststatus, $title, $commentstatus, $pingstatus, $feedhost, $vidcod, $postauthor, $futuretime, $vidurl_original, $grab_comments, $max_comments, $aprove_comments, $vidtime);
	$pornmax++; $conta++; $ptotaladded++; $grabbed++; $grabbed_cp++; $futuretime = $futuretime + $scheduletime;
	if ($showoutput == "yes") {
	echo "<p align=\"left\"><i><font color=\"green\">Video added:</font> $title <font color=\"green\">($poststatus)</font></i><br></p>";
	flush_buffers();
	}
	$grab_more = $maxvideos-$grabbed;
	if ($grab_more == "0") {break;}
	}
	}
	if (($grabbed_cp == "0") AND ($showoutput == "yes")) {echo "<p align=\"left\"><i>There is no new videos in this page.</i><br></p>"; flush_buffers();}
	$page_number = $page_number + 200;
	if (!$grab_next_page) {break;}
	} while (($grab_more > "0") OR ($grabbed == "0"));
break;
// Get Videos from Gdata.YouTube.com ------------------------------
case 'gdata.youtube.com':
	$page_number = 0;
	do {
	if ($page_number > $maxpages*50) {break;}
	if ($page_number > "0") {
	if ($grab_next_page) {$url = $grab_next_page;}
	$page_number2 = $page_number + 50;
	$show_total_source++;
	if ($showoutput == "yes") {
	echo "<p align=\"left\"><i><b>[".$show_total_source."] Connecting ".$showfeedhost." Feed ".$page_number."-".$page_number2."...</b></i> [<a href=\"".$url."\" target=\"_blank\" title=\"Go to ".$url."\">Check Link</a>]<br></p>";
	flush_buffers();
	}
	}
	$curl_feed = connectSource($url, $userAgent, $usefollow, $proxies, $proxysources, $feedhost);
	if (!$curl_feed) {$feednotfound++;$notfoundstats[] = $url;break;} else {$feed = simplexml_load_string($curl_feed);}
	$grab_next = $page_number+50;
	if ($grab_next) {$url2 = strstr($url, "&start-index="); $url = str_replace($url2, "", $url); $grab_next_page = "".$url."&start-index=".$grab_next."";} else {unset($grab_next_page);}
	$futuretime = 5; $pornmax = 1; $conta = 0; $grabbed_cp = 0;
	foreach ($feed->entry as $item) {
	if($pornmax > $maxvideos) {
	break;
	} else {
	$media = $item->children('http://search.yahoo.com/mrss/');
	if(isset($item->title)) {$title = $item->title;}
	else if(isset($media->title)) {$title = $media->title;}
	else {continue;}
	$title = fixEncoding($title);
	$checklink =  sanitize_title($title);
	if (!$checklink) {continue;}
	$cl = $wpdb->get_var("SELECT post_name FROM $wpdb->posts WHERE post_name = '$checklink'");
	if ($cl) {continue;}	
	if ($checktitle == "yes") {if (search_blocked_tags(strtolower($title), $blocktags)) {continue;}}
	if (!$media->group->content) {continue;}
	$vidoriginal = $media->group->player->attributes();
	$fixvidurl = array("&feature=youtube_gdata", "_player");
	$vidurl_original = str_replace($fixvidurl, "", $vidoriginal['url']);
	$vidinfo = $media->group->content->attributes();
	preg_match("#http://(?:www\.)?youtube\.com/v\/([_\-a-z0-9]+)#i", $vidinfo, $matches);
	$vidcod = $matches[1];
	if ((!$vidcod) OR ($vidcod == "")) {continue;}
	$vidtype = $vidinfo['type'];
	$vidtime = $vidinfo['duration'];
	$vidtime = fixVidTimeSeconds($vidtime);
	$attrs = $media->group->thumbnail->attributes();
	$thumbnail = $attrs['url'];
	$thumbnail = str_replace("default.jpg", "0.jpg", $thumbnail);
	$keywords = $media->group->keywords;
	$description = $media->group->description;
	if ($checkdesc == "yes"){if (search_blocked_tags(strtolower($description), $blocktags)) {continue;}}
	if ($checktags == "yes"){if (search_blocked_tags(strtolower($keywords), $blocktags)) {continue;}}
	$description = trim(substr((str_replace("\n", ' ', str_replace("\r", ' ', strip_tags(StupefyEntities($description))))),0,$descsize))."";
	if ($jwplayer == "yes") {$siteurl = get_option('siteurl'); $postcontent = player_youtube_jwp($vidcod,$pwsize,$phsize,$siteurl);} else {$postcontent = player_youtube($vidcod,$pwsize,$phsize);}
	$youtube++;
	$mvbstats['Youtube'] = $youtube;
	$keywords = fixkeywords($keywords);
	$keywords = fixEncoding($keywords);
	$fixthumb = strstr($thumbnail, "?");
	$thumbnail = str_replace($fixthumb, "", $thumbnail);
	if($removeurls == "yes") {$description = preg_replace("/(http:\/\/|(www\.))(([^\s<]{4,68})[^\s<]*)/", '', $description);}
	$description = fixEncoding($description);
	savepost($category, $postname, $keywords, $thumbnail, $description, $postcontent, $poststatus, $title, $commentstatus, $pingstatus, $feedhost, $vidcod, $postauthor, $futuretime, $vidurl_original, $grab_comments, $max_comments, $aprove_comments, $vidtime);
	$pornmax++; $conta++; $ptotaladded++; $grabbed++; $grabbed_cp++; $futuretime = $futuretime + $scheduletime;
	if ($showoutput == "yes") {
	echo "<p align=\"left\"><i><font color=\"green\">Video added:</font> $title <font color=\"green\">($poststatus)</font></i><br></p>";
	flush_buffers();
	}
	$grab_more = $maxvideos-$grabbed;
	if ($grab_more == "0") {break;}
	}
	}
	if (($grabbed_cp == "0") AND ($showoutput == "yes")) {echo "<p align=\"left\"><i>There is no new videos in this page.</i><br></p>"; flush_buffers();}
	$page_number = $page_number + 50;
	if (!$grab_next_page) {break;}
	} while (($grab_more > "0") OR ($grabbed == "0"));
break;
// Get Videos from sxml sources ------------------------------
default:
	$curl_feed = connectSource($url, $userAgent, $usefollow, $proxies, $proxysources, $feedhost);
	if (!$curl_feed) {
	$feednotfound++;
	$notfoundstats[] = $url;
	continue;
	} else {
	$feed = simplexml_load_string($curl_feed);
	}

if ($feedhost == "gdata.youtube.com") {$theforeach = $feed->entry;} else {$theforeach = $feed->channel->item;}

	$futuretime = 5; $grabbed_cp = 0;
foreach ($theforeach as $item) {
	if($max > $maxvideos) {
	break;
	} else {

	$media = $item->children('http://search.yahoo.com/mrss/');
	$media_dm = $item->children('http://search.yahoo.com/mrss');
	$extra = $item->children('http://www.itunes.com/dtds/podcast-1.0.dtd');
	$metakewego = $item->children('http://www.kewego.com');
	if(isset($item->title)) {$title = $item->title;}
	else if(isset($media->title)) {$title = $media->title;}
	else if(isset($media_dm->title)) {$title = $media_dm->title;}
	else if(isset($media->group->title)) {$title = $media->group->title;}
	else if(isset($media->content->title)) {$title = $media->content->title;}
	else {continue;}
	$title = fixEncoding($title);
	$checklink =  sanitize_title($title);
	if (!$checklink) {continue;}
	$cl = $wpdb->get_var("SELECT post_name FROM $wpdb->posts WHERE post_name = '$checklink'");
	if ($cl) {continue;}
	
	if ($checktitle == "yes") {
	$skipvideo_bytitle = search_blocked_tags(strtolower($title), $blocktags);
		if ($skipvideo_bytitle == "1") {continue;}
	}
	
// Get Videos from Metacafe.com ------------------------------
if ($feedhost == "metacafe.com") {
	$vidurl_original = $item->link;
	$vidurl_original = strstr($vidurl_original, "http://");
	preg_match("#http://(?:www\.)?metacafe\.com\/watch\/([_\-a-z0-9]+)\/#i", $vidurl_original, $matches);
	$vidcod = $matches[1];
	if ((!$vidcod) OR ($vidcod == "")) {continue;}
	$attrs = $media->thumbnail->attributes();
	$thumbnail = $attrs['url'];
	$keywords = $media->keywords;
	$description = $media->description;
	preg_match("/<\/a>(.*):(.*)<br\/>/Ui", $item->description, $matches);
	$vidtime = $matches[0];
	$fixvidtime = array("(", ")", "</a>", "<br/>", " ");
	$vidtime = str_replace($fixvidtime, "", $vidtime);
	if ($checkdesc == "yes"){if (search_blocked_tags(strtolower($description), $blocktags)) {continue;}}
	if ($checktags == "yes"){if (search_blocked_tags(strtolower($keywords), $blocktags)) {continue;}}
	$description = trim(substr((str_replace("\n", ' ', str_replace("\r", ' ', strip_tags(StupefyEntities($description))))),0,$descsize))."";
	$postcontent = player_metacafe($vidcod,$pwsize,$phsize);
	$metacafe++;
	$mvbstats['Metacafe'] = $metacafe;
 
} // Get Videos from Break.com ------------------------------
else if ($feedhost == "rss.break.com") {
	$vidurl_original = $item->link;
	$vidurl_original = strstr($vidurl_original, "http://");
	$fulldescription = $item->description;
	$description = $item->description;
	$description = trim(substr((str_replace("\n", ' ', str_replace("\r", ' ', strip_tags(StupefyEntities($description))))),0,$descsize))."";
	$removetags = strstr($description, "Tags:");
	if ($removetags) {$description = str_replace($removetags, "", $description);}
	if (!$vidurl_original) {continue;} 
	$curlresult = connectSource($vidurl_original, $userAgent, $usefollow, $proxies, $proxysources, $feedhost);
	$html= str_get_html($curlresult);
	$getcod = $html->find('meta[name=embed_video_url]', 0)->content;
	$vidcod = str_replace("http://embed.break.com/", "", $getcod);
	$thumbnail = $html->find('meta[name=embed_video_thumb_url]', 0)->content;
	$vidtime = "00:00";
	if (!$vidcod) {continue;}
	preg_match_all("/<a href=\"http:\/\/www.break.com\/surfacevideo\/(.*)\/\">(.*)<\/a>/Ui", $fulldescription, $gettags);
	$keywords = implode(" ", $gettags[2]);
	$keywords = fixkeywords($keywords);
	if ($checkdesc == "yes"){if (search_blocked_tags(strtolower($description), $blocktags)) {continue;}}
	if ($checktags == "yes"){if (search_blocked_tags(strtolower($keywords), $blocktags)) {continue;}}
	$postcontent = player_break($vidcod,$pwsize,$phsize);
	$break++;
	$mvbstats['Break'] = $break;
	
} // Get Videos from SevenLoad.com ------------------------------
else if (($feedhost == "en.sevenload.com") OR ($feedhost == "rss.sevenload.com")) {
	$url = str_replace("http://en.sevenload.com/rss/taggedvideos/", "http://rss.sevenload.com/taggedvideos/", $url);
	$url = "".$url."?portalId=en";
	$attrs = $media->thumbnail->attributes();
	$thumbnail = $attrs['url'];
	$vidurl_original = $item->link;
	$vidurl_original = strstr($vidurl_original, "http://");
	$vidcod = str_replace("http://en.sevenload.com/videos/", "", $vidurl_original);
	$vidcod2 = strstr($vidcod, "-");
	$vidcod = str_replace("$vidcod2", "", $vidcod);
	if (!$vidcod) {continue;} 
	$keywords = $media->keywords;
	$description = $media->description;
	$vidtime = $media->content->attributes();
	$vidtime = $vidtime['duration'];
	$vidtime = fixVidTimeSeconds($vidtime);
	if ($checkdesc == "yes"){if (search_blocked_tags(strtolower($description), $blocktags)) {continue;}}
	if ($checktags == "yes"){if (search_blocked_tags(strtolower($keywords), $blocktags)) {continue;}}
	$description = trim(substr((str_replace("\n", ' ', str_replace("\r", ' ', strip_tags(StupefyEntities($description))))),0,$descsize))."";
	$postcontent = player_sevenload($vidcod,$pwsize,$phsize);
	$sevenload++;
	$mvbstats['Sevenload'] = $sevenload; 

} // Get Videos from Viddler.com ------------------------------
else if ($feedhost == "viddler.com") {
	$attrs = $media->content->attributes();
	$vidurl_original = $attrs['url'];
	$vidurl_original = strstr($vidurl_original, "http://");
	$attrs = $media->content->thumbnail->attributes();
	$thumbnail = $attrs['url'];
	$keywords = $media->content->category;
	$removeprefixs = array("http://cdn-thumbs.viddler.com/thumbnail_1_", "_v1.jpg", ".jpg");
	$vidcod = str_replace($removeprefixs, "", $thumbnail);
	if (!$vidcod) {continue;} 
	$curlresult = connectSource($vidurl_original, $userAgent, $usefollow, $proxies, $proxysources, $feedhost);
	$html= str_get_html($curlresult);
	$description = $html->find('div[id=smDesShown]', 0)->plaintext;
	$vidtime = "00:00";
	if ($checkdesc == "yes"){if (search_blocked_tags(strtolower($description), $blocktags)) {continue;}}
	if ($checktags == "yes"){if (search_blocked_tags(strtolower($keywords), $blocktags)) {continue;}}
	$description = trim(substr((str_replace("\n", ' ', str_replace("\r", ' ', strip_tags(StupefyEntities($description))))),0,$descsize))."";
	$postcontent = player_viddler($vidcod,$pwsize,$phsize);
	$viddler++;
	$mvbstats['Viddler'] = $viddler; 

} // Get Videos from Hulu.com ------------------------------
else if ($feedhost == "hulu.com") {
	$vidurl = $item->link;
	$urlfix2 = strstr($vidurl, "#http");
	$vidurl_original = str_replace($urlfix2, "", $vidurl);
	$attrs = $media->thumbnail->attributes();
	$thumbnail = $attrs['url'];
	$descfull = $item->description;
	$descfix1 = trim(substr((str_replace("\n", ' ', str_replace("\r", ' ', strip_tags(StupefyEntities($descfull))))),0,$descsize))."";
	$descfix2 = strstr($descfix1, "Add this to your queueAdded");
	$description = str_replace($descfix2, "", $descfix1);
	preg_match("/Duration: (.*)Rating/Ui", $descfix1, $matches);
	$vidtime = $matches[1];
	$curlresult = connectSource($vidurl_original, $userAgent, $usefollow, $proxies, $proxysources, $feedhost);
	$html= str_get_html($curlresult);
	$vidcod = $html->find('link[rel=media:video]', 0)->href;
	$vidcod = str_replace("http://www.hulu.com/embed/", "", $vidcod);
	if (!$vidcod) {continue;}
	$getkeywords = $html->find('a[href^=/search/search_tag]');
	$keywords = strtolower(strip_tags(implode(",", $getkeywords)));
	$keywords = str_replace(" ...", "", $keywords);
	$keywords = str_replace("...", "", $keywords);
	if ($checkdesc == "yes"){if (search_blocked_tags(strtolower($description), $blocktags)) {continue;}}
	if ($checktags == "yes"){if (search_blocked_tags(strtolower($keywords), $blocktags)) {continue;}}
	$description = trim(substr((str_replace("\n", ' ', str_replace("\r", ' ', strip_tags(StupefyEntities($description))))),0,$descsize))."";
	$postcontent = player_hulu($vidcod,$pwsize,$phsize);
	$hulu++;
	$mvbstats['Hulu'] = $hulu; 

} // Get Videos from Dailymotion.com ------------------------------
else if ($feedhost == "dailymotion.com") {
	$vidurl_original = $item->link;
	$vidurl_original = strstr($vidurl_original, "http://");
	$attrs = $media_dm->thumbnail->attributes();
	$thumbnail = $attrs['url'];
	$author = $media_dm->credit;
	if ($author == "hulu") {continue;}
	$dmgroup = $media_dm->group;
	if (!$dmgroup) {continue;}
	$attrs = $media_dm->group->content->attributes();
	$getcod = $attrs['url'];
	if (preg_match("#http://(?:www\.)?dailymotion\.com/embed\/video\/([_\-a-z0-9]+)#i", $getcod, $matches)){
	$vidcod = $matches[1];
	} else {
	preg_match("#http://(?:www\.)?dailymotion\.com/swf\/video\/([_\-a-z0-9]+)#i", $getcod, $matches);
	$vidcod = $matches[1];
	}
	$vidtime = $attrs['duration'];
	$vidtime = fixVidTimeSeconds($vidtime);
	if (!$vidcod) {continue;} 
	$keywords = $extra->keywords;
	$description = $extra->summary;
	if ($checkdesc == "yes"){if (search_blocked_tags(strtolower($description), $blocktags)) {continue;}}
	if ($checktags == "yes"){if (search_blocked_tags(strtolower($keywords), $blocktags)) {continue;}}
	$description = trim(substr((str_replace("\n", ' ', str_replace("\r", ' ', strip_tags(StupefyEntities($description))))),0,$descsize))."";
	$postcontent = player_dailymotion($vidcod,$pwsize,$phsize);
	$dailymotion++;
	$mvbstats['Dailymotion'] = $dailymotion; 

} // Get Videos from Kewego.com ------------------------------
else if ($feedhost == "kewego.com") {
	$vidurl_original = $item->link;
	$vidurl_original = strstr($vidurl_original, "http://");
	$attrs = $media->thumbnail->attributes();
	$thumbnail = $attrs['url'];
	$vidcod = str_replace("http://www.kewego.com/video/", "", $vidurl_original);
	$vidcod = str_replace(".html", "", $vidcod);
	if (!$vidcod) {continue;} 
	$keywords = $media->category;
	$description = $metakewego->description;
	if ($checkdesc == "yes"){if (search_blocked_tags(strtolower($description), $blocktags)) {continue;}}
	if ($checktags == "yes"){if (search_blocked_tags(strtolower($keywords), $blocktags)) {continue;}}
	$description = trim(substr((str_replace("\n", ' ', str_replace("\r", ' ', strip_tags(StupefyEntities($description))))),0,$descsize))."";
	$postcontent = player_kewego($vidcod,$pwsize,$phsize);
	$kewego++;
	$mvbstats['Kewego'] = $kewego; 

} // Get Videos from Yahoo.com ------------------------------
else if ($feedhost == "video.yahoo.com") {
	$vidurl_original = $item->link;
	$vidurl_original = strstr($vidurl_original, "http://");
	$attrs = $media_dm->thumbnail->attributes();
	$thumbnail = $attrs['url'];
	$afterthumb = strstr($thumbnail, ".jpeg");
	$thumbnail = str_replace($afterthumb, ".jpeg", $thumbnail);
	$attrs = $media_dm->content->player->attributes();
	$fullvidcod = $attrs['url'];
	$aftervidcod = strstr($fullvidcod, "id=");
	$afterlang= strstr($aftervidcod, "&lang=");
	$vidcod = str_replace($afterlang, "", $aftervidcod);
	$vidcod = "".$vidcod."&lang=en-us&intl=us&thumbUrl=".$thumbnail."&embed=1";
	if (!$vidcod) {continue;} 
	$keywords = $media_dm->keywords;
	$description = $media_dm->description;
	$vidtime = "0:00";
	if ($checkdesc == "yes"){if (search_blocked_tags(strtolower($description), $blocktags)) {continue;}}
	if ($checktags == "yes"){if (search_blocked_tags(strtolower($keywords), $blocktags)) {continue;}}
	$description = trim(substr((str_replace("\n", ' ', str_replace("\r", ' ', strip_tags(StupefyEntities($description))))),0,$descsize))."";
	$postcontent = player_yahoo($vidcod,$pwsize,$phsize);
	$yahoo++;
	$mvbstats['Yahoo'] = $yahoo; 

	
} // END via feeds ------------------------------
	// Saving Data ------------------------------

	$keywords = fixkeywords($keywords);
	$keywords = fixEncoding($keywords);
	$fixthumb = strstr($thumbnail, "?");
	$thumbnail = str_replace($fixthumb, "", $thumbnail);
	$videoimage = $thumbnail;

	if($removeurls == "yes") {$description = preg_replace("/(http:\/\/|(www\.))(([^\s<]{4,68})[^\s<]*)/", '', $description);}
	
	savepost($category, $postname, $keywords, $videoimage, $description, $postcontent, $poststatus, $title, $commentstatus, $pingstatus, $feedhost, $vidcod, $postauthor, $futuretime, $vidurl_original, $grab_comments, $max_comments, $aprove_comments, $vidtime);
	$grabbed_cp++;
	if ($showoutput == "yes") {
	echo "<p align=\"left\"><i><font color=\"green\">Video added:</font> ".stripslashes($title)." <font color=\"green\">(".$poststatus.")</font></i><br></p>";
	flush_buffers();
	}
	}
	$ptotaladded++;
	$max++;
	$futuretime = $futuretime + $scheduletime;

} // END Item feeds ------------------------------
if (($grabbed_cp == "0") AND ($showoutput == "yes")) {echo "<p align=\"left\"><i>There is no new videos in this page.</i><br></p>"; flush_buffers();}
break;
} // END Feed Sources ------------------------------

	$ftotaladded++;
} // END Looping Sources ------------------------------
	if ($showoutput == "yes") {
	echo "<p align=\"left\"><i><b>Done!</b></i></p>";
	flush_buffers();
	}
// Show Results ------------------------------
if(($type == "manual") OR ($type == "processfeed")) {

if ($feednotfound != "0") {
?>
<center><table class="widefat" width="70%" cellspacing="0">
<thead>
<tr>
<th scope="col"><b>MVB can not reach <?php echo "$feednotfound";?> source(s):</b></th>
</tr>
</thead>
<?php
foreach ($notfoundstats as $feedsoff) {
echo "<tr><td bgcolor=\"#DDDDDD\"><a href=\"".$feedsoff."\" target=\"_blank\">".$feedsoff."</a></td></tr>";
}
?>
</table></center><br><br>
<?php
}
if ($ptotaladded  > "0") {
?>
<center><table class="widefat" width="70%" cellspacing="0">
<thead>
<tr>
<th scope="col"><b>Sources:</b></th>
<th scope="col"><b><?php echo "$ptotaladded";?> videos added:</b></th>
</tr>
</thead>
<?php
foreach ($mvbstats as $provider => $grabs) {
echo "<tr><td bgcolor=\"#DDDDDD\">".$provider."</td><td bgcolor=\"#DDDDDD\">".$grabs."</td></tr>";
}
?>
</table></center><br><br>
<?php
} else {
echo "No videos added.<br>Maybe you already have all the videos from this source. Wait for the source to be updated.";
}
} else if($type == "internal") {
$notifymail = get_option("mvbcron_mail");
$frommail = get_option("admin_email");
if ($notifymail) {
if ($feednotfound != "0") {
$notreachmsg = "\n\nMVB was unable to connect to ".$feednotfound." video sources. Please contact MVB Support.";
}
$siteupdated = get_bloginfo('siteurl');
$siteupdatedtitle = strtolower(str_replace("http://", '', get_bloginfo('siteurl')));
$siteupdatedtitle = str_replace("www.", '', $siteupdatedtitle);
$header = "From: MVB Plugin <" . $frommail . ">\r\n";
$mailmsg = "Hello!\n\nYour site has been updated with new videos!\n\nTotal videos: ".$ptotaladded."\nTotal sources: ".$ftotaladded."\nSite updated: ".$siteupdated."".$notreachmsg."\n\nHave a nice day!\nPHPMyVideoblog.com";
mail($notifymail, '[MVB Pro] Site Updated: '.$siteupdatedtitle.'', $mailmsg, $header);
}
} else {
$siteupdated = get_bloginfo('siteurl');
$siteupdatedtitle = strtolower(str_replace("http://", '', get_bloginfo('siteurl')));
$siteupdatedtitle = str_replace("www.", '', $siteupdatedtitle);
if ($feednotfound != "0") {
$notreachmsg = "<br>MVB was unable to connect to ".$feednotfound." video sources. Please contact MVB Support.<br>";
}
echo "Your site has been updated with new videos!<br>Total videos: ".$ptotaladded."<br>Total sources: ".$ftotaladded."<br>Site updated: ".$siteupdated."".$notreachmsg."<br><br>Have a nice day!<br>PHPMyVideoblog.com";
}
?>