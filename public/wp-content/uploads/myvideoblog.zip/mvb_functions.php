<?php
require(ABSPATH . 'wp-content/plugins/myvideoblog/mvb_players.php');

function flush_buffers(){ 
    ob_start();
    ob_flush(); 
    flush(); 
    ob_end_flush(); 
}

function workingProxy($proxies){
 $url = 'http://www.google.com';
 $return = 'groups';
 $userAgent = "Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.2.6) Gecko/20100625 Firefox/3.6.6";
 $count = count($proxies);
 $curl_arr = array();
 $master = curl_multi_init();
 for($i = 0; $i < $count; $i++) {
 $proxy = $proxies[$i];
 $curl_arr[$i] = curl_init();
 curl_setopt($curl_arr[$i], CURLOPT_URL, $url);
 curl_setopt($curl_arr[$i], CURLOPT_RETURNTRANSFER, true);
 curl_setopt($curl_arr[$i], CURLOPT_HEADER, false);
 curl_setopt($curl_arr[$i], CURLOPT_CONNECTTIMEOUT, 10);
 curl_setopt($curl_arr[$i], CURLOPT_TIMEOUT, 10);
 curl_setopt($curl_arr[$i], CURLOPT_FOLLOWLOCATION, true);
 curl_setopt($curl_arr[$i], CURLOPT_USERAGENT, $userAgent);
 $cproxy = explode('|', $proxy);
 curl_setopt($curl_arr[$i], CURLOPT_PROXY, $cproxy[0]);
 if($cproxy[2] == "socks4") {curl_setopt($curl_arr[$i], CURLOPT_PROXYTYPE, CURLPROXY_SOCKS4);}
 else if($cproxy[2] == "socks5") {curl_setopt($curl_arr[$i], CURLOPT_PROXYTYPE, CURLPROXY_SOCKS5);}
 if($cproxy[1] != ":") {
 curl_setopt($curl_arr[$i], CURLOPT_PROXYUSERPWD, $cproxy[1]);}
 curl_multi_add_handle($master, $curl_arr[$i]);
 }
 $running = null;
 do {
 curl_multi_exec($master,$running);
 } while($running > 0);
 $a = 0;
 for($i = 0; $i < $count; $i++) {
 $rawdata = curl_multi_getcontent($curl_arr[$i]);
if(curl_errno($curl_arr[$i]) || $rawdata == "" || strpos($rawdata, $return) === FALSE) {
 $badproxy = 1;
 } else {
 $goodproxy = $proxies[$i];
 break;
 }
 }
 curl_multi_close($master);
 return $goodproxy;
}

function checkProxy($proxy, $userpwd, $type) {
	$url = "http://www.google.com";
	$find = "groups";
	$userAgent = "Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.2.6) Gecko/20100625 Firefox/3.6.6";
	$usefollow = 1;
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
	if($usefollow == "1") {curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);}
	curl_setopt($ch, CURLOPT_USERAGENT, $userAgent);
	curl_setopt($ch, CURLOPT_PROXY, $proxy);
	if($type == "socks4") {curl_setopt($ch, CURLOPT_PROXYTYPE, CURLPROXY_SOCKS4);}
	else if($type == "socks5") {curl_setopt($ch, CURLOPT_PROXYTYPE, CURLPROXY_SOCKS5);}
	if($userpwd != ":") {curl_setopt($ch, CURLOPT_PROXYUSERPWD, $userpwd);}
	$html = curl_exec($ch);
    if(curl_errno($ch) || $html == "" || strpos($html, $find) === FALSE) {
	$isworking = "0";
	} else {
	$isworking = "1";
	}
	curl_close($ch);
	unset($ch);
	return $isworking;
}

function connectSource($url, $userAgent, $usefollow, $proxies, $proxysources, $feedhost) {
	$feedhost = str_replace("gdata.", '', $feedhost);
	$feedhost = str_replace("en.", '', $feedhost);
	$feedhost = str_replace("rss.", '', $feedhost);
	$referer = "http://www.".$feedhost."";
	if(($proxysources) AND ($proxies)) {
	foreach ($proxysources as $i => $value) {if($proxysources[$i] == $feedhost) {$goodproxy = workingProxy($proxies);}}
	}
	$c = curl_init();
	curl_setopt($c, CURLOPT_URL, $url);
	if($usefollow == "1") {curl_setopt($c, CURLOPT_FOLLOWLOCATION, true);}
	curl_setopt($c, CURLOPT_HEADER, false);
	curl_setopt($c, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($c, CURLOPT_USERAGENT, $userAgent);
	curl_setopt($c, CURLOPT_REFERER, $referer);
	if(isset($goodproxy)) {
	$useproxy = explode('|', $goodproxy); curl_setopt($c, CURLOPT_PROXY, $useproxy[0]);
	if($useproxy[2] == "socks4") {curl_setopt($c, CURLOPT_PROXYTYPE, CURLPROXY_SOCKS4);}
	else if($useproxy[2] == "socks5") {curl_setopt($c, CURLOPT_PROXYTYPE, CURLPROXY_SOCKS5);}
	if($useproxy[1] != ":") {curl_setopt($c, CURLOPT_PROXYUSERPWD, $useproxy[1]);}
	}
	curl_setopt($c, CURLOPT_CONNECTTIMEOUT, 20);
	$curlresult = curl_exec($c);
	$get_curl_error = curl_errno($c);
	if($get_curl_error) {
	echo 'Curl error: ' . curl_error($c);
	curl_close($c);
	return false;
	} else{
	curl_close($c);
	return $curlresult;
	}
}

function search_blocked_tags($where, $tags, $result = 0) {
		if (empty($tags)) {
		$result = 0;
		} else {
	foreach ( $tags as $key => $value ) {
		if (empty($value)) {
		$result = 0;
		} else {
		$pos = strpos($where, $value);
		if ($pos === false) { $result = 0;} else {$result = 1; break;}
		}
	}
		}
return $result;
}

function fixEncoding($in_str) 
{ 
if (function_exists('mb_detect_encoding')) {
  $cur_encoding = mb_detect_encoding($in_str) ; 
  if($cur_encoding == "UTF-8" && mb_check_encoding($in_str,"UTF-8")) {
    return $in_str; 
  } else {
    return utf8_encode($in_str);
	}
} else {
    return $in_str;
}
}

function returnImage($text) {
    //$text = html_entity_decode($text, ENT_QUOTES, 'UTF-8');
    //echo $text;
    $pattern = "/<img[^>]+\>/i";
    preg_match($pattern, $text, $matches);
    $text = $matches[0];
    return $text;
}
function scrapeImage($text) {
    
    $pattern = '/src=[\'"]?([^\'" >]+)[\'" >]/'; 
    
preg_match($pattern, $text, $link);

$link = $link[1];
//$link = urlencode($link);
return $link;
}

function shortdesc($string, $length) {
    $suffix = '...';
    $short_desc = trim(str_replace("\n", ' ', str_replace("\r", ' ', strip_tags(StupefyEntities($string)))));
    $desc = trim(substr($short_desc, 0, $length));
    $lastchar = substr($desc, -1, 1);
    if ($lastchar == '.' || $lastchar == '!' || $lastchar == '?') $suffix='';
    $desc .= $suffix;
}

// SmartyPants 1.5.1 changes rolled in May 2004 by Alex Rosenberg, http://monauraljerk.org/smartypants-php/
function StupefyEntities($s = '') {
    $inputs = array('�', '�', '�', '�', '�', '�', '�', '[', ']');
    $outputs = array('-', '--', "'", "'", '"', '"', '...', '[', ']');
    $s = str_replace($inputs, $outputs, $s);
    return $s;
}

function newsk() {
    $length = 10;
    $characters = "0123456789abcdefghijklmnopqrstuvwxyz";   

    for ($p = 0; $p < $length; $p++) {
        $string .= $characters[mt_rand(0, strlen($characters))];
    }

    return $string;
}

function fixkeywords($keywords) {
$keywords = preg_replace('/(\'|")/', '', $keywords);
$keywords = trim($keywords);
$keywords = strtolower($keywords);
//$keywords = addslashes($keywords);
$keywords = ereg_replace("[.!#?$%&@*�]","",$keywords);
$keywords = str_replace(" ", ',', $keywords);
$keywords = str_replace(",,", ',', $keywords);
return $keywords;
}

function fixpornkeywords($keywords) {
$keywords = addslashes($keywords);
$keywords = strtolower($keywords);
$keywords = str_replace(" it ", '', $keywords);
$keywords = str_replace(" and ", '', $keywords);
$keywords = str_replace(" in ", '', $keywords);
$keywords = str_replace(" at ", '', $keywords);
$keywords = str_replace(" the ", '', $keywords);
$keywords = str_replace(" a ", '', $keywords);
$keywords = str_replace(" on ", '', $keywords);
$keywords = str_replace(" gets ", '', $keywords);
$keywords = str_replace(" makes ", '', $keywords);
$keywords = str_replace(" her ", '', $keywords);
$keywords = str_replace(" him ", '', $keywords);
$keywords = str_replace(" e ", '', $keywords);
$keywords = str_replace(" with ", '', $keywords);
$keywords = str_replace(" to ", '', $keywords);
$keywords = str_replace(" i ", '', $keywords);
$keywords = str_replace(" is ", '', $keywords);
$keywords = str_replace(" are ", '', $keywords);
$keywords = str_replace(" be ", '', $keywords);
$keywords = str_replace(" this ", '', $keywords);
$keywords = str_replace(" where ", '', $keywords);
$keywords = str_replace(" you ", '', $keywords);
$keywords = str_replace(" into ", '', $keywords);
$keywords = str_replace(" would ", '', $keywords);
$keywords = str_replace(" off ", '', $keywords);
$keywords = str_replace(" of ", '', $keywords);
$keywords = str_replace(" - ", '', $keywords);
$keywords = str_replace(" _ ", '', $keywords);
$keywords = str_replace(" ", ',', $keywords);
$keywords = preg_replace('/(\'|")/', '', $keywords);
return $keywords;
}

function fixVidTime ($vidtime) {
	if ((preg_match("/(.*) min (.*) sec/Ui", $vidtime, $makevidtime)) OR (preg_match("/(.*)m(.*)s/Ui", $vidtime, $makevidtime))) {
		if ((strlen($makevidtime[1]) == "1") AND (strlen($makevidtime[2]) == "1")) {
	$vidminutes = "0".$makevidtime[1]."";
	$vidseconds = "0".$makevidtime[2]."";
	$vidtime = "".$vidminutes.":".$vidseconds."";
		} else if ((strlen($makevidtime[1]) == "1") AND (strlen($makevidtime[2]) > "1")) {
	$vidminutes = "0".$makevidtime[1]."";
	$vidtime = "".$vidminutes.":".$makevidtime[2]."";
		} else if ((strlen($makevidtime[1]) > "1") AND (strlen($makevidtime[2]) == "1")) {
	$vidseconds = "0".$makevidtime[2]."";
	$vidtime = "".$makevidtime[1].":".$vidseconds."";
		} else {
		$vidtime = "".$makevidtime[1].":".$makevidtime[2]."";
		}
	} else if (preg_match("/(.*) min/Ui", $vidtime, $makevidtime)) {
		if (strlen($makevidtime[1]) == "1") {
		$vidtime = "0".$makevidtime[1].":00";
		} else {
		$vidtime = "".$makevidtime[1].":00";
		}
	} else if (preg_match("/(.*) sec/Ui", $vidtime, $makevidtime)) {
		if (strlen($makevidtime[1]) == "1")  {
		$vidtime = "00:0".$makevidtime[1]."";
		} else {
		$vidtime = "00:".$makevidtime[1]."";
		}
	}
	return $vidtime;
}

function fixVidTimeSeconds ($vidtime) {
$min = $vidtime/60;
settype($min, "integer");
$sec = $vidtime%60;
if ($sec <= "9") {
$sec = "0".$sec."";
}
$vidtime = "".$min.":".$sec."";
return $vidtime;
}

function makethumbtitle($thumbtitle) {
$thumbtitle = stripslashes($thumbtitle);
$thumbtitle = trim($thumbtitle);
$thumbtitle = ereg_replace("[.!#?$%&@:*�]","",$thumbtitle);
$thumbtitle = str_replace("-", "", $thumbtitle);
$thumbtitle = str_replace("  ", "_", $thumbtitle);
$thumbtitle = str_replace(" ", "_", $thumbtitle);
$thumbtitle = str_replace(',', "", $thumbtitle);
$thumbtitle = preg_replace('/(\'|")/', '', $thumbtitle);
return $thumbtitle;
}

function arrayToObject($array) {
	if(!is_array($array)) {
		return $array;
	}
	$object = new stdClass();
	if (is_array($array) && count($array) > 0) {
	  foreach ($array as $name=>$value) {
	     $name = strtolower(trim($name));
	     if (!empty($name)) {
	        $object->$name = arrayToObject($value);
	     }
	  }
      return $object;
	}
    else {
      return FALSE;
    }
}

function copy_image_curl($url_source,$saveimageto) {
$my_curl = curl_init($url_source); 
$fs_file = fopen($saveimageto, "w");
curl_setopt($my_curl, CURLOPT_TIMEOUT, 50);
curl_setopt($my_curl, CURLOPT_HEADER, false); 
curl_setopt($my_curl, CURLOPT_FILE, $fs_file); 
if($usefollow == "1") {
curl_setopt($my_curl, CURLOPT_FOLLOWLOCATION, true);
}
curl_exec($my_curl); 
curl_close($my_curl); 
fclose($fs_file); 
}
function current_time_fixed( $type, $gmt = 0, $moretime ) {
	$t =  ( $gmt ) ? gmdate( 'Y-m-d H:i:s' ) : gmdate( 'Y-m-d H:i:s', ( time() + ( get_option( 'gmt_offset' ) * 3600 ) ) );
	switch ( $type ) {
		case 'mysql':
			return $t;
			break;
		case 'timestamp':
			return strtotime($t)+$moretime;
			break;
	}
}

function savepost($category, $postname, $keywords, $thumbnail, $description, $postcontent, $poststatus, $title, $commentstatus, $pingstatus, $feedhost, $vidcod, $postauthor, $scheduletime, $vidurl_original, $grab_comments, $max_comments, $aprove_comments, $vidtime) {
global $wpdb;

$mytemplate = get_option('mvb_posttemplate');
$mytemplate = stripslashes($mytemplate);
$copyimages = get_option('mvb_copyimages');
$imglib = get_option('mvb_imglib');
$customfield_thumb = get_option('mvb_customfield_thumb');
$customfield_desc = get_option('mvb_customfield_desc');
$customfield_vid = get_option('mvb_customfield_vid');
$customfield_vidsource = get_option('mvb_customfield_vidsource');
$thumbs_dir = get_option('mvb_thumbs_dir');
$theme_setting = get_option('mvb_theme_setting');
$customfield_vidembed = get_option('mvb_customfield_vidembed');
$customfield_vidtime = get_option('mvb_customfield_vidtime');

$mvb_savepost = array();
$mvb_savepost['post_title'] = $title;
$mvb_savepost['post_content'] = $description;
$mvb_savepost['post_status'] = $poststatus;
$mvb_savepost['post_author'] = $postauthor;
$mvb_savepost['comment_status'] = $commentstatus;
$mvb_savepost['ping_status'] = $pingstatus;
$mvb_savepost['post_category'] = $category;
if ($poststatus == "future") {
$changedate = current_time_fixed("timestamp", 0, $scheduletime);
$newdate = gmdate("Y-m-d H:i:s", $changedate);
$mvb_savepost['post_date'] = $newdate;
} else if (($poststatus == "draft") OR ($poststatus == "pending")) {
$newpostname = sanitize_title($title);
$mvb_savepost['post_name'] = $newpostname;
}

// feed object to wp_insert_post
$post_id = wp_insert_post($mvb_savepost);
$guid = get_permalink($post_id);

$findme = "xvideos.com";
$checkxvideos = strpos($thumbnail, $findme);
if ($checkxvideos === false) {
    $fromxvideos = "0";
} else {
    $fromxvideos = "1";
}

if (($copyimages == "yes") OR ($fromxvideos == "1")) {
	$thumbtitle = sanitize_title($title);
	$thumbtitle = ereg_replace("[.!#?$%&@*�]","",$thumbtitle);
	$thumbtitle = substr($thumbtitle, 0, 100);
	$thumbpath = ABSPATH . 'wp-content/'.$thumbs_dir.'';

	if(!file_exists($thumbpath)) { 
	mkdir($thumbpath, 0777);
	}
	$thumbname = "".$thumbpath."/img_".$post_id."_".$thumbtitle.".jpg";

	copy_image_curl($thumbnail, $thumbname);
	$siteurl = get_bloginfo('wpurl');
	if (!file_exists($thumbname)){
	$videoimage = $thumbnail;
	} else {
	$videoimage = "".$siteurl."/wp-content/".$thumbs_dir."/img_".$post_id."_".$thumbtitle.".jpg";
		if ($imglib == "yes") {
	$imglib_dir = str_replace("uploads/", '', $thumbs_dir);
	$imglocation = "".$imglib_dir."/img_".$post_id."_".$thumbtitle.".jpg";
	$imglib_title = "img_".$post_id."_".$thumbtitle."";
	$attachment = array(
	'post_title' => $imglib_title,
	'post_content' => '',
	'post_type' => 'attachment',
	'post_parent' => $post_id,
	'post_mime_type' => 'image/jpeg'
	);
	require_once(ABSPATH . "wp-admin" . '/includes/image.php');
	$attach_id = wp_insert_attachment( $attachment, $imglocation, $post_id );
	$attach_data = wp_generate_attachment_metadata( $attach_id, $imglocation );
	wp_update_attachment_metadata( $attach_id,  $attach_data );
		}
	}
} else {
	$videoimage = $thumbnail;
}

$removeprefixs = array("gdata.", "en.", "rss.", "playervideo.");
$feedhost = str_replace($removeprefixs, "", $feedhost);

$usetemplate = $mytemplate;
$usetemplate = str_replace("[videoimage]", $videoimage, $usetemplate);
$usetemplate = str_replace("[videotitle]", $title, $usetemplate);
$usetemplate = str_replace("[posturl]", $guid, $usetemplate);
$usetemplate = str_replace("[videodescription]", $description, $usetemplate);
$usetemplate = str_replace("[videourl]", $vidurl_original, $usetemplate);
$usetemplate = str_replace("[videosource]", $feedhost, $usetemplate);
$usetemplate = str_replace("[hide]", "<!--more-->", $usetemplate);
$usetemplate = str_replace("[videoplayer]", "<!--videoplayer-->".$postcontent."<!--endvideoplayer-->", $usetemplate);
$usetemplate = str_replace("[duration]", $vidtime, $usetemplate);
$usetemplate = addslashes($usetemplate);
$wpdb->query("UPDATE ".$wpdb->posts." SET post_content = '".$usetemplate."' WHERE ID = '".$post_id."'");


if (!is_array($keywords)) {
$keywords = explode(',', $keywords);
}
foreach ($keywords as $thetag) {
wp_add_post_tags($post_id, $thetag);
}

add_post_meta($post_id, $customfield_vidsource, $feedhost, true);
add_post_meta($post_id, 'mvb_vid_code', $vidcod, true);
add_post_meta($post_id, $customfield_desc, $description, true);
add_post_meta($post_id, $customfield_vid, $vidurl_original, true);
add_post_meta($post_id, $customfield_thumb, $videoimage, true);
add_post_meta($post_id, $customfield_vidtime, $vidtime, true);

if ($customfield_vidembed) {
	$new_postcontent = "<!--videoplayer-->".$postcontent."<!--endvideoplayer-->";
	add_post_meta($post_id, $customfield_vidembed, $new_postcontent, true);
}

if (($feedhost == "youtube.com") AND ($grab_comments == "yes")) {
	$total_comments=1;
	if($aprove_comments == "yes"){$comments_aproved = "1";} else {$comments_aproved = "0";}
	$comments_url = "http://gdata.youtube.com/feeds/api/videos/".$vidcod."/comments?v=2&max-results=50";
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $comments_url);
	curl_setopt($ch, CURLOPT_HEADER, 0);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	$curl_comments = curl_exec($ch);
	curl_close($ch);
	$feed_comments = simplexml_load_string($curl_comments);
	$item_comments = $feedcomments->entry;
	print_r($feedcomments->entry);
	foreach ($feed_comments->entry as $item_comments) {
	$comments_author = $item_comments->author->name;
	$comments_content = $item_comments->content;
	if(!$comments_author){continue;};
	if($total_comments > $max_comments){break;}
	if($newdate) {$comment_time= $newdate;} else {$comment_time = current_time('mysql');}
	list( $today_year, $today_month, $today_day, $hour, $minute, $second ) = split( '([^0-9])', $comment_time );	
	$comment_time = mktime($hour, $minute + rand(0, 59), $second + rand(0, 59), $today_month, $today_day, $today_year);
	$comment_time=date("Y-m-d H:i:s", $comment_time); 
$data = array(
    'comment_post_ID' => $post_id,
    'comment_author' => $comments_author,
    'comment_author_email' => 'someone@domain.com',
    'comment_author_url' => 'http://',
    'comment_content' => $comments_content,
    'comment_type' => '',
    'comment_parent' => 0,
    'user_id' => '',
    'comment_author_IP' => '127.0.0.1',
    'comment_agent' => 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.0.10) Gecko/2009042316 Firefox/3.0.10 (.NET CLR 3.5.30729)',
    'comment_date' => $comment_time,
    'comment_approved' => $comments_aproved,
);
wp_insert_comment($data);
	$total_comments++;
	}
}
	return $post_id;
}
?>