<?php
/*
Plugin Name: PHP MyVideoBlog
Plugin URI: http://www.phpmyvideoblog.com
Description: Auto add post videos to your blog. PRO Version.
Version: 3.2.3
Author: JotaBiz
Author URI: http://www.phpmyvideoblog.com
*/

register_activation_hook( __FILE__, 'mvb_install' );
global $mvb_version;
$mvb_version = "3.2.2";
$mvb_showversion = "3.2.3";

function mainnewsk() {
    $length = 10;
    $characters = "0123456789abcdefghijklmnopqrstuvwxyz";   

    for ($p = 0; $p < $length; $p++) {
        $string .= $characters[mt_rand(0, strlen($characters))];
    }

    return $string;
}

function mvb_install () {
   global $wpdb, $mvb_version;

$charset_collate = '';

if ( version_compare(mysql_get_server_info(), '4.1.0', '>=') ) {
	if ( ! empty($wpdb->charset) )
		$charset_collate = "DEFAULT CHARACTER SET $wpdb->charset";
	if ( ! empty($wpdb->collate) )
		$charset_collate .= " COLLATE $wpdb->collate";
}

   $table_name = $wpdb->prefix . "myvideoblog";
   if($wpdb->get_var("show tables like '$table_name'") != $table_name) {
      
      $sql = "CREATE TABLE " . $table_name . " (
	  fid mediumint(9) NOT NULL AUTO_INCREMENT,
	  feed varchar(200) NOT NULL,
	  category varchar(200) NOT NULL,
	  active varchar(3) NOT NULL,
	  maxvideos mediumint(9) NOT NULL,
	  poststatus varchar(10) NOT NULL,
	  sunday char(3) NOT NULL,
	  monday char(3) NOT NULL,
	  tuesday char(3) NOT NULL,
	  wednesday char(3) NOT NULL,
	  thursday char(3) NOT NULL,
	  friday char(3) NOT NULL,
	  saturday char(3) NOT NULL,
	  commentstatus varchar(10) NOT NULL,
	  pingstatus varchar(10) NOT NULL,
	  blocktags blob NOT NULL,
	  checktitle varchar(3) NOT NULL,
	  checkdesc varchar(3) NOT NULL,
	  checktags varchar(3) NOT NULL,
	  postauthor mediumint(3) NOT NULL DEFAULT  '1',
	  scheduletime int(10) NOT NULL,
	  grab_comments varchar(3) NOT NULL DEFAULT 'no',
	  max_comments int(50) NOT NULL DEFAULT '0',
	  aprove_comments varchar(3) NOT NULL DEFAULT 'yes',
	  PRIMARY KEY fid (fid)
	) $charset_collate;";

      require_once(ABSPATH . 'wp-admin/upgrade-functions.php');
      dbDelta($sql);
	}
	$sk = mainnewsk();
	add_option('mvb_postdefault', '<p><a href="[posturl]"><img src="[videoimage]" alt="[videotitle]" border="0" align="left" style="width:120px;height:80px;"></a>[videodescription]<br clear="all"></p>[hide]<p><center>[videoplayer]</center></p>');
	add_option('mvb_posttemplate', '<p><a href="[posturl]"><img src="[videoimage]" alt="[videotitle]" border="0" align="left" style="width:120px;height:80px;"></a>[videodescription]<br clear="all"></p>[hide]<p><center>[videoplayer]</center></p>');
	add_option('mvb_securitykey', $sk);
	add_option('mvb_removeurls', 'yes');
	add_option('mvb_copyimages', 'yes');
	add_option('mvb_descsize', '500');
	add_option('mvb_imglib', 'no');
	add_option('mvb_pwsize', '540');
	add_option('mvb_phsize', '420');
	add_option('mvb_myplayer', 'no');
	add_option('mvb_utf8_active', 'yes');
	add_option('mvb_customfield_thumb', 'mvb_thumb_url');
	add_option('mvb_customfield_desc', 'mvb_vid_desc');
	add_option('mvb_customfield_vid', 'mvb_vid_url');
	add_option('mvb_customfield_vidsource', 'mvb_vid_source');
	add_option('mvb_thumbs_dir', 'uploads/mvbthumbs');
	add_option('mvb_theme_setting', 'default');
	add_option('mvb_jwplayer', 'no');
	add_option('mvb_customfield_vidembed', '');
	add_option('mvb_customfield_vidtime', 'duration');
	add_option('mvb_maxpages', '0');
	add_option('mvb_installed_ver', $mvb_version);
}

function mvb_update() {
   global $wpdb, $mvb_version;
   
	$table_name = $wpdb->prefix . "mvbconfig";
	$myconfigs = $wpdb->get_row("SELECT * FROM ".$table_name." WHERE tid = '1'");
	add_option('mvb_postdefault', $myconfigs->postdefault);
	add_option('mvb_posttemplate', $myconfigs->posttemplate);
	add_option('mvb_securitykey', $myconfigs->securitykey);
	add_option('mvb_removeurls', $myconfigs->removeurls);
	add_option('mvb_copyimages', $myconfigs->copyimages);
	add_option('mvb_descsize', $myconfigs->descsize);
	add_option('mvb_imglib', $myconfigs->imglib);
	add_option('mvb_pwsize', $myconfigs->pwsize);
	add_option('mvb_phsize', $myconfigs->phsize);
	add_option('mvb_myplayer', $myconfigs->myplayer);
	add_option('mvb_utf8_active', $myconfigs->utf8_active);
	add_option('mvb_customfield_thumb', $myconfigs->customfield_thumb);
	add_option('mvb_customfield_desc', $myconfigs->customfield_desc);
	add_option('mvb_customfield_vid', $myconfigs->customfield_vid);
	add_option('mvb_customfield_vidsource', $myconfigs->customfield_vidsource);
	add_option('mvb_thumbs_dir', $myconfigs->thumbs_dir);
	add_option('mvb_theme_setting', $myconfigs->theme_setting);
	add_option('mvb_jwplayer', $myconfigs->jwplayer);
	add_option('mvb_customfield_vidembed', $myconfigs->customfield_vidembed);
	add_option('mvb_customfield_vidtime', 'duration');
	add_option('mvb_maxpages', '0');
	$wpdb->query("DROP TABLE ".$table_name."");
	$checkSXE = $wpdb->get_results("SELECT * FROM ".$wpdb->prefix."postmeta WHERE `meta_key` = 'mvb_vid_url' AND `meta_value` LIKE '%SimpleXMLElement%'");
	if($checkSXE) {
	foreach ($checkSXE as $SXE) {
$meta_id = $SXE->meta_id;
$meta_value = $SXE->meta_value;
$meta_value = strstr($meta_value, "http://");
$meta_value = substr($meta_value, 0, -3);
$wpdb->query("UPDATE ".$wpdb->prefix."postmeta SET meta_value = '$meta_value' WHERE meta_id = '$meta_id'");
	}
	}
	require(ABSPATH . 'wp-content/plugins/myvideoblog/mvb_upgrade_v2.php');
	update_option('mvb_installed_ver', $mvb_version);
}

$installed_ver = get_option('mvb_installed_ver');
if((isset($installed_ver)) AND ($installed_ver >= "1.0") AND ($installed_ver < $mvb_version)) {
mvb_update();
}
add_action('admin_head', 'mvbjs_header_admin');

function mvbjs_header_admin() {
	echo '<script type=\'text/javascript\' src=\''.get_bloginfo('wpurl').'/wp-content/plugins/myvideoblog/includes/functions.js\'></script>'."\n";
}
add_action('admin_menu', 'myvideoblog_admin_menu');
function myvideoblog_admin_menu() {
	add_menu_page('MyVideoBlog', 'MyVideoBlog', 'edit_pages', 'myvideoblog/mvb_main.php', 'MyVideoBlog_showfeeds');
        add_submenu_page('myvideoblog/mvb_main.php', 'My Video Sources', 'My Video Sources', 'edit_pages', 'myvideoblog/mvb_main.php', 'MyVideoBlog_showfeeds');
        add_submenu_page('myvideoblog/mvb_main.php', 'Add Video Source', 'Add Video Source', 'edit_pages', 'MVB_Add_New_Feed', 'MyVideoBlog_newfeed');
        add_submenu_page('myvideoblog/mvb_main.php', 'MVB Settings', 'MVB Settings', 'edit_pages', 'MVB_Settings', 'MyVideoBlog_settings');
        add_submenu_page('myvideoblog/mvb_main.php', 'Auto-Updates Settings', 'Auto-Updates Settings', 'edit_pages', 'MVB_Auto-Updates_Settings', 'MyVideoBlog_cronjob');
		add_submenu_page('myvideoblog/mvb_main.php', 'MVB Edit Feed', '', 'edit_pages', 'MVB_Edit_Feed', 'MyVideoBlog_editfeed');
}

add_action('mvbcron_hook','MyVideoBlog_InternalCron');
add_action('deleted_post','MyVideoBlog_RemoveThumb');

register_deactivation_hook(__FILE__, 'stop_mvbcron');
function stop_mvbcron() {
	wp_clear_scheduled_hook('mvbcron_hook');
}
add_filter('cron_schedules', 'more_reccurences');
function more_reccurences() {
return array(
'once_half_hour' => array('interval' => 1800, 'display' => 'Once Half an Hour'),
'once_two_hour' => array('interval' => 7200, 'display' => 'Once Two Hours'),
'once_three_hour' => array('interval' => 10800, 'display' => 'Once Three Hours'),
'weekly' => array('interval' => 604800, 'display' => 'Once Weekly'),
);
}
	
function MyVideoBlog_showfeeds() {
global $wpdb, $wp_version, $mvb_version, $installed_ver;
require(ABSPATH . 'wp-content/plugins/myvideoblog/mvb_showfeeds.php');
}
function MyVideoBlog_newfeed() {
global $wpdb, $wp_version, $mvb_version;
require(ABSPATH . 'wp-content/plugins/myvideoblog/mvb_newfeed.php');
}
function MyVideoBlog_editfeed() {
global $wpdb, $wp_version, $mvb_version;
require(ABSPATH . 'wp-content/plugins/myvideoblog/mvb_editfeed.php');
}
function MyVideoBlog_cronjob() {
global $wpdb, $wp_version, $mvb_version;
require(ABSPATH . 'wp-content/plugins/myvideoblog/mvb_cronjob.php');
}
function MyVideoBlog_rewrite() {
global $wpdb, $wp_version, $mvb_version;
require(ABSPATH . 'wp-content/plugins/myvideoblog/mvb_rewrite.php');
}
function MyVideoBlog_settings() {
global $wpdb, $wp_version, $mvb_version;
require(ABSPATH . 'wp-content/plugins/myvideoblog/mvb_settings.php');
}
function MyVideoBlog_manualupdate() {
global $wpdb, $wp_version, $mvb_version;
$type = "manual";
$showoutput = $_REQUEST['showoutput'];
require(ABSPATH . 'wp-content/plugins/myvideoblog/mvb_getvideos.php');
}
function MyVideoBlog_processfeed() {
global $wpdb, $wp_version, $mvb_version;
$type = "processfeed";
$fid = $_GET['updatefeed'];
$showoutput = $_GET['showoutput'];
require(ABSPATH . 'wp-content/plugins/myvideoblog/mvb_getvideos.php');
}
function MyVideoBlog_InternalCron() {
global $wpdb, $wp_version, $mvb_version;
$type = "internal";
$showoutput = "no";
require(ABSPATH . 'wp-content/plugins/myvideoblog/mvb_getvideos.php');
update_option("mvbcron_triggercount",get_option("mvbcron_triggercount")+1);
}

function MyVideoBlog_RemoveThumb($post_id) {
global $wpdb, $wp_version;
wp_delete_attachment($post_id+1);
$customfield_thumb = get_option('mvb_customfield_thumb');
$thumbs_dir = get_option('mvb_thumbs_dir');
$thumb_path = "".ABSPATH."wp-content/".$thumbs_dir."/";
if( strstr($thumb_path,"\\")){
$thumb_path = str_replace("/", "\\", $thumb_path);
}
$search_id = "img_".$post_id."_";
if(file_exists($thumb_path)) {
$search_thumb_dir = new DirectoryIterator($thumb_path);
foreach ( $search_thumb_dir as $thumb ) {
	$thumb_file = $thumb->getFilename();
	$thumb_full_path = "".$thumb_path."".$thumb_file."";
	if( strstr($thumb_file, $search_id)){
	unlink ($thumb_full_path);
	}
	}
}
}

function mvb_embed_code($postid, $pwsize, $phsize) {
global $wpdb, $id;
$getinfo = get_post_meta($id, mvb_vid_code, true);
if( strstr($getinfo,"|")){
$vidinfo  = explode('|', $getinfo);
$videohost = $vidinfo[0];
$vidcod = $vidinfo[1];
$vidcod = str_replace("http://www.youtube.com/v/", "", $vidcod);
$vidcod = str_replace("http://www.dailymotion.com/swf/video/", "", $vidcod);
$vidcod = str_replace("http://www.dailymotion.com/swf/", "", $vidcod);
$vidcod = str_replace("http://www.metacafe.com/fplayer/", "", $vidcod);
$vidcod = str_replace("/video.swf", "", $vidcod);
$vidcod = str_replace("&related=0", "", $vidcod);
$vidcod = str_replace("&f=gdata_videos", "", $vidcod);
$str_after = strstr($vidcod, "?f");
if ($str_after) {$vidcod = str_replace($str_after, "", $vidcod);}
}else{
$videohost = get_post_meta($id, mvb_vid_source, true);
$vidcod = $getinfo;
}
$removeprefixs = array("gdata.", "en.", "rss.", "playervideo.");
$videohost = str_replace($removeprefixs, "", $videohost);
$jwplayer = get_option('mvb_jwplayer');
$siteurl = get_bloginfo('wpurl');
require(ABSPATH . 'wp-content/plugins/myvideoblog/mvb_players.php');
require(ABSPATH . 'wp-content/plugins/myvideoblog/mvb_showembed.php');
echo $embedcode;
}

function MyVideoBlog_showfooter() {
global $mvb_showversion;
echo "<br><br><div class=\"wrap\"><center>PHP MyVideoBlog PRO V".$mvb_showversion."<br><a href=\"http://www.phpmyvideoblog.com\" target=\"_blank\">www.PHPMyVideoBlog.com</a></center></div><br><br>";
}
?>