<?php
$table_name = $wpdb->prefix . "myvideoblog";
$siteurl = get_bloginfo('wpurl');
$action = $_REQUEST['action'];
$fid = $_REQUEST['editfeed'];
?>
<div class=wrap>
<table width="100%"><tr><td>
<a href="http://www.phpmyvideoblog.com" target="_blank" title="PHPMyVideoBlog.com"><img src="<?php echo $siteurl?>/wp-content/plugins/myvideoblog/includes/mvb.gif" border="0" alt="PHPMyVideoBlog.com"></a>
</td><td>
[<a href="admin.php?page=myvideoblog/mvb_main.php">My Video Sources</a>]
[<a href="admin.php?page=MVB_Add_New_Feed">Add New Video Source</a>]
[<a href="admin.php?page=MVB_Settings">MVB Settings</a>]
[<a href="admin.php?page=MVB_Auto-Updates_Settings">Auto-Updates Settings</a>]
</td></tr></table>
<h2>Edit Video Source - Id: <?php echo $fid;?></h2>
<?php
if ($action == "editfeed") {
$feedurl = $_REQUEST['feedurl'];
$days = $_REQUEST['days'];
$feedcategory = $_REQUEST['feedcategory'];
$maxvideos = $_REQUEST['maxvideos'];
$poststatus = $_REQUEST['poststatus'];
$commentstatus = $_REQUEST['commentstatus'];
$pingstatus = $_REQUEST['pingstatus'];
$author = $_REQUEST['author'];
$getblocktags = $_REQUEST['blocktags'];
$blockwhere = $_REQUEST['blockwhere'];

if (!$feedurl) { echo "<font color=red>Please put a Feed URL.</font><br>";}
else if (!$days) {echo "<font color=red>Please select the weekdays to update this Feed!</font><br>";}
else if (!$feedcategory) {echo "<font color=red>Please select the categories to save your videos.</font><br>";}
else {
if (!$maxvideos) { $maxvideos = "1";}
if ($maxvideos == "0") { $maxvideos = "1";}

foreach ($days as $weekday) {
if ($weekday == "everyday") { $everyday = "yes";}
if ($weekday == "sunday") { $sunday = "yes";}
if ($weekday == "monday") { $monday = "yes";}
if ($weekday == "tuesday") { $tuesday = "yes";}
if ($weekday == "wednesday") { $wednesday = "yes";}
if ($weekday == "thursday") { $thursday = "yes";}
if ($weekday == "friday") { $friday = "yes";}
if ($weekday == "saturday") { $saturday = "yes";}
}

$poststatus = $_REQUEST['poststatus'];
$commentstatus = $_REQUEST['commentstatus'];
$pingstatus = $_REQUEST['pingstatus'];
$author = $_REQUEST['author'];
$scheduletime = $_REQUEST['scheduletime'];
$grab_comments = $_REQUEST['grab_comments'];
$max_comments = $_REQUEST['max_comments'];
$aprove_comments = $_REQUEST['aprove_comments'];

$feedurl = str_replace("gdata.youtube.com/feeds/base/", "gdata.youtube.com/feeds/api/", $feedurl);
$feedurl = str_replace("alt=rss", "alt=atom", $feedurl);
$feedurl = str_replace("alt=json", "alt=atom", $feedurl);
$feedurl = str_replace("alt=json-in-script", "alt=atom", $feedurl);
if ($feedurl) {
$usefeed = $feedurl;
}
$feedcategory = serialize($feedcategory);

$getblocktags = strtolower($getblocktags);
if ($getblocktags == "example|keyword1|keyword2") { $getblocktags == "";}
$blocktags = explode("|", $getblocktags);
$blocktags = serialize($blocktags);

if (isset($blockwhere)) {
foreach ($blockwhere as $block_in) {
if ($block_in == "title") { $checktitle = "yes";}
if ($block_in == "desc") { $checkdesc = "yes";}
if ($block_in == "tags") { $checktags = "yes";}
}
}


$wpdb->query("UPDATE ".$table_name." SET feed = '$usefeed', category = '$feedcategory', maxvideos = '$maxvideos', poststatus = '$poststatus', sunday = '$sunday', monday = '$monday', tuesday = '$tuesday', wednesday = '$wednesday', thursday = '$thursday', friday = '$friday', saturday = '$saturday', commentstatus = '$commentstatus', pingstatus = '$pingstatus', blocktags = '$blocktags', checktitle = '$checktitle', checkdesc = '$checkdesc', checktags = '$checktags', postauthor = '$author', scheduletime = '$scheduletime', grab_comments = '$grab_comments', max_comments = '$max_comments', aprove_comments = '$aprove_comments' WHERE fid = '$fid'");
echo "<center><font color=green>Video source edited successfully!</font></center>";
}
}
?>

<?php
$getfeed = $wpdb->get_row("SELECT fid, feed, category, active, maxvideos, poststatus, sunday, monday, tuesday, wednesday, thursday, friday, saturday, commentstatus, pingstatus, blocktags, checktitle, checkdesc, checktags, postauthor, scheduletime, grab_comments, max_comments, aprove_comments FROM ".$table_name." WHERE fid = '$fid'");
$feed = $getfeed->feed;
$category = $getfeed->category;
$maxvideos = $getfeed->maxvideos;
$poststatus = $getfeed->poststatus;
$commentstatus = $getfeed->commentstatus;
$pingstatus = $getfeed->pingstatus;
$blocktags = unserialize($getfeed->blocktags);
$postauthor = $getfeed->postauthor;
$scheduletime = $getfeed->scheduletime;
$grab_comments = $getfeed->grab_comments;
$max_comments = $getfeed->max_comments;
$aprove_comments = $getfeed->aprove_comments;

if (is_array($blocktags)) {
$blocktags = implode("|", $blocktags);
} else {
$blocktags = "";
}
$checktitle = $getfeed->checktitle;
$checkdesc = $getfeed->checkdesc;
$checktags = $getfeed->checktags;
$sunday = $getfeed->sunday;
$monday = $getfeed->monday;
$tuesday = $getfeed->tuesday;
$wednesday = $getfeed->wednesday;
$thursday = $getfeed->thursday;
$friday = $getfeed->friday;
$saturday = $getfeed->saturday;
?>
<table class="widefat" width="100%" cellspacing="1">
<tr><td>
<form action="admin.php?page=MVB_Edit_Feed" method="post" name="myform">
<input type="hidden" name="action" value="editfeed">
<input type="hidden" name="editfeed" value="<?php echo $fid;?>">
<table width="100%" cellspacing="0">
<tr><td>
<div style="float:left;width=100px;padding-right:3px">
<div><b>Source:</b></div>
<div>
<input type="text" name="feedurl" size="50" value="<?php echo $feed;?>">
</div>
</div>
</td></tr>
<tr><td>
<div id="mvdiv" style="width:100px;float:left;display:block;padding-right:3px">
<div><b>Max Videos:</b></div>
<div>
<input style="font-size:10px;" type="text" name="maxvideos" maxlength="3" size="2" value="<?php echo $maxvideos;?>">
</div>
</div>
</td></tr></table>
<br>
<table width="100%" cellspacing="0">
<tr><td>
<div style="float:left;width=100px;padding-right:3px;">
<div><b>Categories:</b></div>
<div>
<table width="100%" cellspacing="4">
<tr>
<?php
$feedcategories = unserialize($category);
$boxcount=0;
$getcats = $wpdb->get_results("SELECT term_id, term_taxonomy_id FROM $wpdb->term_taxonomy WHERE taxonomy = 'category' ORDER BY term_taxonomy_id DESC");
foreach ($getcats as $thecats) {
$taxocat_id = $thecats->term_id;
$showcat_name = $wpdb->get_var("SELECT name FROM $wpdb->terms WHERE term_id = '$taxocat_id'");
if (in_array($taxocat_id, $feedcategories)) {
echo "<td><input value=\"$taxocat_id\" type=\"checkbox\" name=\"feedcategory[]\" checked>$showcat_name</td>";
} else {
echo "<td><input value=\"$taxocat_id\" type=\"checkbox\" name=\"feedcategory[]\">$showcat_name</td>";
}
$boxcount++;
if ($boxcount == "5") {
echo "</tr><tr>";
$boxcount=0;
}
}
?>
</table>
</div>
</div>
</td></tr></table><br>
<table width="100%" cellspacing="0">
<tr><td>
<b>Skip videos with the following keywords:</b> (separate by | )
<br>
<input type="text" name="blocktags" value="<?php echo $blocktags;?>" size="80">
<br><br>
<b>Check for blocked keywords in:</b>
<br>
<?php
if ($checktitle == "yes") {
echo "<input value=\"title\" type=\"checkbox\" name=\"blockwhere[]\" checked>Video Title<br>";
} else {
echo "<input value=\"title\" type=\"checkbox\" name=\"blockwhere[]\">Video Title<br>";
}
if ($checkdesc == "yes") {
echo "<input value=\"desc\" type=\"checkbox\" name=\"blockwhere[]\" checked>Video Description<br>";
} else {
echo "<input value=\"desc\" type=\"checkbox\" name=\"blockwhere[]\">Video Description<br>";
}
if ($checktags == "yes") {
echo "<input value=\"tags\" type=\"checkbox\" name=\"blockwhere[]\" checked>Video Tags<br>";
} else {
echo "<input value=\"tags\" type=\"checkbox\" name=\"blockwhere[]\">Video Tags<br>";
}
?>
</td></tr>
</table>
<br>
<table cellpadding="0" border="0"><tr>
<td>
<table cellspacing="1" cellpadding="2" bgcolor="#C6D9E9">
<tr><td bgcolor="#E4F2FD"><b>Publish Status:</b></td></tr>
<tr><td bgcolor="#FFF3E0">
<?php
if ($poststatus == "publish") {$publish = "checked";}
if($poststatus == "pending") {$pending = "checked";}
if($poststatus == "draft") {$draft = "checked";}
if($poststatus == "future") {$future = "checked";}
?>
<input value="publish" type="radio" name="poststatus" onClick="hideschedule();" <?php echo $publish;?>>Publish
<input value="pending" type="radio" name="poststatus" onClick="hideschedule();" <?php echo $pending;?>>Pending
<input value="draft" type="radio" name="poststatus" onClick="hideschedule();" <?php echo $draft;?>>Draft
<input value="future" type="radio" name="poststatus" onClick="showschedule();" <?php echo $future;?>>Schedule
</td></tr>
</table>
<?php
if ($poststatus == "future") {
?>
<div id="schedulediv" style="float:left;display:block;padding-right:3px">
<?php
} else {
?>
<div id="schedulediv" style="float:left;display:none;padding-right:3px">
<?php
}
?>
Interval between each post: <input type="text" name="scheduletime" value="<?php echo $scheduletime;?>" size="3" maxlength="10"> Seconds<br>
300 = 5 minutes, 3600 = 1 hour
</div>
</td><td>
<table cellspacing="1" cellpadding="2" bgcolor="#C6D9E9">
<tr><td bgcolor="#E4F2FD"><b>Allow Comments:</b></td></tr>
<tr><td bgcolor="#FFF3E0">
<?php
if ($commentstatus == "open") {$open = "checked";} else if($commentstatus == "closed") {$closed = "checked";}
?>
<input value="open" type="radio" name="commentstatus" <?php echo $open;?>>Yes	
<input value="closed" type="radio" name="commentstatus" <?php echo $closed;?>>No
</td></tr>
</table>
</td><td>
<table cellspacing="1" cellpadding="2" bgcolor="#C6D9E9">
<tr><td bgcolor="#E4F2FD"><b>Allow Pings:</td></tr>
<tr><td bgcolor="#FFF3E0">
<?php
if ($pingstatus == "open") {$pingopen = "checked";} else if($pingstatus == "closed") {$pingclosed = "checked";}
?>
<input value="open" type="radio" name="pingstatus" <?php echo $pingopen;?>>Yes	
<input value="closed" type="radio" name="pingstatus" <?php echo $pingclosed;?>>No
</td></tr>
</table>
</td><td>
<table cellspacing="1" cellpadding="2" bgcolor="#C6D9E9">
<tr><td bgcolor="#E4F2FD"><b>Post Author:</td></tr>
<tr><td bgcolor="#FFF3E0">
<select name="author">
<?php
$getauthors = $wpdb->get_results("SELECT ID, display_name FROM $wpdb->users ORDER BY ID");
foreach ($getauthors as $theauts) {
$author_id = $theauts->ID;
$author_name = $theauts->display_name;
if ($author_id == $postauthor) {
echo "<option value=\"$author_id\" SELECTED>$author_name</option>";
} else {
echo "<option value=\"$author_id\">$author_name</option>";
}
}
?>
</select>
</td></tr>
</table>
</td></tr></table>
<br>
<table cellpadding="0" border="0"><tr>
<td>
<table cellspacing="1" cellpadding="2" bgcolor="#C6D9E9">
<tr><td bgcolor="#E4F2FD"><b>Grab YouTube comments?</b></td></tr>
<tr><td bgcolor="#FFF3E0">
<?php
if ($grab_comments == "yes") {$grabyes = "checked";} else if($grab_comments == "no") {$grabno = "checked";}
?>
<input value="yes" type="radio" name="grab_comments" <?php echo $grabyes;?>>Yes	
<input value="no" type="radio" name="grab_comments" <?php echo $grabno;?>>No
</td></tr>
</table>
</td>
<td>
<table cellspacing="1" cellpadding="2" bgcolor="#C6D9E9">
<tr><td bgcolor="#E4F2FD"><b>Max comments per video:</b></td></tr>
<tr><td bgcolor="#FFF3E0">
<input style="font-size:10px;" type="text" name="max_comments" maxlength="2" size="2" value="<?php echo $max_comments;?>">
</td></tr>
</table>
</td><td>
<table cellspacing="1" cellpadding="2" bgcolor="#C6D9E9">
<tr><td bgcolor="#E4F2FD"><b>Auto aprove these comments?</td></tr>
<tr><td bgcolor="#FFF3E0">
<?php
if ($aprove_comments == "yes") {$aproveyes = "checked";} else if($aprove_comments == "no") {$aproveno = "checked";}
?>
<input value="yes" type="radio" name="aprove_comments" <?php echo $aproveyes;?>>Yes	
<input value="no" type="radio" name="aprove_comments" <?php echo $aproveno;?>>No
</td></tr>
</table>
</td></tr></table><br>
<table cellspacing="1" cellpadding="2" bgcolor="#C6D9E9">
<tr><td bgcolor="#E4F2FD"><b>Update Weekdays:</td></tr>
<tr><td bgcolor="#FFF3E0">
<input value="everyday" type="checkbox" name="days[]" onClick="Check(this)"><b>Everyday</b>
<?php
if ($sunday == "yes") {$checksunday = "checked";}
if ($monday == "yes") {$checkmonday = "checked";}
if ($tuesday == "yes") {$checktuesday = "checked";}
if ($wednesday == "yes") {$checkwednesday = "checked";}
if ($thursday == "yes") {$checkthursday = "checked";}
if ($friday == "yes") {$checkfriday = "checked";}
if ($saturday == "yes") {$checksaturday = "checked";}
?>
 <input value="sunday" type="checkbox" name="days[]" <?php echo $checksunday;?>>Sunday
 <input value="monday" type="checkbox" name="days[]" <?php echo $checkmonday;?>>Monday
 <input value="tuesday" type="checkbox" name="days[]" <?php echo $checktuesday;?>>Tuesday
 <input value="wednesday" type="checkbox" name="days[]" <?php echo $checkwednesday;?>>Wednesday
 <input value="thursday" type="checkbox" name="days[]" <?php echo $checkthursday;?>>Thursday
 <input value="friday" type="checkbox" name="days[]" <?php echo $checkfriday;?>>Friday
 <input value="saturday" type="checkbox" name="days[]" <?php echo $checksaturday;?>>Saturday
</td></tr>
</table>
<br><center><input type="submit" name="submit" class="button" value="EDIT FEED!"></center></form>
</td></tr></table>
</div>

<?php
MyVideoBlog_showfooter();
?>