<?php
require_once(ABSPATH . 'wp-content/plugins/myvideoblog/mvb_functions.php');
$table_name = $wpdb->prefix . "myvideoblog";
$getcats = $wpdb->get_results("SELECT * FROM ".$table_name." ORDER BY fid");
	if($getcats) {
	 foreach ($getcats as $theinfo) {
	 $thecat = $theinfo->category;
	 $thefid = $theinfo->fid;
	 if (!is_array(unserialize($thecat))) {
	 $arraycats = array();
	 $arraycats[] = "".$thecat."";
	 $thecategories = serialize($arraycats);
	 $wpdb->query("UPDATE ".$table_name." SET category = '$thecategories' WHERE fid = '$thefid'");
	 }
	 }
	 }

$olddm = "www.dailymotion.com/rss/tag";
$fixdm = $wpdb->get_results("SELECT fid, feed FROM $table_name WHERE feed LIKE '%".$olddm."%' ORDER BY fid");
if($fixdm) {
	foreach ($fixdm as $dminfo) {
$old_dm_url = $dminfo->feed;
$old_dm_id = $dminfo->fid;
$new_dm_url = str_replace("http://www.dailymotion.com/rss/tag/", "http://www.dailymotion.com/rss/relevance/search/", $old_dm_url);
$wpdb->query("UPDATE $table_name SET feed = '$new_dm_url' WHERE fid = '$old_dm_id'");
	}
}
$old7load = "en.sevenload.com/rss/taggedvideos";
$fix7load = $wpdb->get_results("SELECT fid, feed FROM $table_name WHERE feed LIKE '%".$old7load."%' ORDER BY fid");
if($fix7load) {
	foreach ($fix7load as $sevenloadinfo) {
$old_7l_url = $sevenloadinfo->feed;
$old_7l_id = $sevenloadinfo->fid;
$new_7l_url = str_replace("http://en.sevenload.com/rss/taggedvideos/", "http://rss.sevenload.com/taggedvideos/", $old_7l_url);
$wpdb->query("UPDATE $table_name SET feed = '$new_7l_url' WHERE fid = '$old_7l_id'");
	}
}
$myconfigs = $wpdb->get_row("SELECT tid, postdefault, posttemplate, securitykey, removeurls, copyimages, descsize, imglib, pwsize, phsize, myplayer FROM ".$wpdb->prefix."mvbconfig WHERE tid = '1'");
$mytemplate = $myconfigs->posttemplate;
$mytemplate = stripslashes($mytemplate);
$removeurls = $myconfigs->removeurls;
$copyimages = $myconfigs->copyimages;
$descsize = $myconfigs->descsize;
$imglib = $myconfigs->imglib;
$pwsize = $myconfigs->pwsize;
$phsize = $myconfigs->phsize;

$mvbinfo = "START-MVB-INFO";
$getposts = $wpdb->get_results("SELECT ID, post_content, post_title, guid FROM $wpdb->posts WHERE post_content LIKE '%".$mvbinfo."%' AND post_type = 'post' ORDER BY ID DESC");
if($getposts) {
foreach ($getposts as $postinfo) {
$the_post_id = $postinfo->ID;
$the_post_content = $postinfo->post_content;
$the_post_title = $postinfo->post_title;
$the_post_guid = $postinfo->guid;
 
$pattern = "/vidsource[^>]+\>/i";
preg_match($pattern, $the_post_content, $matches);
$videohost = $matches[0];
$videohost = str_replace("vidsource:", "", $videohost);
$videohost = str_replace("-->", "", $videohost);

$pattern = "/vidcod[^>]+\>/i";
preg_match($pattern, $the_post_content, $matches);
$vidcod = $matches[0];
$vidcod = str_replace("vidcod:", "", $vidcod);
$vidcod = str_replace("-->", "", $vidcod);
$vidcod = str_replace("&f=videos&app=youtube_gdata", "", $vidcod);

$pattern = "/vidimage[^>]+\>/i";
preg_match($pattern, $the_post_content, $matches);
$vidimage = $matches[0];
$vidimage = str_replace("vidimage:", "", $vidimage);
$vidimage = str_replace("-->", "", $vidimage);
$vidimage = str_replace("http://", "", $vidimage);
$vidimage = "http://".$vidimage."";

$pattern = "/viddesc[^>]+\>/i";
preg_match($pattern, $the_post_content, $matches);
$viddesc = $matches[0];
$viddesc = str_replace("viddesc:", "", $viddesc);
$viddesc = str_replace("-->", "", $viddesc);

if ((!$vidcod) OR (!$vidimage)) {
$skiped++;
continue;
}

require(ABSPATH . 'wp-content/plugins/myvideoblog/mvb_showembed.php');
$usetemplate = $mytemplate;
$usetemplate = str_replace("[videoimage]", $vidimage, $usetemplate);
$usetemplate = str_replace("[videotitle]", $the_post_title, $usetemplate);
$usetemplate = str_replace("[posturl]", $the_post_guid, $usetemplate);
$usetemplate = str_replace("[videodescription]", $viddesc, $usetemplate);
$usetemplate = str_replace("[hide]", "<!--more-->", $usetemplate);
$usetemplate = str_replace("[videoplayer]", "<!--videoplayer-->".$embedcode."<!--endvideoplayer-->", $usetemplate);
$usetemplate = addslashes($usetemplate);
$wpdb->query("UPDATE ".$wpdb->prefix."posts SET post_content = '$usetemplate' WHERE ID = '$the_post_id'");

$newvidcod = "".$videohost."|".$vidcod."";
add_post_meta($the_post_id, 'mvb_thumb_url', $vidimage, true) or update_post_meta($the_post_id, 'mvb_thumb_url', $vidimage);
add_post_meta($the_post_id, 'mvb_vid_code', $newvidcod, true) or update_post_meta($the_post_id, 'mvb_vid_code', $newvidcod);
add_post_meta($the_post_id, 'mvb_vid_desc', $viddesc, true) or update_post_meta($the_post_id, 'mvb_vid_desc', $viddesc);
delete_post_meta($the_post_id, 'mvb_video_player');

$total++;
}
}
$wpdb->query("ALTER TABLE ".$table_name." ADD scheduletime int(10) NOT NULL");
$wpdb->query("ALTER TABLE ".$table_name." ADD grab_comments varchar(3) NOT NULL DEFAULT 'no'");
$wpdb->query("ALTER TABLE ".$table_name." ADD max_comments int(50) NOT NULL DEFAULT '0'");
$wpdb->query("ALTER TABLE ".$table_name." ADD aprove_comments varchar(3) NOT NULL DEFAULT 'yes'");
?>