<?php
$table_name = $wpdb->prefix . "myvideoblog";
$server_url = $_SERVER['REQUEST_URI'];
$tv = $_REQUEST['tv'];
$tf = $_REQUEST['tf'];
$siteurl = get_bloginfo('wpurl');

function MyVideoBlog_feedON() {
global $wpdb;
$table_name = $wpdb->prefix . "myvideoblog";
$fid = $_GET['fid'];
$wpdb->query("UPDATE $table_name SET active = 'yes' WHERE fid = '$fid'");
echo "<font color=green>Source $fid is active now!</font><br>";
}

function MyVideoBlog_feedOFF() {
global $wpdb;
$table_name = $wpdb->prefix . "myvideoblog";
$fid = $_GET['fid'];
$wpdb->query("UPDATE $table_name SET active = 'no' WHERE fid = '$fid'");
echo "<font color=red>The source $fid was stopped!</font><br>";
}

function MyVideoBlog_delfeed() {
global $wpdb;
$table_name = $wpdb->prefix . "myvideoblog";
$fid = $_GET['fid'];
$wpdb->query("DELETE FROM $table_name WHERE fid = '$fid'");
echo "<font color=red>The source $fid was deleted!</font><br>";
}

function MyVideoBlog_changemarks() {
global $wpdb;
$table_name = $wpdb->prefix . "myvideoblog";
$markfeeds = $_POST['markfeeds'];
$marksaction = $_POST['marksaction'];

if ($markfeeds) {

foreach($markfeeds as $fid) {

if ($marksaction == "activeon") {
$wpdb->query("UPDATE $table_name SET active = 'yes' WHERE fid = '$fid'");
} else if ($marksaction == "activeoff") {
$wpdb->query("UPDATE $table_name SET active = 'no' WHERE fid = '$fid'");
} else if ($marksaction == "publish") {
$wpdb->query("UPDATE $table_name SET poststatus = 'publish' WHERE fid = '$fid'");
} else if ($marksaction == "pending") {
$wpdb->query("UPDATE $table_name SET poststatus = 'pending' WHERE fid = '$fid'");
} else if ($marksaction == "draft") {
$wpdb->query("UPDATE $table_name SET poststatus = 'draft' WHERE fid = '$fid'");
} else if ($marksaction == "commentopen") {
$wpdb->query("UPDATE $table_name SET commentstatus = 'open' WHERE fid = '$fid'");
} else if ($marksaction == "commentclosed") {
$wpdb->query("UPDATE $table_name SET commentstatus = 'closed' WHERE fid = '$fid'");
} else if ($marksaction == "pingopen") {
$wpdb->query("UPDATE $table_name SET pingstatus = 'open' WHERE fid = '$fid'");
} else if ($marksaction == "pingclosed") {
$wpdb->query("UPDATE $table_name SET pingstatus = 'closed' WHERE fid = '$fid'");
} else if ($marksaction == "delete") {
$wpdb->query("DELETE FROM $table_name WHERE fid = '$fid'");
}

}
echo "<font color=green>Changes saved!</font><br>";
} else {
echo "<font color=red>No video sources selected!</font><br>";
}

}
?>
<div class=wrap>
<table width="100%"><tr><td>
<a href="http://www.phpmyvideoblog.com" target="_blank" title="PHPMyVideoBlog.com"><img src="<?php echo $siteurl?>/wp-content/plugins/myvideoblog/includes/mvb.gif" border="0" alt="PHPMyVideoBlog.com"></a>
</td><td>
[<a href="admin.php?page=myvideoblog/mvb_main.php">My Video Sources</a>]
[<a href="admin.php?page=MVB_Add_New_Feed">Add New Video Source</a>]
[<a href="admin.php?page=MVB_Settings">MVB Settings</a>]
[<a href="admin.php?page=MVB_Auto-Updates_Settings">Auto-Updates Settings</a>]
</td></tr></table>
<?php
switch ($_REQUEST['action']) {
    case "feedon":
	MyVideoBlog_feedON();
        break;
    case "feedoff":
        MyVideoBlog_feedOFF();
        break;
    case "publish":
        MyVideoBlog_publish();
        break;
    case "pending":
        MyVideoBlog_pending();
        break;
    case "draft":
        MyVideoBlog_draft();
        break;
    case "commentopen":
        MyVideoBlog_commentopen();
        break;
    case "commentclosed":
        MyVideoBlog_commentclosed();
        break;
    case "pingopen":
        MyVideoBlog_pingopen();
        break;
    case "pingclosed":
        MyVideoBlog_pingclosed();
        break;
    case "delfeed":
        MyVideoBlog_delfeed();
        break;
    case "changemarks":
        MyVideoBlog_changemarks();
        break;
    case "manualupdate":
        MyVideoBlog_manualupdate();
        break;
	case "processfeed":
        MyVideoBlog_processfeed();
        break;
	case "mu":
        echo "$tv new videos added from $tf feed(s)!<br>";
        break;
}

$oldyt = "www.youtube.com/rss/tag";
$checkyoutube = $wpdb->get_results("SELECT fid, feed FROM $table_name WHERE feed LIKE '%".$oldyt."%' ORDER BY fid");
if($checkyoutube) {
	foreach ($checkyoutube as $ytinfo) {
$old_yt_url = $ytinfo->feed;
$old_yt_id = $ytinfo->fid;
$old_yt_keys = str_replace("http://www.youtube.com/rss/tag/", "", $old_yt_url);
$old_yt_keys = str_replace(".rss", "", $old_yt_keys);
$new_yt_keys = str_replace('-', "/", $old_yt_keys);
$new_yt_url = "http://gdata.youtube.com/feeds/api/videos/-/".$new_yt_keys."/?max-results=50";
$wpdb->query("UPDATE $table_name SET feed = '$new_yt_url' WHERE fid = '$old_yt_id'");
	}
}

$fixyt = "max-results=80";
$fixyoutube = $wpdb->get_results("SELECT fid, feed FROM $table_name WHERE feed LIKE '%".$fixyt."%' ORDER BY fid");
if($fixyoutube) {
	foreach ($fixyoutube as $fixytinfo) {
$fixold_yt_url = $fixytinfo->feed;
$fixold_yt_id = $fixytinfo->fid;
$fixnew_yt_url = str_replace("max-results=80", "max-results=50", $fixold_yt_url);
$wpdb->query("UPDATE $table_name SET feed = '$fixnew_yt_url' WHERE fid = '$fixold_yt_id'");
	}
}

$oldshuf1 = "http://www.shufuni.com/rssnews.xml?ct=amateur";
$newshuf1 = "http://www.shufuni.com/rssnews.xml?ct=amateurs";
$checkshuf1 = $wpdb->get_results("SELECT fid, feed FROM $table_name WHERE feed = '$oldshuf1' ORDER BY fid");
if($checkshuf1) {
	foreach ($checkshuf1 as $shuf1info) {
$old_shuf1_id = $shuf1info->fid;
$wpdb->query("UPDATE $table_name SET feed = '$newshuf1' WHERE fid = '$old_shuf1_id'");
	}
}

$oldshuf2 = "http://www.shufuni.com/rssnews.xml?ct=shemale";
$newshuf2 = "http://www.shufuni.com/rssnews.xml?ct=Transexuals";
$checkshuf2 = $wpdb->get_results("SELECT fid, feed FROM $table_name WHERE feed = '$oldshuf2' ORDER BY fid");
if($checkshuf2) {
	foreach ($checkshuf2 as $shuf2info) {
$old_shuf2_id = $shuf2info->fid;
$wpdb->query("UPDATE $table_name SET feed = '$newshuf2' WHERE fid = '$old_shuf2_id'");
	}
}

$totalfeeds = $wpdb->get_var("SELECT count(*) FROM $table_name");

if ($totalfeeds >= "1") {
?>
<center>
<table width="100%" cellspacing="1">
<tr><td align="left">
<h2>My Video Sources</h2>
</td></tr>
</table>

<form action="<?php echo $server_url;?>" method="post" name="marksform" id="marksform">
<table class="widefat" width="100%" cellspacing="0">
<thead>
<tr>
<th scope="col"><b><a href="admin.php?page=myvideoblog/mvb_main.php&show=byid&order=<?php if($_GET['order'] == "ASC") {echo "DESC";} else {echo "ASC";}?>" style="color:#333;font-style:bold"><u>ID</u></a></b></th>
<th scope="col"><b><a href="admin.php?page=myvideoblog/mvb_main.php&show=bysource&order=<?php if($_GET['order'] == "ASC") {echo "DESC";} else {echo "ASC";}?>" style="color:#333;font-style:bold"><u>Video Sources</u></a></b></th>
<th scope="col"><b><a href="admin.php?page=myvideoblog/mvb_main.php&show=bystatus&order=<?php if($_GET['order'] == "ASC") {echo "DESC";} else {echo "ASC";}?>" style="color:#333;font-style:bold"><u>Status</u></a></b></th>
<th scope="col"><b><a href="admin.php?page=myvideoblog/mvb_main.php&show=bycats&order=<?php if($_GET['order'] == "ASC") {echo "DESC";} else {echo "ASC";}?>" style="color:#333;font-style:bold"><u>Categories</u></a></b></th>
<th scope="col"><b><a href="admin.php?page=myvideoblog/mvb_main.php&show=bypoststatus&order=<?php if($_GET['order'] == "ASC") {echo "DESC";} else {echo "ASC";}?>" style="color:#333;font-style:bold"><u>Post Status</u></a></b></th>
<th scope="col"><b>Edit</b></th>
<th scope="col"><b>Del</b></th>
<th scope="col">
<input type="hidden" name="action" value="changemarks">
<input value="markall" type="checkbox" name="markfeeds[]" onClick="Check(this)">
</th>
</tr>
</thead>
<?php
if($_GET['show'] == "byid") {
$orderby = "fid ".$_GET['order']."";
} else if($_GET['show'] == "bysource") {
$orderby = "feed ".$_GET['order']."";
} else if($_GET['show'] == "bystatus") {
$orderby = "active ".$_GET['order']."";
} else if($_GET['show'] == "bycats") {
$orderby = "category ".$_GET['order']."";
} else if($_GET['show'] == "bypoststatus") {
$orderby = "poststatus ".$_GET['order']."";
} else {
$orderby = "fid DESC";
}
$getfeeds = $wpdb->get_results("SELECT fid, feed, category, active, maxvideos, poststatus, sunday, monday, tuesday, wednesday, thursday, friday, saturday, commentstatus, pingstatus, grab_comments, max_comments, aprove_comments FROM $table_name ORDER BY $orderby");

foreach ($getfeeds as $showfeed) {

if ($showfeed->active == "yes") {
$turn = "<a href=\"$server_url&action=feedoff&fid=$showfeed->fid\" title=\"Change to OFF\"><img src=\"$siteurl/wp-content/plugins/myvideoblog/includes/on.png\" border=\"0\" alt=\"Change to OFF!\"></a>";
} else {
$turn = "<a href=\"$server_url&action=feedon&fid=$showfeed->fid\" title=\"Change to ON\"><img src=\"$siteurl/wp-content/plugins/myvideoblog/includes/off.gif\" border=\"0\" alt=\"Change to ON\"></a></a>";
}

$poststatus = ucwords($showfeed->poststatus);
$commentstatus = ucwords($showfeed->commentstatus);
$pingstatus = ucwords($showfeed->pingstatus);
$grab_comments = ucwords($showfeed->grab_comments);
$max_comments = $showfeed->max_comments;
$aprove_comments = ucwords($showfeed->aprove_comments);

$catid = $showfeed->category;
$rssfeedurl = $showfeed->feed;
$feedhost = $rssfeedurl;
$feedhost = strtolower($feedhost);
$feedhost = str_replace("http://", "", $feedhost);
$feedhost = str_replace("www.", "", $feedhost);
$feedhost2 = strstr($feedhost, "/");
if ($feedhost2) {
	$feedhost = str_replace($feedhost2, "", $feedhost);
}
$thesource = str_replace("http://www.", "", $rssfeedurl);
$thesource = str_replace("http://rss.", "", $thesource);
$thesource = str_replace("http://gdata.", "", $thesource);
$thesource = str_replace("http://en.", "", $thesource);
$thesource = str_replace("http://video.", "", $thesource);
$thesource = str_replace("http://playervideo.", "", $thesource);
$thesource2 = strstr($thesource, ".com");
$thesource = str_replace($thesource2, "", $thesource);
$thesource = ucwords($thesource);
$sunday = $showfeed->sunday;
$monday = $showfeed->monday;
$tuesday = $showfeed->tuesday;
$wednesday = $showfeed->wednesday;
$thursday = $showfeed->thursday;
$friday = $showfeed->friday;
$saturday = $showfeed->saturday;

$weekday = array($sunday, $monday, $tuesday, $wednesday, $thursday, $friday, $saturday);
if ($weekday[0] == "yes") { $sun = "Sunday";} else { $sun = "";}
if ($weekday[1] == "yes") { $mon = "Monday";} else { $mon = "";}
if ($weekday[2] == "yes") { $tue = "Tuesday";} else { $tue = "";}
if ($weekday[3] == "yes") { $wed = "Wednesday";} else { $wed = "";}
if ($weekday[4] == "yes") { $thu = "Thursday";} else { $thu = "";}
if ($weekday[5] == "yes") { $fri = "Friday";} else { $fri = "";}
if ($weekday[6] == "yes") { $sat = "Saturday";} else { $sat = "";}

if (($sunday == "yes") AND  ($monday == "yes") AND ($tuesday == "yes") AND ($wednesday == "yes") AND ($thursday == "yes") AND ($friday == "yes") AND ($saturday == "yes")) { $everyday = "yes";} else { $everyday = "no";}
if ($everyday == "yes") {
$showweekdays = "<font size=1 color=#808080><b>Updates:</b> Everyday</font>";
} else {
$showweekdays = "<font size=1 color=#808080><b>Updates:</b> $sun $mon $tue $wed $thu $fri $sat</font>";
}

$showcats = unserialize($showfeed->category);
?>
<tr><td bgcolor="#DDDDDD"><b><?php  echo $showfeed->fid;?></b></td>
<td width="35%" align="left" valign="middle" bgcolor="#FFF3E0">
<?php
if (($thesource == "Shufuni") OR ($thesource == "Pornhub") OR ($thesource == "Xvideos") OR ($thesource == "Redtube") OR ($thesource == "Deviantclip") OR ($thesource == "Keezmovies") OR ($thesource == "Megaporn") OR ($thesource == "Globo") OR ($thesource == "Megavideo") OR ($thesource == "Hardsextube") OR ($thesource == "Extremetube")) {
?>
<a href="<?php  echo $showfeed->feed;?>" target="_blank" title="View Page"><img src="<?php echo $siteurl;?>/wp-content/plugins/myvideoblog/includes/web.png" border="0" alt="View Page"></a> <a href="<?php  echo $showfeed->feed;?>" target="_blank" title="View Page"><?php  echo $thesource;?></a>
<?php
} else {
?>
<a href="<?php  echo $showfeed->feed;?>" target="_blank" title="View Feed"><img src="<?php echo $siteurl;?>/wp-content/plugins/myvideoblog/includes/feed_go.png" border="0" alt="View Feed"></a> <a href="<?php  echo $showfeed->feed;?>" target="_blank" title="View Feed"><?php  echo $thesource?></a>
<?php
}
?>
<br><?php  echo $showweekdays;?>
<?php
echo "<br><font size=1 color=#808080><b>Max Videos:</b> ".$showfeed->maxvideos."  <b>Comments:</b> ".$commentstatus."  <b>Ping:</b> ".$pingstatus."</font>";
if($thesource == "Youtube"){echo "<br><font size=1 color=#808080><b>Grab comments:</b> ".$grab_comments." <b>Max:</b> ".$max_comments." <b>Auto aprove:</b> ".$aprove_comments."</font>";}
//echo "<font size=1 color=#c0c0c0><br>$showfeed->feed</font>";
echo "<br><a href=\"".$server_url."&action=processfeed&updatefeed=".$showfeed->fid."&showoutput=yes\">Update now!</a>";
?>
</td>
<td bgcolor="#DDDDDD"><?php  echo $turn;?></td>
<td bgcolor="#DDDDDD">
<?php
$cncount=0;
foreach ($showcats as $taxocat_id) {
$feedcatname = $wpdb->get_var("SELECT name FROM $wpdb->terms WHERE term_id=$taxocat_id");
if ($cncount > "0") {echo "&nbsp;|&nbsp;";}
echo "<a href=\"admin.php?page=MVB_Add_New_Feed&feedcategory=".$taxocat_id."\" title=\"Add new feed to ".$feedcatname."\">".$feedcatname."</a>";
$cncount++;
}
?></td>
<td bgcolor="#DDDDDD" width="80"><?php  echo $poststatus?></td>
<td bgcolor="#DDDDDD"><a href="admin.php?page=MVB_Edit_Feed&editfeed=<?php echo $showfeed->fid;?>" title="Edit Feed <?php echo $showfeed->fid;?>"><img src="<?php echo $siteurl?>/wp-content/plugins/myvideoblog/includes/edit.gif" border="0" alt="Edit Feed <?php echo $showfeed->fid;?>"></a></td>
<?php $imgsiteurl = get_option('siteurl');?>
<?php echo"<td bgcolor=\"#FFF3E0\"><a href=\"#\" onclick=\"delconfirm('".$server_url."&action=delfeed&fid=".$showfeed->fid."','Do you really want to delete the Feed ID ".$showfeed->fid." ?');return false;\" title=\"Delete Feed ".$showfeed->fid."\"><img src=\"".$imgsiteurl."/wp-content/plugins/myvideoblog/includes/del.png\" border=\"0\" alt=\"Delete Feed ".$showfeed->fid."\"></a></td>";?>
<th scope="col" valign="top"><input value="<?php  echo $showfeed->fid;?>" type="checkbox" name="markfeeds[]"></th>
</tr>

<?php  } ?>


</table>
<table class="widefat" width="100%" cellspacing="1">
<thead>
<tr>
<th scope="col"><center><b>Tools</b></center></th>
<th scope="col"><center><b>Manual Update</b></center></th>
</tr>
</thead>
<tr><td bgcolor="#FFF3E0" width="35%" align="center">
<select name="marksaction" id="marksform" onchange="this.form.submit();" style="margin: 0 3em 0 3em;">
    <option value="With selected:" selected="selected">With selected:</option>
    <option value="activeon" >Source Status: ON</option>
    <option value="activeoff" >Source Status: OFF</option>
    <option value="publish" >Post Status: Published</option>
    <option value="pending" >Post Status: Pending</option>
    <option value="draft" >Post Status: Unpublished</option>
    <option value="commentopen" >Comment Status: Open</option>
    <option value="commentclosed" >Comment Status: Closed</option>
    <option value="pingopen" >Ping Status: Open</option>
    <option value="pingclosed" >Ping Status: Closed</option>
    <option value="" >--------------</option>
    <option value="delete">Delete</option>
    <option value="" >--------------</option>
</select></form>
</td><td bgcolor="#FFF3E0" width="65%" align="center">
<form action="<?php  echo $server_url?>" method="post" name="manualupdate">
<input type="hidden" name="action" value="manualupdate">
Display Output? <input type="checkbox" name="showoutput" value="yes" checked>&nbsp;&nbsp;&nbsp;<input type="submit" name="submit" class="button-primary" value="Update ALL active sources without date filter!" onclick="this.disabled=disabled">
</form>
</td></tr></table>
</div>
</center>
<?php 
} else {
echo "<center><br><a href=\"admin.php?page=MVB_Add_New_Feed\">Add feeds!</a></center>";
}
MyVideoBlog_showfooter();
?>