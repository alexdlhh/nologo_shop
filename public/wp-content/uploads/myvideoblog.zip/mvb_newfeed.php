<?php
$table_name = $wpdb->prefix . "myvideoblog";
$siteurl = get_bloginfo('wpurl');
?>
<div class=wrap>
<table width="100%"><tr><td>
<a href="http://www.phpmyvideoblog.com" target="_blank" title="PHPMyVideoBlog.com"><img src="<?php echo $siteurl?>/wp-content/plugins/myvideoblog/includes/mvb.gif" border="0" alt="PHPMyVideoBlog.com"></a>
</td><td>
[<a href="admin.php?page=myvideoblog/mvb_main.php">My Video Sources</a>]
[<a href="admin.php?page=MVB_Add_New_Feed">Add New Video Source</a>]
[<a href="admin.php?page=MVB_Settings">MVB Settings</a>]
[<a href="admin.php?page=MVB_Auto-Updates_Settings">Auto-Updates Settings</a>]
</td></tr></table>
<h2>Add new Video Source</h2>
<?php
if ($_REQUEST['action'] == "savefeed") {
if (($_REQUEST['feedsource'] == "youtube") and ($_REQUEST['ytthetype'] == "byuser") and (!$_REQUEST['feedusername']) and (!$_REQUEST['feedurl']))  { echo "<font color=red>Please put the YouTube username.</font><br>";}
else if ((!$_REQUEST['feedkeywords']) and (!$_REQUEST['feedurl'])) { echo "<font color=red>Please put the keywords or put a specific Feed URL.</font><br>";}
else if (!$_REQUEST['days']) {echo "<font color=red>Please select the weekdays to update this Feed!</font><br>";}
else if (!$_REQUEST['feedcategory']) {echo "<font color=red>Please select the categories to save your videos.</font><br>";}
else if (!$_REQUEST['feedsource']) {echo "<font color=red>Please select the feed source!</font><br>";}
else { $maxvideos = $_REQUEST['maxvideos'];
if (!$maxvideos) { $maxvideos = "1";}
if ($maxvideos == "0") { $maxvideos = "1";}

$days = $_REQUEST['days'];
foreach ($days as $weekday) {
if ($weekday == "everyday") { $everyday = "yes";}
if ($weekday == "sunday") { $sunday = "yes";}
if ($weekday == "monday") { $monday = "yes";}
if ($weekday == "tuesday") { $tuesday = "yes";}
if ($weekday == "wednesday") { $wednesday = "yes";}
if ($weekday == "thursday") { $thursday = "yes";}
if ($weekday == "friday") { $friday = "yes";}
if ($weekday == "saturday") { $saturday = "yes";}
}

$mytags = strtolower($_REQUEST['feedkeywords']);
$feedsource = $_REQUEST['feedsource'];
$poststatus = $_REQUEST['poststatus'];
$scheduletime = $_REQUEST['scheduletime'];
$commentstatus = $_REQUEST['commentstatus'];
$pingstatus = $_REQUEST['pingstatus'];
$shufcats = $_REQUEST['shufcats'];
$phcats = $_REQUEST['phcats'];
$ytcats = $_REQUEST['ytcats'];
$redtubecats = $_REQUEST['redtubecats'];
$postauthor = $_REQUEST['author'];
$grab_comments = $_REQUEST['grab_comments'];
$ytlang = $_REQUEST['ytlang'];
$dm_orderby = $_REQUEST['dm_orderby'];
$dm_lang = $_REQUEST['dm_lang'];
$keepsettings = $_REQUEST['keepsettings'];
$hulucats = $_REQUEST['hulucats'];
$hulu_vidtype = $_REQUEST['hulu_vidtype'];
$hulu_orderby = $_REQUEST['hulu_orderby'];
$megaporncats = $_REQUEST['megaporncats'];
$megavideocats = $_REQUEST['megavideocats'];

if($grab_comments == "no"){
$max_comments = "0";
} else {
$max_comments = $_REQUEST['max_comments'];
}
$aprove_comments = $_REQUEST['aprove_comments'];

if($ytlang == "any") {
$bylang = "";
} else {
$bylang = "&lr=".$ytlang."";
}


if ($feedsource == "youtube") {
if ($_REQUEST['ytthetype'] == "byuser") {
$usefeed = "http://gdata.youtube.com/feeds/api/users/".$_REQUEST['feedusername']."/uploads?max-results=50".$bylang."&alt=atom&v=2&orderby=published";
} else {
$mytags = str_replace(', ', "/", $mytags);
$mytags = str_replace(',', "/", $mytags);
$mytags = str_replace(' ', "/", $mytags);
$usefeed = "http://gdata.youtube.com/feeds/api/videos/-/".$ytcats."".$mytags."?max-results=50".$bylang."&alt=atom&v=2&orderby=published";
}
} else if ($feedsource == "dailymotion") {
$mytags = str_replace(', ', "+", $mytags);
$mytags = str_replace(',', "+", $mytags);
$mytags = str_replace(' ', "+", $mytags);
$usefeed = "http://www.dailymotion.com/rss".$dm_orderby."".$dm_lang."/search/".$mytags."";
} else if ($feedsource == "metacafe") {
$mytags = str_replace(', ', "_", $mytags);
$mytags = str_replace(',', "_", $mytags);
$mytags = str_replace(' ', "_", $mytags);
$usefeed = "http://www.metacafe.com/tags/".$mytags."/rss.xml";
} else if ($feedsource == "sevenload") {
$mytags2 = strstr($mytags, ", ");
$mytags = str_replace($mytags2, "", $mytags);
$mytags1 = strstr($mytags, ",");
$mytags = str_replace($mytags1, "", $mytags);
$mytags3 = strstr($mytags, " ");
$mytags = str_replace($mytags3, "", $mytags);
$usefeed = "http://rss.sevenload.com/taggedvideos/".$mytags."?portalId=en";
} else if ($feedsource == "shufuni") {
if ($_REQUEST['shufthetype'] == "shufbysearch") {
$mytags = str_replace(', ', "+", $mytags);
$mytags = str_replace(',', "+", $mytags);
$mytags = str_replace(' ', "+", $mytags);
$usefeed = "http://www.shufuni.com/SearchResult.aspx?search=".$mytags."";
} else {
$usefeed = "http://www.shufuni.com/videos/?ct=$shufcats&or=1";
}
} else if ($feedsource == "break") {
$mytags = str_replace(', ', ",", $mytags);
$mytags = str_replace(',', "-", $mytags);
$usefeed = "http://rss.break.com/keyword/".$mytags."/filterby/videos/";
} else if ($feedsource == "viddler") {
$mytags2 = strstr($mytags, ", ");
$mytags = str_replace($mytags2, "", $mytags);
$mytags1 = strstr($mytags, ",");
$mytags = str_replace($mytags1, "", $mytags);
$mytags3 = strstr($mytags, " ");
$mytags = str_replace($mytags3, "", $mytags);
$usefeed = "http://www.viddler.com/explore/tags/".$mytags."/feed/";
} else if ($feedsource == "xvideos") {
$mytags = str_replace(', ', "+", $mytags);
$mytags = str_replace(',', "+", $mytags);
$mytags = str_replace(' ', "+", $mytags);
$usefeed = "http://www.xvideos.com/?k=".$mytags."";
} else if ($feedsource == "pornhub") {
if ($_REQUEST['phthetype'] == "phbysearch") {
$mytags = str_replace(', ', "+", $mytags);
$mytags = str_replace(',', "+", $mytags);
$mytags = str_replace(' ', "+", $mytags);
$usefeed = "http://www.pornhub.com/video/search?search=".$mytags."";
} else {
$usefeed = "http://www.pornhub.com/video?c=".$phcats."&u=2&o=mr";
}
} else if ($feedsource == "kewego") {
$mytags = str_replace(', ', "+", $mytags);
$mytags = str_replace(',', "+", $mytags);
$mytags = str_replace(' ', "+", $mytags);
$usefeed = "http://www.kewego.com/search/?q=".$mytags."&format=rss";
} else if ($feedsource == "yahoo") {
$mytags = str_replace(', ', "+", $mytags);
$mytags = str_replace(',', "+", $mytags);
$mytags = str_replace(' ', "+", $mytags);
$usefeed = "http://video.yahoo.com/rss/video/search?p=".$mytags."";
} else if ($feedsource == "redtube") {
if ($_REQUEST['redthetype'] == "redbysearch") {
$mytags = str_replace(', ', "+", $mytags);
$mytags = str_replace(',', "+", $mytags);
$mytags = str_replace(' ', "+", $mytags);
$usefeed = "http://www.redtube.com/?search=".$mytags."";
} else {
$usefeed = "http://www.redtube.com/redtube/".$redtubecats."";
}
} else if ($feedsource == "deviantclip") {
$mytags = str_replace(', ', "+", $mytags);
$mytags = str_replace(',', "+", $mytags);
$mytags = str_replace(' ', "+", $mytags);
$usefeed = "http://www.deviantclip.com/?m=tube-search&format=&search=".$mytags."";
} else if ($feedsource == "keezmovies") {
$mytags = str_replace(', ', "+", $mytags);
$mytags = str_replace(',', "+", $mytags);
$mytags = str_replace(' ', "+", $mytags);
$usefeed = "http://www.keezmovies.com/videos?search=".$mytags."";
} else if ($feedsource == "megaporn") {
if ($_REQUEST['megapornthetype'] == "megapornbysearch") {
$mytags = str_replace(', ', "+", $mytags);
$mytags = str_replace(',', "+", $mytags);
$mytags = str_replace(' ', "+", $mytags);
$usefeed = "http://www.megaporn.com/video/?c=search&s=".$mytags."";
} else {
$usefeed = "http://www.megaporn.com/video/?c=categories&s=".$megaporncats."";
}
} else if ($feedsource == "megavideo") {
if ($_REQUEST['megavideothetype'] == "megavideobysearch") {
$mytags = str_replace(', ', "+", $mytags);
$mytags = str_replace(',', "+", $mytags);
$mytags = str_replace(' ', "+", $mytags);
$usefeed = "http://www.megavideo.com/?c=search&s=".$mytags."";
} else {
$usefeed = "http://www.megavideo.com/?c=categories&s=".$megavideocats."";
}
} else if ($feedsource == "globo") {
$mytags = str_replace(', ', "+", $mytags);
$mytags = str_replace(',', "+", $mytags);
$mytags = str_replace(' ', "+", $mytags);
$usefeed = "http://playervideo.globo.com/webmedia/GMCBusca?b=".$mytags."&o=1";
} else if ($feedsource == "hulu") {
if ($_REQUEST['huluthetype'] == "hulubysearch") {
$mytags = str_replace(', ', "+", $mytags);
$mytags = str_replace(',', "+", $mytags);
$mytags = str_replace(' ', "+", $mytags);
$usefeed = "http://www.hulu.com/feed/search?query=".$mytags."&sort_by=".$hulu_orderby."&st=0&type=".$hulu_vidtype."";
} else {
$usefeed = "http://www.hulu.com/feed/channel/".$hulucats."?kind=videos&sort=".$hulu_orderby."";
}
} else if ($feedsource == "hardsextube") {
$mytags = str_replace(', ', "+", $mytags);
$mytags = str_replace(',', "+", $mytags);
$mytags = str_replace(' ', "+", $mytags);
$usefeed = "http://www.hardsextube.com/?search=".$mytags."&submit=Search";
} else if ($feedsource == "eporner") {
$mytags = str_replace(', ', " ", $mytags);
$mytags = str_replace(',', " ", $mytags);
$fixtags = strstr($mytags, " ");
$mytags = str_replace($fixtags, "", $mytags);
$usefeed = "http://www.eporner.com/api_xml/".$mytags."/200/0/adddate";
} else if ($feedsource == "extremetube") {
$mytags = str_replace(', ', "+", $mytags);
$mytags = str_replace(',', "+", $mytags);
$mytags = str_replace(' ', "+", $mytags);
$usefeed = "http://www.extremetube.com/videos?search=".$mytags."";
}

$feedurl = $_REQUEST['feedurl'];
$feedurl = str_replace("gdata.youtube.com/feeds/base/", "gdata.youtube.com/feeds/api/", $feedurl);
$feedurl = str_replace("alt=rss", "alt=atom", $feedurl);
$feedurl = str_replace("alt=json", "alt=atom", $feedurl);
$feedurl = str_replace("alt=json-in-script", "alt=atom", $feedurl);
if ($feedurl) {
$usefeed = $feedurl;
}
$feedcategory = serialize($_REQUEST['feedcategory']);

if ($_REQUEST['blocktags'] == "example|keyword1|keyword2") {
$getblocktags == "";
} else {
$getblocktags = strtolower($_REQUEST['blocktags']);
}

$blocktags = explode("|", $getblocktags);
$blocktags = serialize($blocktags);

$blockwhere = $_REQUEST['blockwhere'];
if (is_array($blockwhere)) {
foreach ($blockwhere as $block_in) {
if ($block_in == "title") { $checktitle = "yes";}
if ($block_in == "desc") { $checkdesc = "yes";}
if ($block_in == "tags") { $checktags = "yes";}
}
}

$wpdb->query("INSERT INTO $table_name (fid, feed, category, active, maxvideos, poststatus, sunday, monday, tuesday, wednesday, thursday, friday, saturday, commentstatus, pingstatus, blocktags, checktitle, checkdesc, checktags, postauthor, scheduletime, grab_comments, max_comments, aprove_comments) VALUES ('', '$usefeed', '$feedcategory', 'yes', '$maxvideos', '$poststatus', '$sunday', '$monday', '$tuesday', '$wednesday', '$thursday', '$friday', '$saturday', '$commentstatus', '$pingstatus', '$blocktags', '$checktitle', '$checkdesc', '$checktags', '$postauthor', '$scheduletime', '$grab_comments', '$max_comments', '$aprove_comments')");


echo "<br><center><font color=green>Video Source Added!</font></center>";
}
}
?>
<form action="admin.php?page=MVB_Add_New_Feed" method="post" name="myform">
<input type="hidden" name="action" value="savefeed">
<table class="widefat" style="border-width:0px;border-style:solid;border-spacing:0;width:100%;clear:both;margin:0;-moz-border-radius:0px;-khtml-border-radius:0px;-webkit-border-radius:0px;border-radius:0px;background-color:#F9F9F9"><tr><td valign="top" style="border-bottom-width:0px;">
<table class="widefat" cellspacing="0">
<thead>
<th>
Video Source
</th>
</thead>
<tr><td style="border-bottom-width:0px;">
<table width="100%" cellspacing="0" style="border-bottom-width:0px;">
<tr><td style="border-bottom-width:0px;">
<div style="float:left;width=100px;padding-right:3px">
<div><b>Source:</b></div>
<div>
<select name="feedsource" onchange="showsources(this.value)">
<option value="youtube">YouTube</option>
<option value="dailymotion">Dailymotion</option>
<option value="metacafe">Metacafe</option>
<option value="yahoo">Yahoo! Video</option>
<option value="break">Break</option>
<option value="hulu">Hulu</option>
<option value="globo">Globo</option>
<option value="megavideo">MegaVideo</option>
<option value="viddler">Viddler</option>
<option value="kewego">Kewego</option>
<option value="sevenload">SevenLoad</option>
<option value="">-- Adult Videos: --</option>
<option value="megaporn">MegaPorn</option>
<option value="shufuni">Shufuni</option>
<option value="pornhub">PornHub</option>
<option value="xvideos">Xvideos</option>
<option value="redtube">RedTube</option>
<option value="deviantclip">DeviantClip</option>
<option value="keezmovies">KeezMovies</option>
<option value="hardsextube">Hardsextube</option>
<option value="eporner">Eporner</option>
<option value="extremetube">Extremetube</option>
</select>
</div>
</div>
<div id="yttype" style="float:left;display:block;padding-right:3px">
<div><b>Type:</b></div>
<div>
<select name="ytthetype" onchange="ytchangetype(this.value)" id="yttypes">
<option value="bytags">Keywords</option>
<option value="byuser">Username</option>
</select>
</div>
</div>
<div id="ytdiv" style="float:left;display:block;padding-right:3px">
<div><b>Source Category:</b></div>
<div>
<select name="ytcats">
<option value="">-Any-</option>
<option value="Autos/">Autos & Vehicles</option>
<option value="Comedy/">Comedy</option>
<option value="Education/">Education</option>
<option value="Entertainment/">Entertainment</option>
<option value="Film/">Film & Animation</option>
<option value="Gaming/">Gaming</option>
<option value="Howto/">Howto & Style</option>
<option value="Music/">Music</option>
<option value="News/">News & Politics</option>
<option value="Nonprofits/">Nonprofits & Activism</option>
<option value="People/">People & Blogs</option>
<option value="Pets/">Pets & Animals</option>
<option value="Science/">Science & Technology</option>
<option value="Sports/">Sports</option>
<option value="Travel/">Travel & Events</option>
</select>
</div>
</div>
<div id="ytlangdiv" style="float:left;display:block;padding-right:3px">
<div><b>Language:</b></div>
<div>
<select name="ytlang">
<option value="any">-Any Language-</option>
<option value="en">English</option>
<option value="ar">Arabic</option>
<option value="bg">Bulgarian</option>
<option value="ca">Catalan</option>
<option value="zh-Hans">Chinese (Simplified)</option>
<option value="zh-Hant">Chinese (Traditional)</option>
<option value="hr">Croatian</option>
<option value="cs">Czech</option>
<option value="da">Danish</option>
<option value="nl">Dutch</option>
<option value="et">Estonian</option>
<option value="fi">Finnish</option>
<option value="fr">French</option>
<option value="de">German</option>
<option value="er">Greek</option>
<option value="iw">Hebrew</option>
<option value="hu">Hungarian</option>
<option value="is">Icelandic</option>
<option value="it">Italian</option>
<option value="ja">Japanese</option>
<option value="ko">Korean</option>
<option value="lv">Latvian</option>
<option value="lt">Lithuanian</option>
<option value="no">Norwegian</option>
<option value="pl">Polish</option>
<option value="pt">Portuguese</option>
<option value="ro">Romanian</option>
<option value="ru">Russian</option>
<option value="sr">Serbian</option>
<option value="sk">Slovak</option>
<option value="sl">Slovenian</option>
<option value="es">Spanish</option>
<option value="sv">Swedish</option>
<option value="tr">Turkish</option>
</select>
</div>
</div>
<div id="redtype" style="float:left;display:none;padding-right:3px">
<div><b>Type:</b></div>
<div>
<select name="redthetype" onchange="redchangetype(this.value)" id="redtypes">
<option value="redbysearch">Keywords</option>
<option value="redbycat">Category</option>
</select>
</div>
</div>
<div id="redtubediv" style="float:left;display:none;padding-right:3px">
<div><b>Source Category:</b></div>
<div>
<select name="redtubecats">
<option value="amateur">Amateur</option>
<option value="anal">Anal</option>
<option value="asian">Asian</option>
<option value="bigtits">Big Tits</option>
<option value="blowjob">Blowjob</option>
<option value="cumshot">Cumshot</option>
<option value="ebony">Ebony</option>
<option value="fetish">Fetish</option>
<option value="gay">Gay</option>
<option value="group">Group</option>
<option value="hentai">Hentai</option>
<option value="lesbian">Lesbian</option>
<option value="mature">Mature</option>
<option value="public">Public</option>
<option value="teens">Teens</option>
<option value="wildcrazy">Wild & Crazy</option>
</select>
</div>
</div>
<div id="phtype" style="float:left;display:none;padding-right:3px">
<div><b>Type:</b></div>
<div>
<select name="phthetype" onchange="phchangetype(this.value)" id="phtypes">
<option value="phbysearch">Keywords</option>
<option value="phbycat">Category</option>
</select>
</div>
</div>
<div id="phdiv" style="float:left;display:none;padding-right:3px">
<div><b>Source Category:</b></div>
<div>
<select name="phcats">
<option value="3">Amateur</option>
<option value="35">Anal</option>
<option value="1">Asian</option>
<option value="4">Ass</option>
<option value="5">Babe</option>
<option value="7">Big dick</option>
<option value="8">Big tits</option>
<option value="9">Blonde</option>
<option value="13">Blowjob</option>
<option value="10">Bondage</option>
<option value="11">Brunette</option>
<option value="14">Bukkake</option>
<option value="12">Celebrity</option>
<option value="15">Creampie</option>
<option value="16">Cumshot</option>
<option value="34">Dancing</option>
<option value="17">Ebony</option>
<option value="18">Fetish</option>
<option value="19">Fisting</option>
<option value="32">Funny</option>
<option value="2">Group</option>
<option value="20">Handjob</option>
<option value="21">Hardcore</option>
<option value="36">Hentai</option>
<option value="25">Interracial</option>
<option value="6">Large ladies</option>
<option value="26">Latina</option>
<option value="27">Lesbian</option>
<option value="22">Masturbation</option>
<option value="28">Mature</option>
<option value="29">Milf</option>
<option value="30">Pornstar</option>
<option value="24">Public</option>
<option value="31">Reality</option>
<option value="33">Striptease</option>
<option value="37">Teen</option>
<option value="23">Toys</option>
</select>
</div>
</div>
<div id="shuftype" style="float:left;display:none;padding-right:3px">
<div><b>Type:</b></div>
<div>
<select name="shufthetype" onchange="shufchangetype(this.value)" id="shuftypes">
<option value="shufbysearch">Keywords</option>
<option value="shufbycat">Category</option>
</select>
</div>
</div>
<div id="shufdiv" style="float:left;display:none;padding-right:3px">
<div><b>Source Category:</b></div>
<div>
<select name="shufcats">
<option value="amateurs">Amateurs</option>
<option value="anal">Anal</option>
<option value="asians">Asians</option>
<option value="bbw">BBW</option>
<option value="blowjobs">Blowjobs</option>
<option value="camsex">Cam Sex</option>
<option value="cartoons">Cartoons</option>
<option value="cumshots">Cum Shots</option>
<option value="ebony">Ebony</option>
<option value="fetish">Fetish</option>
<option value="gays">Gays</option>
<option value="groupsex">Groupsex</option>
<option value="hardcore">Hardcore</option>
<option value="interracial">Interracial</option>
<option value="jackingoff">Jacking Off</option>
<option value="jillingoff">Jilling Off</option>
<option value="lesbians">Lesbians</option>
<option value="milf">MILF</option>
<option value="pornstars">Porn Stars</option>
<option value="sexybabes">Sexy Babes</option>
<option value="transexuals">Transexuals</option>
<option value="wtf">What Da F@#k?</option>
</select>
</div>
</div>
<div id="hulutype" style="float:left;display:none;padding-right:3px">
<div><b>Type:</b></div>
<div>
<select name="huluthetype" onchange="huluchangetype(this.value)" id="hulutypes">
<option value="hulubysearch">Keywords</option>
<option value="hulubycat">Channel</option>
</select>
</div>
</div>
<div id="huludiv" style="float:left;display:none;padding-right:3px">
<div><b>Source Channel:</b></div>
<div>
<select name="hulucats">
<option value="Classics">Classics</option>
<option value="Health-and-Wellness">Health and Wellness</option>
<option value="Reality-and-Game-Shows">Reality and Game Shows</option>
<option value="Action-and-Adventure">Action and Adventure</option>
<option value="Comedy">Comedy</option>
<option value="Home-and-Garden">Home and Garden</option>
<option value="Science-Fiction">Science Fiction</option>
<option value="Animation-and-Cartoons">Animation and Cartoons</option>
<option value="Drama">Drama</option>
<option value="Horror-and-Suspense">Horror and Suspense</option>
<option value="Sports">Sports</option>
<option value="Arts-and-Culture">Arts and Culture</option>
<option value="Family">Family</option>
<option value="Music">Music</option>
<option value="Talk-and-Interview">Talk and Interview</option>
<option value="Automotive">Automotive</option>
<option value="Food-and-Leisure">Food and Leisure</option>
<option value="News-and-Information">News and Information</option>
<option value="Videogames">Videogames</option>
<option value="Business">Business</option>
<option value="Green">Green</option>
<option value="Other">Other</option>
<option value="Web">Web</option>
</select>
</div>
</div>
<div id="huluvidtype" style="float:left;display:none;padding-right:3px">
<div><b>Video Type:</b></div>
<div>
<select name="hulu_vidtype">
<option value="all" selected>All</option>
<option value="clips">TV Clips</option>
<option value="episode">TV Full Episodes</option>
<option value="film_clip">Movie Clips</option>
<option value="film_trailer">Movie Trailers</option>
</select>
</div>
</div>
<div id="huluorderdiv" style="float:left;display:none;padding-right:3px">
<div><b>Sort by:</b></div>
<div>
<select name="hulu_orderby">
<option value="relevance" selected>Relevance</option>
<option value="popularity_today">Most Popular Today</option>
<option value="popularity_week">Most Popular This Week</option>
<option value="popularity">Most Popular All Time</option>
<option value="user_rating">User Rating</option>
<option value="pub_date">Recently Added</option>
</select>
</div>
</div>
<div id="megaporntype" style="float:left;display:none;padding-right:3px">
<div><b>Type:</b></div>
<div>
<select name="megapornthetype" onchange="megapornchangetype(this.value)" id="megaporntypes">
<option value="megapornbysearch">Keywords</option>
<option value="megapornbycat">Category</option>
</select>
</div>
</div>
<div id="megaporndiv" style="float:left;display:none;padding-right:3px">
<div><b>Source Category:</b></div>
<div>
<select name="megaporncats">
<option value="122">Amateur</option>
<option value="48">Anal</option>
<option value="47">Anime</option>
<option value="49">Asian</option>
<option value="51">Babes</option>
<option value="123">BIG Dicks</option>
<option value="68">BIG Tits</option>
<option value="52">Bisexual</option>
<option value="53">Black / Ebony</option>
<option value="127">Blonde</option>
<option value="54">Bondage</option>
<option value="128">Brunette</option>
<option value="133">Busty</option>
<option value="55">Celebrity</option>
<option value="132">Creampie</option>
<option value="56">Cum shots</option>
<option value="57">Fetish</option>
<option value="58">Gay</option>
<option value="73">Hardcore</option>
<option value="130">Housewives</option>
<option value="125">Interracial</option>
<option value="60">Large Ladies</option>
<option value="126">Latina</option>
<option value="61">Lesbians</option>
<option value="134">Masturbation</option>
<option value="64">Oral</option>
<option value="129">Orgy</option>
<option value="131">Pornstar</option>
<option value="135">Public</option>
<option value="66">Red heads</option>
<option value="67">She males</option>
<option value="124">Small tits</option>
<option value="76">Soft Erotic</option>
<option value="74">Striptease</option>
<option value="69">Toys</option>
<option value="65">Upskirt</option>
<option value="72">Webcams</option>
</select>
</div>
</div>
<div id="megavideotype" style="float:left;display:none;padding-right:3px">
<div><b>Type:</b></div>
<div>
<select name="megavideothetype" onchange="megavideochangetype(this.value)" id="megavideotypes">
<option value="megavideobysearch">Keywords</option>
<option value="megavideobycat">Category</option>
</select>
</div>
</div>
<div id="megavideodiv" style="float:left;display:none;padding-right:3px">
<div><b>Source Category:</b></div>
<div>
<select name="megavideocats">
<option value="1">Arts &amp; Animations</option> 
<option value="2">Autos &amp; Vehicles</option> 
<option value="23">Comedy</option> 
<option value="24">Entertainment</option> 
<option value="10">Music</option>
<option value="25">News &amp; Blogs</option> 
<option value="22">People</option> 
<option value="15">Pets &amp; Animals</option>
<option value="26">Science &amp; Technology</option>
<option value="17">Sports</option> 
<option value="19">Travel &amp; Places</option>
<option value="20">Video Games</option>
</select>
</div>
</div>
<div id="dmorderdiv" style="float:left;display:none;padding-right:3px">
<div><b>Order by:</b></div>
<div>
<select name="dm_orderby">
<option value="">Most Recent</option>
<option value="/relevance" selected>Relevance</option>
<option value="/commented">Most Commented</option>
<option value="/visited">Most Viewed</option>
<option value="/rated">Best Rated</option>
</select>
</div>
</div>

<div id="dmlangdiv" style="float:left;display:none;padding-right:3px">
<div><b>Language:</b></div>
<div>
<select name="dm_lang">
<option value="">-Any Language-</option>
<option value="/lang/en">English</option>
<option value="/lang/ar">Arabic</option>
<option value="/lang/bn">Bengalli</option>
<option value="/lang/bg">Bulgarian</option>
<option value="/lang/ca">Catalan</option>
<option value="/lang/zh">Chinese</option>
<option value="/lang/hr">Croatian</option>
<option value="/lang/cs">Czech</option>
<option value="/lang/da">Danish</option>
<option value="/lang/nl">Dutch</option>
<option value="/lang/eu">Euskara</option>
<option value="/lang/fl">Filipino</option>
<option value="/lang/fi">Finnish</option>
<option value="/lang/fr">French</option>
<option value="/lang/de">German</option>
<option value="/lang/el">Greek</option>
<option value="/lang/he">Hebrew</option>
<option value="/lang/hi">Hindi</option>
<option value="/lang/hu">Hungarian</option>
<option value="/lang/is">Icelandic</option>
<option value="/lang/it">Italian</option>
<option value="/lang/ja">Japanese</option>
<option value="/lang/jv">Javanese</option>
<option value="/lang/ko">Korean</option>
<option value="/lang/ms">Malay</option>
<option value="/lang/mr">Marathi</option>
<option value="/lang/no">Norwegian</option>
<option value="/lang/fa">Persian</option>
<option value="/lang/pa">Panjabi</option>
<option value="/lang/pl">Polish</option>
<option value="/lang/pt">Portuguese</option>
<option value="/lang/ro">Romanian</option>
<option value="/lang/ru">Russian</option>
<option value="/lang/sr">Serbian</option>
<option value="/lang/sk">Slovak</option>
<option value="/lang/es">Spanish</option>
<option value="/lang/sv">Swedish</option>
<option value="/lang/ta">Tamil</option>
<option value="/lang/te">Telugu</option>
<option value="/lang/th">Thai</option>
<option value="/lang/tr">Turkish</option>
<option value="/lang/uk">Ukrainian</option>
<option value="/lang/ur">Urdu</option>
<option value="/lang/vi">Vietnamese</option>
</select>
</div>
</div>

</td></tr>
</table>
<table width="100%" cellspacing="0" style="border-bottom-width:0px;">
<tr><td style="border-bottom-width:0px;">
<div id="keydiv" style="float:left;display:block;padding-right:3px">
<div><b>Keywords:</b> (Separated by comma.)</div>
<div>
<input type="text" name="feedkeywords" value="<?php if(($keepsettings) AND ($_REQUEST['feedkeywords'])){echo $_REQUEST['feedkeywords'];} else{echo "example,tag,tag";}?>" size="35" <?php if(!$keepsettings) { echo "onfocus=\"this.value='';return false;\"";}?>>
</div>
</div>
<div id="userdiv" style="float:left;display:none;padding-right:3px">
<div><b>Username:</b></div>
<div>
<input type="text" name="feedusername" value="channel/user" size="35" onfocus="this.value='';return false;">
</div>
</div>
<div id="mvdiv" style="width:100px;float:left;display:block;padding-right:3px">
<div><b>Max Videos:</b></div>
<div>
<input style="font-size:10px;" type="text" name="maxvideos" maxlength="3" size="2" value="<?php if(($keepsettings) AND ($_REQUEST['maxvideos'])){echo $_REQUEST['maxvideos'];} else{echo "5";}?>">
</div>
</div>
</td></tr>
</table>
<div id="clicksf" style="display:block";padding-right:3px";>
<br>
<a href="#" onclick="mvbtoggle('showsf'); return false;">Add a custom feed/page <a href="#" onclick="mvbtoggle('mvb_custom_feed'); return false;"><img src="<?php echo $siteurl?>/wp-content/plugins/myvideoblog/includes/help.png" border="0" alt="Click here for Help" title="Click here for Help"></a></a>
<div id="mvb_custom_feed" style="display:none";>
<font size=1><b>Some sites like dailymotion can be used several types of feeds, by tags, by user, by search, by category. If you type some url here, this is the url that will be used and not the keywords box/source box.</b></font>
</div>
</div>
</div>
<?php
if(($keepsettings) AND ($_REQUEST['feedurl'])) {
echo "<div id=\"showsf\" style=\"display:block\";>";
} else {
echo "<div id=\"showsf\" style=\"display:none\";>";
}
?>
<table cellspacing="1" cellpadding="2" bgcolor="#C6D9E9" style="border-bottom-width:0px;">
<tr><td bgcolor="#E4F2FD" style="border-bottom-width:0px;"><b>Specific Feed/Page URL:</td></tr>
<tr><td bgcolor="#FFF3E0" style="border-bottom-width:0px;">
<input type="text" name="feedurl" size="50" value="<?php if(($keepsettings) AND ($_REQUEST['feedurl'])){echo $_REQUEST['feedurl'];} else{echo "";}?>">
</td></tr>
</table><br>
</div>
</td></tr></table>
<br>
<table class="widefat" cellspacing="0">
<thead>
<th>
Video Filter
</th>
</thead>
<tr><td style="border-bottom-width:0px;">
<b>Skip videos with the following keywords:</b> (separate by | )
<br>
<input type="text" name="blocktags" value="<?php if(($keepsettings) AND ($_REQUEST['blocktags'])){echo $_REQUEST['blocktags'];} else{echo "example|keyword1|keyword2";}?>" size="80" onfocus="this.value='';return false;">
<br><br>
<b>Check for blocked keywords in:</b>
<br>
<input value="title" type="checkbox" name="blockwhere[]" <?php if($checktitle == "yes"){echo "checked";} else{echo "";}?>>Video Title<br>
<input value="desc" type="checkbox" name="blockwhere[]" <?php if($checkdesc == "yes"){echo "checked";} else{echo "";}?>>Video Description<br>
<input value="tags" type="checkbox" name="blockwhere[]" <?php if($checktags == "yes"){echo "checked";} else{echo "";}?>>Video Tags<br>
</td></tr>
</table>
<br>
<table class="widefat" cellspacing="0">
<thead>
<th>
Post Options
</th>
</thead>
<tr><td style="border-bottom-width:0px;">

<table cellspacing="4" cellpadding="4" bgcolor="#C6D9E9" style="border-bottom-width:0px;">
<tr><td bgcolor="#E4F2FD" style="border-bottom-width:0px;"><b>Publish Status:</b></td>
<td bgcolor="#FFF3E0" style="border-bottom-width:0px;">
<input value="publish" type="radio" name="poststatus"  onClick="hideschedule();" <?php if(($keepsettings) AND ($_REQUEST['poststatus'] == "publish")){echo "checked";} else if(!$keepsettings){echo "checked";}?>>Publish
<input value="pending" type="radio" name="poststatus" onClick="hideschedule();" <?php if(($keepsettings) AND ($_REQUEST['poststatus'] == "pending")){echo "checked";}?>>Pending
<input value="draft" type="radio" name="poststatus" onClick="hideschedule();" <?php if(($keepsettings) AND ($_REQUEST['poststatus'] == "draft")){echo "checked";}?>>Draft
<input value="future" type="radio" name="poststatus" onClick="showschedule();" <?php if(($keepsettings) AND ($_REQUEST['poststatus'] == "future")){echo "checked";}?>>Schedule
<?php
if (($keepsettings) AND ($_REQUEST['poststatus'] == "future")) {
echo "<div id=\"schedulediv\" style=\"float:left;display:block;padding-right:3px\">";
} else {
echo "<div id=\"schedulediv\" style=\"float:left;display:none;padding-right:3px\">";
}
?>
Interval between each post: <input type="text" name="scheduletime" value="<?php if(($keepsettings) AND ($_REQUEST['scheduletime'])){echo $_REQUEST['scheduletime'];}?>" size="3" maxlength="10"> Seconds<br>
300 = 5 minutes, 3600 = 1 hour
</div>
</td></tr>
<tr><td bgcolor="#E4F2FD" style="border-bottom-width:0px;"><b>Allow Comments:</b></td>
<td bgcolor="#FFF3E0" style="border-bottom-width:0px;"><input value="open" type="radio" name="commentstatus" <?php if(($keepsettings) AND ($_REQUEST['commentstatus'] == "open")){echo "checked";} else if(!$keepsettings){echo "checked";}?>>Yes	
<input value="closed" type="radio" name="commentstatus" <?php if(($keepsettings) AND ($_REQUEST['commentstatus'] == "closed")){echo "checked";}?>>No
</td></tr>

<tr><td bgcolor="#E4F2FD" style="border-bottom-width:0px;"><b>Allow Pings:</td>
<td bgcolor="#FFF3E0" style="border-bottom-width:0px;">
<input value="open" type="radio" name="pingstatus" <?php if(($keepsettings) AND ($_REQUEST['pingstatus'] == "open")){echo "checked";} else if(!$keepsettings){echo "checked";}?>>Yes	
<input value="closed" type="radio" name="pingstatus" <?php if(($keepsettings) AND ($_REQUEST['pingstatus'] == "closed")){echo "checked";}?>>No
</td></tr>

<tr><td bgcolor="#E4F2FD" style="border-bottom-width:0px;"><b>Post Author:</td>
<td bgcolor="#FFF3E0" style="border-bottom-width:0px;">
<select name="author">
<?php
$getauthors = $wpdb->get_results("SELECT ID, display_name FROM $wpdb->users ORDER BY ID");
foreach ($getauthors as $theauts) {
$author_id = $theauts->ID;
$author_name = $theauts->display_name;
if(($keepsettings) AND ($_REQUEST['author'] == $author_id)){
echo "<option value=\"$author_id\" selected>$author_name</option>";
} else {
echo "<option value=\"$author_id\">$author_name</option>";
}
}
?>
</select>
</td></tr>
</table>
<div id="comments_div" style="display:block;">

<table cellspacing="4" cellpadding="4" bgcolor="#C6D9E9" style="border-bottom-width:0px;">
<tr><td bgcolor="#E4F2FD" style="border-bottom-width:0px;"><b>Grab YouTube comments?</b></td>
<td bgcolor="#FFF3E0" style="border-bottom-width:0px;"><input value="yes" type="radio" name="grab_comments" <?php if(($keepsettings) AND ($_REQUEST['grab_comments'] == "yes")){echo "checked";}?>>Yes	
<input value="no" type="radio" name="grab_comments" <?php if(($keepsettings) AND ($_REQUEST['grab_comments'] == "no")){echo "checked";} else if(!$keepsettings){echo "checked";}?>>No
</td></tr>

<tr><td bgcolor="#E4F2FD" style="border-bottom-width:0px;"><b>Max comments per video:</b></td>
<td bgcolor="#FFF3E0" style="border-bottom-width:0px;">
<input style="font-size:10px;" type="text" name="max_comments" maxlength="2" size="2" value="<?php if(($keepsettings) AND ($_REQUEST['max_comments'])){echo $_REQUEST['max_comments'];} else {echo "20";}?>">
</td></tr>

<tr><td bgcolor="#E4F2FD" style="border-bottom-width:0px;"><b>Auto aprove these comments?</td>
<td bgcolor="#FFF3E0" style="border-bottom-width:0px;">
<input value="yes" type="radio" name="aprove_comments" <?php if(($keepsettings) AND ($_REQUEST['aprove_comments'] == "yes")){echo "checked";} else if(!$keepsettings){echo "checked";}?>>Yes	
<input value="no" type="radio" name="aprove_comments" <?php if(($keepsettings) AND ($_REQUEST['aprove_comments'] == "no")){echo "checked";}?>>No
</td></tr>
</table>

</div>
</td></tr></table>
</td><td width="200" valign="top" style="border-bottom-width:0px;">
<table class="widefat" cellspacing="0">
<thead>
<th>
Days to Update
</th>
</thead>
<tr><td bgcolor="#E4F2FD" style="border-bottom-width:0px;">
<input value="everyday" type="checkbox" name="days[]" onClick="Check(this)"><b>Everyday</b>
<br><input value="sunday" type="checkbox" name="days[]" <?php if(($keepsettings) AND ($sunday == "yes")){echo "checked";}?>>Sunday
<br><input value="monday" type="checkbox" name="days[]" <?php if(($keepsettings) AND ($monday == "yes")){echo "checked";}?>>Monday
<br><input value="tuesday" type="checkbox" name="days[]" <?php if(($keepsettings) AND ($tuesday == "yes")){echo "checked";}?>>Tuesday
<br><input value="wednesday" type="checkbox" name="days[]" <?php if(($keepsettings) AND ($wednesday == "yes")){echo "checked";}?>>Wednesday
<br><input value="thursday" type="checkbox" name="days[]" <?php if(($keepsettings) AND ($thursday == "yes")){echo "checked";}?>>Thursday
<br><input value="friday" type="checkbox" name="days[]" <?php if(($keepsettings) AND ($friday == "yes")){echo "checked";}?>>Friday
<br><input value="saturday" type="checkbox" name="days[]" <?php if(($keepsettings) AND ($saturday == "yes")){echo "checked";}?>>Saturday
</td></tr>
</table><br>
<table class="widefat" cellspacing="0">
<thead>
<th>
Categories
</th>
</thead>
<tr><td style="border-bottom-width:0px;">
<table width="100%" cellspacing="0">
<?php
$getcats = $wpdb->get_results("SELECT term_id, term_taxonomy_id FROM $wpdb->term_taxonomy WHERE taxonomy = 'category' ORDER BY term_taxonomy_id DESC");
foreach ($getcats as $thecats) {
$taxocat_id = $thecats->term_id;
$showcat_name = $wpdb->get_var("SELECT name FROM $wpdb->terms WHERE term_id = '$taxocat_id'");

if(($keepsettings) AND ($_REQUEST['feedcategory'])) {
foreach ($_REQUEST['feedcategory'] as $thecategory) {
if($taxocat_id == $thecategory) {
$waschecked = 1;
echo "<tr><td style=\"border-bottom-width:0px;\"><input value=\"$taxocat_id\" type=\"checkbox\" name=\"feedcategory[]\" checked>$showcat_name</td></tr>";
}
}
} else if((!$keepsettings) AND ($_REQUEST['feedcategory'])) {
if($taxocat_id == $_REQUEST['feedcategory']) {
$waschecked = 1;
echo "<tr><td style=\"border-bottom-width:0px;\"><input value=\"$taxocat_id\" type=\"checkbox\" name=\"feedcategory[]\" checked>$showcat_name</td></tr>";
}
}

if ($waschecked == "1") {
$waschecked = 0;
continue;
}
echo "<tr><td style=\"border-bottom-width:0px;\"><input value=\"$taxocat_id\" type=\"checkbox\" name=\"feedcategory[]\">$showcat_name</td></tr>";
}
?>
</table>
</td></tr></table>
</td></tr></table>
<br><center>
<input value="ks_yes" type="checkbox" name="keepsettings" <?php if($keepsettings){echo "checked";}?>> Keep these settings for next source.<br>
<input type="submit" name="submit" class="button-primary" value="ADD VIDEO SOURCE!">
</center>
</form>
<br>
<?php
MyVideoBlog_showfooter();
?>