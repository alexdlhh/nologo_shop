CREATE TABLE `wp_bp_messages_messages` (  `id` bigint(20) NOT NULL AUTO_INCREMENT,  `thread_id` bigint(20) NOT NULL,  `sender_id` bigint(20) NOT NULL,  `subject` varchar(200) NOT NULL,  `message` longtext NOT NULL,  `date_sent` datetime NOT NULL,  PRIMARY KEY (`id`),  KEY `sender_id` (`sender_id`),  KEY `thread_id` (`thread_id`)) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `wp_bp_messages_messages` DISABLE KEYS */;
INSERT INTO `wp_bp_messages_messages` VALUES('1', '1', '3', 'como estás', 'funcionando...', '2011-06-22 20:14:10');
INSERT INTO `wp_bp_messages_messages` VALUES('2', '2', '1', 'hola', 'como estás', '2011-08-22 19:31:08');
/*!40000 ALTER TABLE `wp_bp_messages_messages` ENABLE KEYS */;
