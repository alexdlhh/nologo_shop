CREATE TABLE `wp_wp_eStore_cat_tbl` (  `cat_id` int(12) NOT NULL AUTO_INCREMENT,  `cat_name` varchar(64) NOT NULL DEFAULT 'Uncategorized',  `cat_desc` text NOT NULL,  `cat_parent` int(12) NOT NULL,  `cat_image` varchar(255) NOT NULL,  `cat_url` varchar(255) NOT NULL,  PRIMARY KEY (`cat_id`)) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `wp_wp_eStore_cat_tbl` DISABLE KEYS */;
INSERT INTO `wp_wp_eStore_cat_tbl` VALUES('1', 'Maillots Exclusivos', 'Maillots de dise&ntilde;o exclusivo utilizados por nuestras gimnastas en alta competici&oacute;n', '0', '', '');
/*!40000 ALTER TABLE `wp_wp_eStore_cat_tbl` ENABLE KEYS */;
