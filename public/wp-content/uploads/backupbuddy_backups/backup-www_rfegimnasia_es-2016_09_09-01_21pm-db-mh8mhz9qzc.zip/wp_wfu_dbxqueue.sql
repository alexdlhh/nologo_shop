CREATE TABLE `wp_wfu_dbxqueue` (  `iddbxqueue` mediumint(9) NOT NULL AUTO_INCREMENT,  `fileid` mediumint(9) NOT NULL,  `priority` mediumint(9) NOT NULL,  `status` mediumint(9) NOT NULL,  `jobid` varchar(10) NOT NULL,  `start_time` bigint(20) DEFAULT NULL,  PRIMARY KEY (`iddbxqueue`)) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `wp_wfu_dbxqueue` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_wfu_dbxqueue` ENABLE KEYS */;
