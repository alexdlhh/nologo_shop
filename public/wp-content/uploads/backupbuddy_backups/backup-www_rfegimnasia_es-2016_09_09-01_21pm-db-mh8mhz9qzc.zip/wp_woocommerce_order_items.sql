CREATE TABLE `wp_woocommerce_order_items` (  `order_item_id` bigint(20) NOT NULL AUTO_INCREMENT,  `order_item_name` longtext NOT NULL,  `order_item_type` varchar(200) NOT NULL DEFAULT '',  `order_id` bigint(20) NOT NULL,  PRIMARY KEY (`order_item_id`),  KEY `order_id` (`order_id`)) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `wp_woocommerce_order_items` DISABLE KEYS */;
INSERT INTO `wp_woocommerce_order_items` VALUES('1', 'Calendario 2014 Gimnasia Rítmica', 'line_item', '13466');
/*!40000 ALTER TABLE `wp_woocommerce_order_items` ENABLE KEYS */;
