CREATE TABLE `wp_doptg_galleries` (  `id` int(11) NOT NULL AUTO_INCREMENT,  `name` varchar(128) NOT NULL DEFAULT '',  UNIQUE KEY `id` (`id`)) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40000 ALTER TABLE `wp_doptg_galleries` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_doptg_galleries` ENABLE KEYS */;
