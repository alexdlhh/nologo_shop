CREATE TABLE `wp_gf_addon_feed` (  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,  `form_id` mediumint(8) unsigned NOT NULL,  `is_active` tinyint(1) NOT NULL DEFAULT '1',  `feed_order` mediumint(8) unsigned NOT NULL DEFAULT '0',  `meta` longtext,  `addon_slug` varchar(50) DEFAULT NULL,  PRIMARY KEY (`id`),  KEY `addon_form` (`addon_slug`,`form_id`)) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `wp_gf_addon_feed` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_gf_addon_feed` ENABLE KEYS */;
