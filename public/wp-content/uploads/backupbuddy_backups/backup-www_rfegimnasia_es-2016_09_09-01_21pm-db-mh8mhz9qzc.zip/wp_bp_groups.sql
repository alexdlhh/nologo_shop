CREATE TABLE `wp_bp_groups` (  `id` bigint(20) NOT NULL AUTO_INCREMENT,  `creator_id` bigint(20) NOT NULL,  `name` varchar(100) NOT NULL,  `slug` varchar(200) NOT NULL,  `description` longtext NOT NULL,  `status` varchar(10) NOT NULL DEFAULT 'public',  `enable_forum` tinyint(1) NOT NULL DEFAULT '1',  `date_created` datetime NOT NULL,  PRIMARY KEY (`id`),  KEY `creator_id` (`creator_id`),  KEY `status` (`status`)) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `wp_bp_groups` DISABLE KEYS */;
INSERT INTO `wp_bp_groups` VALUES('2', '1', 'Equipo GAM', 'equipo-gam', 'Equipo Nacional de Gimnasia Artística Masculina', 'public', '0', '2011-08-22 18:55:14');
/*!40000 ALTER TABLE `wp_bp_groups` ENABLE KEYS */;
