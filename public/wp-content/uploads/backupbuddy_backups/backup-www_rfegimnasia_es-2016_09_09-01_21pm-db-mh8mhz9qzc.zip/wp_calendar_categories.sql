CREATE TABLE `wp_calendar_categories` (  `category_id` int(11) NOT NULL AUTO_INCREMENT,  `category_name` varchar(30) COLLATE latin1_general_ci NOT NULL,  `category_colour` varchar(30) COLLATE latin1_general_ci NOT NULL,  PRIMARY KEY (`category_id`)) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40000 ALTER TABLE `wp_calendar_categories` DISABLE KEYS */;
INSERT INTO `wp_calendar_categories` VALUES('1', 'General', '#F6F79B');
INSERT INTO `wp_calendar_categories` VALUES('2', 'Gimnasia Masculina Nacional', '00ccff');
INSERT INTO `wp_calendar_categories` VALUES('3', 'Gimnasia Femenina Nacional', 'ff0000');
INSERT INTO `wp_calendar_categories` VALUES('4', '', '');
/*!40000 ALTER TABLE `wp_calendar_categories` ENABLE KEYS */;
