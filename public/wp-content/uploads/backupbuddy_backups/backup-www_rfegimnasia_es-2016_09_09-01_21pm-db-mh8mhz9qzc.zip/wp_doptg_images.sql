CREATE TABLE `wp_doptg_images` (  `id` int(11) NOT NULL AUTO_INCREMENT,  `gallery_id` int(11) NOT NULL,  `name` varchar(128) NOT NULL DEFAULT '',  `title` varchar(128) NOT NULL DEFAULT '',  `caption` text NOT NULL,  `position` int(11) NOT NULL DEFAULT '0',  UNIQUE KEY `id` (`id`)) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40000 ALTER TABLE `wp_doptg_images` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_doptg_images` ENABLE KEYS */;
