CREATE TABLE `wp_events_personnel` (  `id` int(11) NOT NULL AUTO_INCREMENT,  `name` varchar(250) DEFAULT NULL,  `role` varchar(250) DEFAULT NULL,  `identifier` varchar(26) DEFAULT '0',  `email` text,  `meta` text,  `wp_user` int(22) DEFAULT '1',  UNIQUE KEY `id` (`id`),  KEY `identifier` (`identifier`),  KEY `wp_user` (`wp_user`)) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `wp_events_personnel` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_events_personnel` ENABLE KEYS */;
