CREATE TABLE `wp_translate_langs` (  `id` int(11) NOT NULL AUTO_INCREMENT,  `name` varchar(25) COLLATE latin1_general_ci NOT NULL,  `main` tinyint(1) NOT NULL DEFAULT '0',  `order` tinyint(1) NOT NULL DEFAULT '0',  `icon` varchar(20) COLLATE latin1_general_ci NOT NULL DEFAULT '',  PRIMARY KEY (`id`)) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40000 ALTER TABLE `wp_translate_langs` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_translate_langs` ENABLE KEYS */;
