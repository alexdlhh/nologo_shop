CREATE TABLE `wp_bp_xprofile_groups` (  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,  `name` varchar(150) NOT NULL,  `description` mediumtext NOT NULL,  `can_delete` tinyint(1) NOT NULL,  `group_order` bigint(20) NOT NULL DEFAULT '0',  PRIMARY KEY (`id`),  KEY `can_delete` (`can_delete`)) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `wp_bp_xprofile_groups` DISABLE KEYS */;
INSERT INTO `wp_bp_xprofile_groups` VALUES('1', 'Perfil', '', '0', '0');
INSERT INTO `wp_bp_xprofile_groups` VALUES('2', 'Lugar', '', '1', '0');
INSERT INTO `wp_bp_xprofile_groups` VALUES('3', 'Federaciónes y Clubes', '', '1', '0');
/*!40000 ALTER TABLE `wp_bp_xprofile_groups` ENABLE KEYS */;
