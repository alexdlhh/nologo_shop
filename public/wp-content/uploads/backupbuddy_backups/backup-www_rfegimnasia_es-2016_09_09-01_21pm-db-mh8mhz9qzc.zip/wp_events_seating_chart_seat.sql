CREATE TABLE `wp_events_seating_chart_seat` (  `id` int(11) NOT NULL AUTO_INCREMENT,  `seating_chart_id` int(11) DEFAULT NULL,  `level` varchar(255) DEFAULT NULL,  `section` varchar(255) DEFAULT NULL,  `row` varchar(255) DEFAULT NULL,  `seat` varchar(255) DEFAULT NULL,  `price` float DEFAULT NULL,  `member_price` float DEFAULT NULL,  `custom_tag` text,  `description` text,  PRIMARY KEY (`id`)) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `wp_events_seating_chart_seat` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_events_seating_chart_seat` ENABLE KEYS */;
