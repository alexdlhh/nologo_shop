CREATE TABLE `wp_events_seating_chart` (  `id` int(11) NOT NULL AUTO_INCREMENT,  `name` varchar(255) DEFAULT NULL,  `description` text,  `image_name` varchar(255) DEFAULT NULL,  PRIMARY KEY (`id`)) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `wp_events_seating_chart` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_events_seating_chart` ENABLE KEYS */;
