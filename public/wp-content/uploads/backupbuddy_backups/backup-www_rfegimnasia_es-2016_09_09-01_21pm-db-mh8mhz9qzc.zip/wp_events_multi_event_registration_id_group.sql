CREATE TABLE `wp_events_multi_event_registration_id_group` (  `primary_registration_id` varchar(255) DEFAULT NULL,  `registration_id` varchar(255) DEFAULT NULL) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `wp_events_multi_event_registration_id_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_events_multi_event_registration_id_group` ENABLE KEYS */;
