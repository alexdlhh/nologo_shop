CREATE TABLE `wp_events_locale` (  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,  `name` varchar(250) DEFAULT NULL,  `identifier` varchar(26) DEFAULT '0',  `wp_user` int(22) DEFAULT '1',  UNIQUE KEY `id` (`id`),  KEY `identifier` (`identifier`),  KEY `wp_user` (`wp_user`)) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `wp_events_locale` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_events_locale` ENABLE KEYS */;
