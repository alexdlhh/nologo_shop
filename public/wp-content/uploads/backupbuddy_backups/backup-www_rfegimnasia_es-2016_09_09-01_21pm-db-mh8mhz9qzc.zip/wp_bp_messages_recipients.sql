CREATE TABLE `wp_bp_messages_recipients` (  `id` bigint(20) NOT NULL AUTO_INCREMENT,  `user_id` bigint(20) NOT NULL,  `thread_id` bigint(20) NOT NULL,  `unread_count` int(10) NOT NULL DEFAULT '0',  `sender_only` tinyint(1) NOT NULL DEFAULT '0',  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',  PRIMARY KEY (`id`),  KEY `user_id` (`user_id`),  KEY `thread_id` (`thread_id`),  KEY `is_deleted` (`is_deleted`),  KEY `sender_only` (`sender_only`),  KEY `unread_count` (`unread_count`)) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `wp_bp_messages_recipients` DISABLE KEYS */;
INSERT INTO `wp_bp_messages_recipients` VALUES('1', '1', '1', '0', '0', '0');
INSERT INTO `wp_bp_messages_recipients` VALUES('2', '3', '1', '0', '1', '0');
INSERT INTO `wp_bp_messages_recipients` VALUES('3', '3', '2', '1', '0', '0');
INSERT INTO `wp_bp_messages_recipients` VALUES('4', '1', '2', '0', '1', '0');
/*!40000 ALTER TABLE `wp_bp_messages_recipients` ENABLE KEYS */;
