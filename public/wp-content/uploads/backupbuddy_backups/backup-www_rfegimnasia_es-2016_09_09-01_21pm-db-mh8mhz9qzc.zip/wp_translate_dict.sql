CREATE TABLE `wp_translate_dict` (  `term` varchar(25) COLLATE latin1_general_ci NOT NULL,  `lang_id` int(11) NOT NULL,  `translation` text COLLATE latin1_general_ci NOT NULL,  PRIMARY KEY (`term`,`lang_id`),  KEY `lang_id` (`lang_id`)) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40000 ALTER TABLE `wp_translate_dict` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_translate_dict` ENABLE KEYS */;
