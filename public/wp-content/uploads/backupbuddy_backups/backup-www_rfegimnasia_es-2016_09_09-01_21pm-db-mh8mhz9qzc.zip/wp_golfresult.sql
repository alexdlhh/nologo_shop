CREATE TABLE `wp_golfresult` (  `result_aid` mediumint(10) NOT NULL AUTO_INCREMENT,  `table_id` mediumint(10) NOT NULL DEFAULT '0',  `row_id` mediumint(10) NOT NULL DEFAULT '1',  `value` mediumtext COLLATE latin1_general_ci NOT NULL,  PRIMARY KEY (`result_aid`),  UNIQUE KEY `id` (`result_aid`)) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40000 ALTER TABLE `wp_golfresult` DISABLE KEYS */;
INSERT INTO `wp_golfresult` VALUES('1', '1', '0', '100');
INSERT INTO `wp_golfresult` VALUES('2', '1', '0', '100');
INSERT INTO `wp_golfresult` VALUES('3', '1', '0', '100');
INSERT INTO `wp_golfresult` VALUES('4', '1', '1', 'Column 1');
INSERT INTO `wp_golfresult` VALUES('5', '1', '1', 'Column 2');
INSERT INTO `wp_golfresult` VALUES('6', '1', '1', 'Column 3');
/*!40000 ALTER TABLE `wp_golfresult` ENABLE KEYS */;
