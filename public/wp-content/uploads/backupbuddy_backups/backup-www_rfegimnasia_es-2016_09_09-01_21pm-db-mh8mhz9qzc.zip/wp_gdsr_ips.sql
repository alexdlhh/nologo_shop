CREATE TABLE `wp_gdsr_ips` (  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,  `status` varchar(1) DEFAULT 'B',  `mode` varchar(1) DEFAULT 'S',  `ip` varchar(128) DEFAULT NULL,  PRIMARY KEY (`id`)) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `wp_gdsr_ips` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_gdsr_ips` ENABLE KEYS */;
