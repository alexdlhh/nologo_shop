CREATE TABLE `wp_wfu_userdata` (  `iduserdata` mediumint(9) NOT NULL AUTO_INCREMENT,  `uploadid` varchar(20) NOT NULL,  `property` varchar(100) NOT NULL,  `propkey` mediumint(9) NOT NULL,  `propvalue` text,  `date_from` datetime DEFAULT NULL,  `date_to` datetime DEFAULT NULL,  PRIMARY KEY (`iduserdata`)) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `wp_wfu_userdata` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_wfu_userdata` ENABLE KEYS */;
