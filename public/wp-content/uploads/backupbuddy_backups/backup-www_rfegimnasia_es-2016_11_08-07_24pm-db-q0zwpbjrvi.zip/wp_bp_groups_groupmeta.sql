CREATE TABLE `wp_bp_groups_groupmeta` (  `id` bigint(20) NOT NULL AUTO_INCREMENT,  `group_id` bigint(20) NOT NULL,  `meta_key` varchar(255) DEFAULT NULL,  `meta_value` longtext,  PRIMARY KEY (`id`),  KEY `group_id` (`group_id`),  KEY `meta_key` (`meta_key`)) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `wp_bp_groups_groupmeta` DISABLE KEYS */;
INSERT INTO `wp_bp_groups_groupmeta` VALUES('3', '2', 'last_activity', '2011-08-22 18:55:22');
INSERT INTO `wp_bp_groups_groupmeta` VALUES('4', '2', 'total_member_count', '1');
/*!40000 ALTER TABLE `wp_bp_groups_groupmeta` ENABLE KEYS */;
