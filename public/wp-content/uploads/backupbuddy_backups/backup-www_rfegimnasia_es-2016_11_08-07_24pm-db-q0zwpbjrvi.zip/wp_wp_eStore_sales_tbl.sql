CREATE TABLE `wp_wp_eStore_sales_tbl` (  `cust_email` varchar(128) COLLATE latin1_general_ci NOT NULL DEFAULT '',  `date` date NOT NULL DEFAULT '0000-00-00',  `time` time NOT NULL DEFAULT '00:00:00',  `item_id` varchar(10) COLLATE latin1_general_ci NOT NULL DEFAULT '',  `sale_price` varchar(10) COLLATE latin1_general_ci NOT NULL DEFAULT '') ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40000 ALTER TABLE `wp_wp_eStore_sales_tbl` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_wp_eStore_sales_tbl` ENABLE KEYS */;
