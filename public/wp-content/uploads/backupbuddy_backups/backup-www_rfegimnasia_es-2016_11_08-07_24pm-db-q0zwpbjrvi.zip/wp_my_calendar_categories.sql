CREATE TABLE `wp_my_calendar_categories` (  `category_id` int(11) NOT NULL AUTO_INCREMENT,  `category_name` varchar(255) NOT NULL,  `category_color` varchar(7) NOT NULL,  `category_icon` varchar(128) NOT NULL,  PRIMARY KEY (`category_id`)) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `wp_my_calendar_categories` DISABLE KEYS */;
INSERT INTO `wp_my_calendar_categories` VALUES('1', 'General', '#ffffff', 'event.png');
/*!40000 ALTER TABLE `wp_my_calendar_categories` ENABLE KEYS */;
