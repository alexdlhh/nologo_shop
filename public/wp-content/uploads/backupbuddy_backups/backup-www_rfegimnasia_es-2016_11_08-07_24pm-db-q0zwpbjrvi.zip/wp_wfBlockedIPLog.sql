CREATE TABLE `wp_wfBlockedIPLog` (  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',  `countryCode` varchar(2) NOT NULL,  `blockCount` int(10) unsigned NOT NULL DEFAULT '0',  `unixday` int(10) unsigned NOT NULL,  PRIMARY KEY (`IP`,`unixday`)) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `wp_wfBlockedIPLog` DISABLE KEYS */;
INSERT INTO `wp_wfBlockedIPLog` VALUES('\0\0\0\0\0\0\0\0\0\0��-7�\"', 'US', '1', '17106');
INSERT INTO `wp_wfBlockedIPLog` VALUES('\0\0\0\0\0\0\0\0\0\0���\nc�', 'CH', '1', '17106');
INSERT INTO `wp_wfBlockedIPLog` VALUES('\0\0\0\0\0\0\0\0\0\0��[�Q', 'UA', '1', '17106');
INSERT INTO `wp_wfBlockedIPLog` VALUES('\0\0\0\0\0\0\0\0\0\0�����g', 'NL', '1', '17109');
INSERT INTO `wp_wfBlockedIPLog` VALUES('\0\0\0\0\0\0\0\0\0\0��Y\"�y', 'RO', '1', '17111');
INSERT INTO `wp_wfBlockedIPLog` VALUES('\0\0\0\0\0\0\0\0\0\0����3[', 'FR', '1', '17111');
INSERT INTO `wp_wfBlockedIPLog` VALUES('\0\0\0\0\0\0\0\0\0\0�����', 'US', '1', '17111');
INSERT INTO `wp_wfBlockedIPLog` VALUES('\0\0\0\0\0\0\0\0\0\0��]s_�', 'RO', '1', '17111');
INSERT INTO `wp_wfBlockedIPLog` VALUES('\0\0\0\0\0\0\0\0\0\0��Ú��', 'FR', '1', '17107');
INSERT INTO `wp_wfBlockedIPLog` VALUES('\0\0\0\0\0\0\0\0\0\0����s6', 'UA', '1', '17107');
INSERT INTO `wp_wfBlockedIPLog` VALUES('\0\0\0\0\0\0\0\0\0\0���\nk�', 'CH', '1', '17109');
INSERT INTO `wp_wfBlockedIPLog` VALUES('\0\0\0\0\0\0\0\0\0\0��U��', 'SK', '1', '17110');
INSERT INTO `wp_wfBlockedIPLog` VALUES('\0\0\0\0\0\0\0\0\0\0���&�', 'NL', '1', '17109');
INSERT INTO `wp_wfBlockedIPLog` VALUES('\0\0\0\0\0\0\0\0\0\0��[���', 'HU', '1', '17109');
INSERT INTO `wp_wfBlockedIPLog` VALUES('\0\0\0\0\0\0\0\0\0\0��[�/', 'UA', '1', '17112');
INSERT INTO `wp_wfBlockedIPLog` VALUES('\0\0\0\0\0\0\0\0\0\0��M���', 'NL', '1', '17108');
INSERT INTO `wp_wfBlockedIPLog` VALUES('\0\0\0\0\0\0\0\0\0\0��mVs�', 'UA', '1', '17113');
INSERT INTO `wp_wfBlockedIPLog` VALUES('\0\0\0\0\0\0\0\0\0\0���\nk�', 'CH', '1', '17106');
INSERT INTO `wp_wfBlockedIPLog` VALUES('\0\0\0\0\0\0\0\0\0\0��E��	', 'US', '1', '17106');
INSERT INTO `wp_wfBlockedIPLog` VALUES('\0\0\0\0\0\0\0\0\0\0��]s_�', 'RO', '1', '17106');
/*!40000 ALTER TABLE `wp_wfBlockedIPLog` ENABLE KEYS */;
