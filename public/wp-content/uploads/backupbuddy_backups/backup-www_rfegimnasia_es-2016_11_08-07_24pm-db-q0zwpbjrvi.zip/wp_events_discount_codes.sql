CREATE TABLE `wp_events_discount_codes` (  `id` int(11) NOT NULL AUTO_INCREMENT,  `coupon_code` varchar(50) DEFAULT NULL,  `coupon_code_price` decimal(20,2) DEFAULT NULL,  `use_percentage` varchar(1) DEFAULT NULL,  `coupon_code_description` text,  `each_attendee` varchar(1) DEFAULT NULL,  `wp_user` int(22) DEFAULT '1',  PRIMARY KEY (`id`),  KEY `coupon_code` (`coupon_code`),  KEY `wp_user` (`wp_user`)) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40000 ALTER TABLE `wp_events_discount_codes` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_events_discount_codes` ENABLE KEYS */;
