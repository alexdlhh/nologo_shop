CREATE TABLE `wp_wdpv_post_votes` (  `id` int(10) NOT NULL AUTO_INCREMENT,  `blog_id` int(10) NOT NULL,  `site_id` int(10) NOT NULL,  `post_id` int(10) NOT NULL,  `user_id` int(10) NOT NULL,  `user_ip` int(10) NOT NULL,  `vote` int(1) NOT NULL,  UNIQUE KEY `id` (`id`)) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40000 ALTER TABLE `wp_wdpv_post_votes` DISABLE KEYS */;
INSERT INTO `wp_wdpv_post_votes` VALUES('1', '0', '0', '102', '1', '1595015492', '1');
INSERT INTO `wp_wdpv_post_votes` VALUES('2', '0', '0', '416', '1', '1595015492', '1');
INSERT INTO `wp_wdpv_post_votes` VALUES('3', '0', '0', '115', '1', '1595015492', '1');
/*!40000 ALTER TABLE `wp_wdpv_post_votes` ENABLE KEYS */;
