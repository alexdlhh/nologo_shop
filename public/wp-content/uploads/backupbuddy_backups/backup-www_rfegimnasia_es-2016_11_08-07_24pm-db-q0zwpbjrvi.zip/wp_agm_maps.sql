CREATE TABLE `wp_agm_maps` (  `id` int(10) NOT NULL AUTO_INCREMENT,  `title` varchar(50) COLLATE latin1_general_ci NOT NULL,  `post_ids` text COLLATE latin1_general_ci NOT NULL,  `markers` text COLLATE latin1_general_ci NOT NULL,  `options` text COLLATE latin1_general_ci NOT NULL,  UNIQUE KEY `id` (`id`)) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40000 ALTER TABLE `wp_agm_maps` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_agm_maps` ENABLE KEYS */;
