CREATE TABLE `wp_bp_friends` (  `id` bigint(20) NOT NULL AUTO_INCREMENT,  `initiator_user_id` bigint(20) NOT NULL,  `friend_user_id` bigint(20) NOT NULL,  `is_confirmed` tinyint(1) DEFAULT '0',  `is_limited` tinyint(1) DEFAULT '0',  `date_created` datetime NOT NULL,  PRIMARY KEY (`id`),  KEY `initiator_user_id` (`initiator_user_id`),  KEY `friend_user_id` (`friend_user_id`)) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `wp_bp_friends` DISABLE KEYS */;
INSERT INTO `wp_bp_friends` VALUES('1', '1', '3', '0', '0', '2011-06-23 02:22:44');
/*!40000 ALTER TABLE `wp_bp_friends` ENABLE KEYS */;
