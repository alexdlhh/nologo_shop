CREATE TABLE `wp_osefw_logs` (  `id` int(11) NOT NULL AUTO_INCREMENT,  `date` datetime DEFAULT NULL,  `comp` varchar(3) NOT NULL,  `status` text NOT NULL,  PRIMARY KEY (`id`)) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40000 ALTER TABLE `wp_osefw_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_osefw_logs` ENABLE KEYS */;
