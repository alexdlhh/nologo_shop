CREATE TABLE `wp_wp_eStore_pending_payment_tbl` (  `customer_id` varchar(64) NOT NULL,  `item_number` int(12) NOT NULL,  `name` varchar(255) NOT NULL,  `price` varchar(128) NOT NULL,  `quantity` int(12) NOT NULL,  `shipping` varchar(128) NOT NULL,  `custom` varchar(255) NOT NULL) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `wp_wp_eStore_pending_payment_tbl` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_wp_eStore_pending_payment_tbl` ENABLE KEYS */;
