CREATE TABLE `wp_events_venue_rel` (  `id` int(11) NOT NULL AUTO_INCREMENT,  `event_id` int(11) DEFAULT NULL,  `venue_id` int(11) DEFAULT NULL,  PRIMARY KEY (`id`),  KEY `event_id` (`event_id`)) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `wp_events_venue_rel` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_events_venue_rel` ENABLE KEYS */;
