CREATE TABLE `wp_shopp_catalog` (  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,  `product` bigint(20) unsigned NOT NULL DEFAULT '0',  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',  `type` enum('category','tag') NOT NULL,  `priority` int(10) NOT NULL DEFAULT '0',  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',  PRIMARY KEY (`id`),  KEY `product` (`product`),  KEY `assignment` (`parent`,`type`)) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `wp_shopp_catalog` DISABLE KEYS */;
INSERT INTO `wp_shopp_catalog` VALUES('1', '1', '2', 'category', '2', '2011-11-29 15:31:47', '2011-11-29 15:31:47');
INSERT INTO `wp_shopp_catalog` VALUES('2', '2', '1', 'category', '3', '2011-11-29 16:12:55', '2011-11-29 16:12:55');
/*!40000 ALTER TABLE `wp_shopp_catalog` ENABLE KEYS */;
