CREATE TABLE `wp_events_seating_chart_event` (  `event_id` int(11) DEFAULT NULL,  `seating_chart_id` int(11) DEFAULT NULL) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `wp_events_seating_chart_event` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_events_seating_chart_event` ENABLE KEYS */;
