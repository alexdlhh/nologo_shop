CREATE TABLE `wp_additional_attendees` (  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,  `attendee_id` int(11) NOT NULL DEFAULT '0',  `x_attedee_name` varchar(45) DEFAULT NULL,  `x_attendee_email` varchar(45) DEFAULT NULL,  PRIMARY KEY (`id`)) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40000 ALTER TABLE `wp_additional_attendees` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_additional_attendees` ENABLE KEYS */;
