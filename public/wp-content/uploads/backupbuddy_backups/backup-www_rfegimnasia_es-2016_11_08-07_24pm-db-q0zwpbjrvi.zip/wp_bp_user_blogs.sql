CREATE TABLE `wp_bp_user_blogs` (  `id` bigint(20) NOT NULL AUTO_INCREMENT,  `user_id` bigint(20) NOT NULL,  `blog_id` bigint(20) NOT NULL,  PRIMARY KEY (`id`),  KEY `user_id` (`user_id`),  KEY `blog_id` (`blog_id`)) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `wp_bp_user_blogs` DISABLE KEYS */;
INSERT INTO `wp_bp_user_blogs` VALUES('1', '1', '1');
INSERT INTO `wp_bp_user_blogs` VALUES('2', '16', '1');
INSERT INTO `wp_bp_user_blogs` VALUES('3', '15', '1');
INSERT INTO `wp_bp_user_blogs` VALUES('4', '14', '1');
INSERT INTO `wp_bp_user_blogs` VALUES('5', '9', '1');
INSERT INTO `wp_bp_user_blogs` VALUES('6', '11', '1');
/*!40000 ALTER TABLE `wp_bp_user_blogs` ENABLE KEYS */;
