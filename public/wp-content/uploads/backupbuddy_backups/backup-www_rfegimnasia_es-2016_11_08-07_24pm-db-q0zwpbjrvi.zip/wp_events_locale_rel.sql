CREATE TABLE `wp_events_locale_rel` (  `id` int(11) NOT NULL AUTO_INCREMENT,  `venue_id` int(11) DEFAULT NULL,  `locale_id` int(11) DEFAULT NULL,  PRIMARY KEY (`id`),  KEY `venue_id` (`venue_id`)) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `wp_events_locale_rel` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_events_locale_rel` ENABLE KEYS */;
