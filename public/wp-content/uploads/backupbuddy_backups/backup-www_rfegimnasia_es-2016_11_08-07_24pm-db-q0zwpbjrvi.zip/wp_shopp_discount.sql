CREATE TABLE `wp_shopp_discount` (  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,  `promo` bigint(20) unsigned NOT NULL DEFAULT '0',  `product` bigint(20) unsigned NOT NULL DEFAULT '0',  `price` bigint(20) unsigned NOT NULL DEFAULT '0',  PRIMARY KEY (`id`),  KEY `lookup` (`product`,`price`)) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `wp_shopp_discount` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_shopp_discount` ENABLE KEYS */;
