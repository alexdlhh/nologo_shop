CREATE TABLE `wp_group_map` (  `group_map_id` int(11) NOT NULL AUTO_INCREMENT,  `group_map_title` varchar(255) DEFAULT NULL,  `group_marker` text,  `group_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,  PRIMARY KEY (`group_map_id`)) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `wp_group_map` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_group_map` ENABLE KEYS */;
