CREATE TABLE `wp_golftable` (  `table_aid` mediumint(10) NOT NULL AUTO_INCREMENT,  `table_name` varchar(200) COLLATE latin1_general_ci NOT NULL DEFAULT 'Table name',  `description` mediumtext COLLATE latin1_general_ci NOT NULL,  `alternative` tinyint(1) NOT NULL DEFAULT '1',  `show_name` tinyint(1) NOT NULL DEFAULT '1',  `show_desc` tinyint(1) NOT NULL DEFAULT '0',  `head_bold` tinyint(1) NOT NULL DEFAULT '1',  PRIMARY KEY (`table_aid`),  UNIQUE KEY `id` (`table_aid`)) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40000 ALTER TABLE `wp_golftable` DISABLE KEYS */;
INSERT INTO `wp_golftable` VALUES('1', 'Table name 1', 'This is your first demo table', '1', '1', '0', '1');
/*!40000 ALTER TABLE `wp_golftable` ENABLE KEYS */;
