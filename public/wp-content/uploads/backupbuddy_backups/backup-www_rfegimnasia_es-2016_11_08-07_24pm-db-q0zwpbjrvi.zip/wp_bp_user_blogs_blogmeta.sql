CREATE TABLE `wp_bp_user_blogs_blogmeta` (  `id` bigint(20) NOT NULL AUTO_INCREMENT,  `blog_id` bigint(20) NOT NULL,  `meta_key` varchar(255) DEFAULT NULL,  `meta_value` longtext,  PRIMARY KEY (`id`),  KEY `blog_id` (`blog_id`),  KEY `meta_key` (`meta_key`)) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `wp_bp_user_blogs_blogmeta` DISABLE KEYS */;
INSERT INTO `wp_bp_user_blogs_blogmeta` VALUES('1', '1', 'name', 'Real Federación Española de Gimnasia');
INSERT INTO `wp_bp_user_blogs_blogmeta` VALUES('2', '1', 'last_activity', '2012-07-22 16:31:38');
/*!40000 ALTER TABLE `wp_bp_user_blogs_blogmeta` ENABLE KEYS */;
