CREATE TABLE `wp_events_attendee_meta` (  `ameta_id` bigint(20) NOT NULL AUTO_INCREMENT,  `attendee_id` int(11) DEFAULT NULL,  `meta_key` varchar(255) DEFAULT NULL,  `meta_value` longtext,  `date_added` datetime DEFAULT NULL,  PRIMARY KEY (`ameta_id`),  KEY `attendee_id` (`attendee_id`)) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `wp_events_attendee_meta` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_events_attendee_meta` ENABLE KEYS */;
