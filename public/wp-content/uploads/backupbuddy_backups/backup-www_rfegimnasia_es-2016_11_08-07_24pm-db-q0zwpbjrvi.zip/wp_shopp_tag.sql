CREATE TABLE `wp_shopp_tag` (  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,  `name` varchar(255) NOT NULL DEFAULT '',  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',  PRIMARY KEY (`id`)) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `wp_shopp_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_shopp_tag` ENABLE KEYS */;
