CREATE TABLE `wp_events_email` (  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,  `email_name` varchar(100) DEFAULT NULL,  `email_subject` varchar(250) DEFAULT NULL,  `email_text` text,  `wp_user` int(22) DEFAULT '1',  UNIQUE KEY `id` (`id`),  KEY `wp_user` (`wp_user`)) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `wp_events_email` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_events_email` ENABLE KEYS */;
