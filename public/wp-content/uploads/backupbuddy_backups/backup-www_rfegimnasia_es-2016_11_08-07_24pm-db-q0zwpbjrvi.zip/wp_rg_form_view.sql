CREATE TABLE `wp_rg_form_view` (  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,  `form_id` mediumint(8) unsigned NOT NULL,  `date_created` datetime NOT NULL,  `ip` char(15) DEFAULT NULL,  `count` mediumint(8) unsigned NOT NULL DEFAULT '1',  PRIMARY KEY (`id`),  KEY `date_created` (`date_created`),  KEY `form_id` (`form_id`)) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `wp_rg_form_view` DISABLE KEYS */;
INSERT INTO `wp_rg_form_view` VALUES('1', '1', '2016-07-06 17:33:31', '87.216.73.186', '11');
INSERT INTO `wp_rg_form_view` VALUES('2', '1', '2016-07-13 21:01:24', '87.216.73.186', '1');
/*!40000 ALTER TABLE `wp_rg_form_view` ENABLE KEYS */;
