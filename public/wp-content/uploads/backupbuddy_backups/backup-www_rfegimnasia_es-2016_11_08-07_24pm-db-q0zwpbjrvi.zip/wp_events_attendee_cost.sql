CREATE TABLE `wp_events_attendee_cost` (  `attendee_id` int(11) DEFAULT NULL,  `cost` decimal(20,2) DEFAULT '0.00',  `quantity` int(11) DEFAULT NULL,  KEY `attendee_id` (`attendee_id`)) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `wp_events_attendee_cost` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_events_attendee_cost` ENABLE KEYS */;
