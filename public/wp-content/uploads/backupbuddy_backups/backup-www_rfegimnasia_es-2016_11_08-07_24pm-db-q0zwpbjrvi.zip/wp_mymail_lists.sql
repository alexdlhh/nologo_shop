CREATE TABLE `wp_mymail_lists` (  `ID` bigint(20) NOT NULL AUTO_INCREMENT,  `parent_id` bigint(20) unsigned NOT NULL,  `name` varchar(191) NOT NULL,  `slug` varchar(191) NOT NULL,  `description` longtext NOT NULL,  `added` int(11) unsigned NOT NULL,  `updated` int(11) unsigned NOT NULL,  PRIMARY KEY (`ID`),  UNIQUE KEY `name` (`name`),  UNIQUE KEY `slug` (`slug`)) ENGINE=MyISAM AUTO_INCREMENT=94 DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `wp_mymail_lists` DISABLE KEYS */;
INSERT INTO `wp_mymail_lists` VALUES('92', '0', 'CLUBES', 'clubes', '', '1455704920', '1455704920');
INSERT INTO `wp_mymail_lists` VALUES('93', '0', 'FEDERACIONES AUTONÓMICAS', 'federaciones-autonomicas', '', '1455877723', '1455877723');
/*!40000 ALTER TABLE `wp_mymail_lists` ENABLE KEYS */;
