CREATE TABLE `wp_events_personnel_rel` (  `id` int(11) NOT NULL AUTO_INCREMENT,  `event_id` int(11) DEFAULT NULL,  `person_id` int(11) DEFAULT NULL,  PRIMARY KEY (`id`),  KEY `event_id` (`event_id`),  KEY `person_id` (`person_id`)) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `wp_events_personnel_rel` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_events_personnel_rel` ENABLE KEYS */;
