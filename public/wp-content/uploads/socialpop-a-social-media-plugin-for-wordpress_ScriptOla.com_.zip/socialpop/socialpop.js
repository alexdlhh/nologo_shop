<!--
/*!
 **************************************************
 * Copyright 2010 - Danny Carmical
 * http://luckykind.com
 **************************************************/

(function($){
 	$.fn.extend({ 

 		socialpop: function(options) {

			var defaults = {
				style: 'popup',
				box: 'no',
				boxfloat: 'none', 
				title: 'Share!',
				notitle: 'no',
				holder: 'none',
				bgcolor: 'ffffff'
			}

			var options =  $.extend(defaults, options);
			
    		return this.each(function() {
				var subOverBG = '';
				
				if(options.holder=='none'){
					subOverBG = ' style="background-color:#' + options.bgcolor + '"';
				}
				
				var spList = $(' > li ',this);
				var spImg = $(' > li img',this);
				
				var sp_box_float = "";
				if(options.boxfloat!='none') {
					sp_box_float = " socialpop-pos-" + options.boxfloat;
				} else {
					$(this).css('width','99%');
				}
				
				var rand = Math.floor(Math.random()*100000);
				
				if(options.box=='yes') {
						var showPadding;
											
					if(options.style == 'popup'){
						showPadding = 0;
					} else if(options.style == 'popdown'){
						showPadding = 5;					
					} else {
						showPadding = 0;					
					}					
					
					$(this).wrap('<div class="socialpop-box spID'+ rand + sp_box_float + '" />');
					var spBox = $('.spID' + rand);
					var fullHeight = spBox.height();									
					var newHeight;	
					if(options.notitle=='no'){
						spBox.prepend('<h5>' + options.title + '</h5>');
						newHeight = 22 + spBox.children('h5').height();
						fullHeight = fullHeight + spBox.children('h5').height();
						spBox.height(newHeight);
					} else {
						newHeight = 16;
						spBox.height('16px');
					}

					var scrollTo = $('body').innerHeight();

					$.each(spBox,function(){
						var box_pos = $(this).offset();
						$(this).hover(
							function (){
								// Check to see if the box is at the bottom of the window and if so, scroll the window.
								if(scrollTo < box_pos.top + fullHeight) {
									var scrollToAfter = $('body').innerHeight();
									$('html, body').animate({scrollTop: scrollToAfter}, 200);									
								}
								$(this).stop().animate({
									height: fullHeight,
									paddingBottom: showPadding
								},200);
							},
							function (){
								$(this).stop().animate({
									height:newHeight,
									paddingBottom: 22
								},200);
							}
						);											
					});
				} else {
					$(this).wrap('<div class="socialpop-box-none spID' + rand + sp_box_float + '" />');					
					var spBoxNone = $('.spID' + rand);
										
					if(options.notitle=='no'){
						spBoxNone.prepend('<h5>' + options.title + '</h5>');
					}
				}
				
				switch(options.style) {
					case 'popup':
						$.each(spList, function(){
							$(this).append('<div class="popup-overlay popup-holder-' + options.holder + '"><div class="sub-popup-overlay"' + subOverBG + '></div></div>');
						});

						$.each(spImg, function(){
							$(this).hover(
								function(){
									$(this).stop().animate({
										top:-6
									}, 200);
								},
								function(){
									$(this).stop().animate({
										top:0
									}, 200);
								}
							);	
							
							$(this).click(function(){
									$(this).stop().animate({
										top:0
									}, 200);
								}
							);	
						});
					break;

					case 'popdown':
						$.each(spList, function(){
							$(this).append('<div class="popdown-overlay popdown-holder-' + options.holder + '"><div class="sub-popdown-overlay"' + subOverBG + '></div></div>');
						});

						$.each(spImg, function(){
							$(this).hover(
								function(){
									$(this).stop().animate({
										top:6
									}, 200);
								},
								function(){
									$(this).stop().animate({
										top:0
									}, 200);
								}
							);	
							
							$(this).click(function(){
									$(this).stop().animate({
										top:0
									}, 200);
								}
							);	
						});
					break;

					case 'popleft':
						$.each(spList, function(){
							$(this).append('<div class="popleft-overlay popleft-holder-' + options.holder + '"><div class="sub-popleft-overlay"' + subOverBG + '></div></div>');
						});

						$.each(spImg, function(){
							$(this).hover(
								function(){
									$(this).stop().animate({
										left:-7
									}, 200);
								},
								function(){
									$(this).stop().animate({
										left:0
									}, 200);
								}
							);	

							$(this).click(function(){
									$(this).stop().animate({
										left:0
									}, 200);
								}
							);	
						});
					break;

					case 'popright':
						$.each(spList, function(){
							$(this).append('<div class="popright-overlay popright-holder-' + options.holder + '"><div class="sub-popright-overlay"' + subOverBG + '></div></div>');
						});

						$.each(spImg, function(){
							$(this).hover(
								function(){
									$(this).stop().animate({
										left:7
									}, 200);
								},
								function(){
									$(this).stop().animate({
										left:0
									}, 200);
								}
							);	

							$(this).click(function(){
									$(this).stop().animate({
										left:0
									}, 200);
								}
							);	
						});
					break;
				}
  		});
    	}
	});

})(jQuery);

-->	