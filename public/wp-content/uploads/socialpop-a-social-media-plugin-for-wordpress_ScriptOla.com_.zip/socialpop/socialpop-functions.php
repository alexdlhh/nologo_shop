<?php

function current_url() {
	$pageURL = 'http';
	if ($_SERVER["HTTPS"] == "on") {$pageURL .= "s";}
		$pageURL .= "://";
	if ($_SERVER["SERVER_PORT"] != "80") {
	 	$pageURL .= $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];
	} else {
	 	$pageURL .= $_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
	}
	return $pageURL;
}

function sps_get_bitly_link($long_url,$username,$user_api_key,$id=0,$social){		
	/* Grab bitly link */
	$url_enc = urlencode($long_url);
	$version = 'v3';
	$login = $username;
	$api_key = $user_api_key;
	$format = 'json';
	$data = @file_get_contents('http://api.bit.ly/'.$version.'/shorten?longUrl='.$url_enc.'&login='.$login.'&apiKey='.$api_key.'&amp;format='.$format);
	if(!$data) {
		return $long_url;
	}
	
	$json = json_decode($data, true);
	$bitly_url = $json['data']['url'];

	if(empty($bitly_url)) {
		return $long_url;
	}
	
	if(!empty($id) && $id!=0) {
		update_post_meta($id,$social,$bitly_url);		
	}
	return $bitly_url;
}

function sps_get_shortlink($long_url,$username,$user_api_key,$id,$social){
	
	if(empty($username) || empty($user_api_key)) {
		return $long_url;
	}
	
	$social = $social . "_bitly_link";

	$has_link = get_post_meta($id,$social,true);
	if(!empty($has_link)) {
		return $has_link;
	} else {
		add_post_meta($id,$social,'',true);
		$has_link = sps_get_bitly_link($long_url,$username,$user_api_key,$id,$social);
		return $has_link;
	}
}

function get_socialpop($socialpops,$title="",$url="",$target=true){
	global $socialpop_path;
	global $sps_the_ID;
	$post_id = $sps_the_ID;
	$orgTitle = $title;
	
	if(empty($url)){
		$url = current_url();
		$url = urlencode($url);
	} else {
		$url = urlencode($url);			
	}
	
	foreach($socialpops as $sps_key => $sps_value) {
		$sps_value['file'] = strtolower($sps_value['file']);
		if($sps_value['file']=='email' || $sps_value['file']=='e-mail' ){
			$target = false;			
			$title = $orgTitle;
		} else {
			$title = urlencode($orgTitle);
		}

		if($target){
			$target = " onclick=\"window.open(this.href);return false;\"";
		} else {
			$target = "";
		}			

		$bitly_username = get_option('sps_opt_bitly_username','');
		$bitly_api_key = get_option('sps_opt_bitly_api_key','');		
				
		switch($sps_value['file']){
			case 'bebo':
				$the_url = sps_get_shortlink("http://www.bebo.com/c/share?Url=$url&amp;Title=$title",$bitly_username,$bitly_api_key,$post_id,'bebo'); 					
				$list .= "<li><a href=\"$the_url\"$target><img src=\"$socialpop_path/images/icons/24px_altered/bebo.png\" width=\"32\" height=\"32\" alt=\"Bebo\" title=\"Bebo\" /></a></li>\n";
				break;

			case 'delicious':
				$the_url = sps_get_shortlink("http://delicious.com/save?url=$url&amp;title=$title",$bitly_username,$bitly_api_key,$post_id,'delicious'); 					
				$list .= "<li><a href=\"$the_url\"$target><img src=\"$socialpop_path/images/icons/24px_altered/delicious.png\" width=\"32\" height=\"32\" alt=\"Delicious\" title=\"Delicious\" /></a></li>\n";
				break;

			case 'digg':
				$the_url = sps_get_shortlink("http://digg.com/submit?url=$url&amp;title=$title",$bitly_username,$bitly_api_key,$post_id,'digg'); 					
				$list .= "<li><a href=\"$the_url\"$target><img src=\"$socialpop_path/images/icons/24px_altered/digg.png\" width=\"32\" height=\"32\" alt=\"Digg\" title=\"Digg\" /></a></li>\n";
				break;

			case 'diigo':
				$the_url = sps_get_shortlink("http://www.diigo.com/post?url=$url&amp;title=$title",$bitly_username,$bitly_api_key,$post_id,'diigo'); 					
				$list .= "<li><a href=\"$the_url\"$target><img src=\"$socialpop_path/images/icons/24px_altered/diigo.png\" width=\"32\" height=\"32\" alt=\"Diigo\" title=\"Diigo\" /></a></li>\n";
				break;

			case 'email':
			case 'e-mail':
				$list .= "<li><a href=\"mailto:?subject=$title&amp;body=$url\"><img src=\"$socialpop_path/images/icons/24px_altered/email.png\" width=\"32\" height=\"32\" alt=\"E-Mail\" title=\"E-Mail\" /></a></li>\n";
				break;

			case 'facebook':
				$the_url = sps_get_shortlink("http://www.facebook.com/sharer.php?u=$url&amp;t=$title",$bitly_username,$bitly_api_key,$post_id,'facebook'); 					
				$list .= "<li><a href=\"$the_url\"$target><img src=\"$socialpop_path/images/icons/24px_altered/facebook.png\" width=\"32\" height=\"32\" alt=\"Facebook\" title=\"Facebook\" /></a></li>\n";
				break;

			case 'friendfeed':
				$the_url = sps_get_shortlink("http://friendfeed.com/?url=$url&amp;title=$title",$bitly_username,$bitly_api_key,$post_id,'friendfeed'); 								
				$list .= "<li><a href=\"$the_url\"$target><img src=\"$socialpop_path/images/icons/24px_altered/friendfeed.png\" width=\"32\" height=\"32\" alt=\"FriendFeed\" title=\"FriendFeed\" /></a></li>\n";
				break;

			case 'google':
			case 'google bookmarks':
			$the_url = sps_get_shortlink("http://www.google.com/bookmarks/mark?op=edit&amp;bkmk=$url&amp;title=$title",$bitly_username,$bitly_api_key,$post_id,'google_bookmarks'); 								
			$list .= "<li><a href=\"$the_url\"$target><img src=\"$socialpop_path/images/icons/24px_altered/google.png\" width=\"32\" height=\"32\" alt=\"Google Bookmarks\" title=\"Google Bookmarks\" /></a></li>\n";
			break;

			case 'google reader':
			case 'google-reader':
				$the_url = sps_get_shortlink("http://www.google.com/reader/link?url=$url&amp;title=$title",$bitly_username,$bitly_api_key,$post_id,'google_reader'); 								
				$list .= "<li><a href=\"$the_url\"$target><img src=\"$socialpop_path/images/icons/24px_altered/google-reader.png\" width=\"32\" height=\"32\" alt=\"Google Reader\" title=\"Google Reader\" /></a></li>\n";
				break;

			case 'google buzz':
			case 'google-buzz':
				$the_url = sps_get_shortlink("http://www.google.com/buzz/post?url=$url&amp;message=$title",$bitly_username,$bitly_api_key,$post_id,'google_buzz'); 								
				$list .= "<li><a href=\"$the_url\"$target><img src=\"$socialpop_path/images/icons/24px_altered/google-buzz.png\" width=\"32\" height=\"32\" alt=\"Google Buzz\" title=\"Google Buzz\" /></a></li>\n";
				break;

			case 'identi.ca':
			case 'identica':
			case 'identi':
				$the_url = sps_get_shortlink("http://identi.ca/notice/new?status_textarea=$title $url",$bitly_username,$bitly_api_key,$post_id,'identica'); 								
				$list .= "<li><a href=\"$the_url\"$target><img src=\"$socialpop_path/images/icons/24px_altered/identi.png\" width=\"32\" height=\"32\" alt=\"Identi.ca\" title=\"Identi.ca\" /></a></li>\n";
				break;

			case 'linkedin':
				$the_url = sps_get_shortlink("http://www.linkedin.com/shareArticle?mini=true&amp;url=$url&amp;message=$title",$bitly_username,$bitly_api_key,$post_id,'linkedin'); 								
				$list .= "<li><a href=\"$the_url\"$target><img src=\"$socialpop_path/images/icons/24px_altered/linkedin.png\" width=\"32\" height=\"32\" alt=\"LinkedIn\" title=\"LinkedIn\" /></a></li>\n";
				break;

			case 'mixx':
				$the_url = sps_get_shortlink("http://www.mixx.com/submit?page_url=$url&amp;title=$title",$bitly_username,$bitly_api_key,$post_id,'mixx'); 								
				$list .= "<li><a href=\"$the_url\"$target><img src=\"$socialpop_path/images/icons/24px_altered/mixx.png\" width=\"32\" height=\"32\" alt=\"Mixx\" title=\"Mixx\" /></a></li>\n";
				break;

			case 'myspace':
				$the_url = sps_get_shortlink("http://www.myspace.com/Modules/PostTo/Pages/?u=$url&amp;t=$title",$bitly_username,$bitly_api_key,$post_id,'myspace'); 								
				$list .= "<li><a href=\"$the_url\"$target><img src=\"$socialpop_path/images/icons/24px_altered/myspace.png\" width=\"32\" height=\"32\" alt=\"MySpace\" title=\"MySpace\" /></a></li>\n";
				break;

			case 'netvibes':
				$the_url = sps_get_shortlink("http://www.netvibes.com/share?url=$url&amp;title=$title",$bitly_username,$bitly_api_key,$post_id,'netvibes'); 								
				$list .= "<li><a href=\"$the_url\"$target><img src=\"$socialpop_path/images/icons/24px_altered/netvibes.png\" width=\"32\" height=\"32\" alt=\"Netvibes\" title=\"Netvibes\" /></a></li>\n";
				break;

			case 'newsvine':
				$the_url = sps_get_shortlink("http://www.newsvine.com/_wine/save?u=$url&amp;h=$title",$bitly_username,$bitly_api_key,$post_id,'newsvine'); 								
				$list .= "<li><a href=\"$the_url\"$target><img src=\"$socialpop_path/images/icons/24px_altered/newsvine.png\" width=\"32\" height=\"32\" alt=\"Newsvine\" title=\"Newsvine\" /></a></li>\n";
				break;

			case 'posterous':
				$the_url = sps_get_shortlink("http://posterous.com/share?linkto=$url&amp;title=$title",$bitly_username,$bitly_api_key,$post_id,'posterous'); 								
				$list .= "<li><a href=\"$the_url\"$target><img src=\"$socialpop_path/images/icons/24px_altered/posterous.png\" width=\"32\" height=\"32\" alt=\"Posterous\" title=\"Posterous\" /></a></li>\n";
				break;

			case 'reddit':
				$the_url = sps_get_shortlink("http://reddit.com/submit?url=$url&amp;title=$title",$bitly_username,$bitly_api_key,$post_id,'reddit'); 								
				$list .= "<li><a href=\"$the_url\"$target><img src=\"$socialpop_path/images/icons/24px_altered/reddit.png\" width=\"32\" height=\"32\" alt=\"Reddit\" title=\"Reddit\" /></a></li>\n";
				break;

			case 'slashdot':
				$the_url = sps_get_shortlink("http://slashdot.org/bookmark.pl?url=$url&amp;title=$title",$bitly_username,$bitly_api_key,$post_id,'slashdot'); 								
				$list .= "<li><a href=\"$the_url\"$target><img src=\"$socialpop_path/images/icons/24px_altered/slashdot.png\" width=\"32\" height=\"32\" alt=\"Slashdot\" title=\"Slashdot\" /></a></li>\n";
				break;

			case 'squidoo':
				$the_url = sps_get_shortlink("http://www.squidoo.com/lensmaster/bookmark?$url",$bitly_username,$bitly_api_key,$post_id,'squidoo'); 								
				$list .= "<li><a href=\"$the_url\"$target><img src=\"$socialpop_path/images/icons/24px_altered/squidoo.png\" width=\"32\" height=\"32\" alt=\"Squidoo\" title=\"Squidoo\" /></a></li>\n";
				break;

			case 'stumbleupon':
				$the_url = sps_get_shortlink("http://www.stumbleupon.com/submit?url=$url&amp;title=$title",$bitly_username,$bitly_api_key,$post_id,'stumbleupon'); 								
				$list .= "<li><a href=\"$the_url\"$target><img src=\"$socialpop_path/images/icons/24px_altered/stumbleupon.png\" width=\"32\" height=\"32\" alt=\"StumbleUpon\" title=\"StumbleUpon\" /></a></li>\n";
				break;

			case 'technorati':
				$the_url = sps_get_shortlink("http://www.technorati.com/faves?add=$url",$bitly_username,$bitly_api_key,$post_id,'technorati'); 								
				$list .= "<li><a href=\"$the_url\"$target><img src=\"$socialpop_path/images/icons/24px_altered/technorati.png\" width=\"32\" height=\"32\" alt=\"Technorati\" title=\"Technorati\" /></a></li>\n";
				break;

			case 'tumblr':
				$the_url = sps_get_shortlink("http://www.tumblr.com/share?v=3&amp;u=$url&amp;t=$title",$bitly_username,$bitly_api_key,$post_id,'tumblr'); 								
				$list .= "<li><a href=\"$the_url\"$target><img src=\"$socialpop_path/images/icons/24px_altered/tumblr.png\" width=\"32\" height=\"32\" alt=\"Tumblr\" title=\"Tumblr\" /></a></li>\n";
				break;

			case 'twitter':
				$the_url = sps_get_shortlink("http://twitter.com/home?status=$title $url",$bitly_username,$bitly_api_key,$post_id,'twitter'); 								
				$list .= "<li><a href=\"$the_url\"$target><img src=\"$socialpop_path/images/icons/24px_altered/twitter.png\" width=\"32\" height=\"32\" alt=\"Twitter\" title=\"Twitter\" /></a></li>\n";
				break;

			case 'windows live':
			case 'live':
			case 'microsoft':
			case 'windows':
				$the_url = sps_get_shortlink("https://favorites.live.com/quickadd.aspx?url=$url&amp;title=$title",$bitly_username,$bitly_api_key,$post_id,'windows_live'); 								
				$list .= "<li><a href=\"$the_url\"$target><img src=\"$socialpop_path/images/icons/24px_altered/microsoft.png\" width=\"32\" height=\"32\" alt=\"Windows Live\" title=\"Windows Live\" /></a></li>\n";
				break;

			case 'yahoo':
			case 'yahoo!':
			case 'yahoo! bookmarks':
			case 'yahoo bookmarks':
				$the_url = sps_get_shortlink("http://myweb2.search.yahoo.com/myresults/bookmarklet?u=$url&amp;t=$title",$bitly_username,$bitly_api_key,$post_id,'yahoo_bookmarks'); 								
				$list .= "<li><a href=\"$the_url\"$target><img src=\"$socialpop_path/images/icons/24px_altered/yahoo.png\" width=\"32\" height=\"32\" alt=\"Yahoo! Bookmarks\" title=\"Yahoo! Bookmarks\" /></a></li>\n";
				break;

			case 'yahoo buzz':
			case 'yahoo-buzz':
				$the_url = sps_get_shortlink("http://buzz.yahoo.com/buzz?targetUrl=$url&amp;headline=$title",$bitly_username,$bitly_api_key,$post_id,'yahoo_buzz'); 								
				$list .= "<li><a href=\"$the_url\"$target><img src=\"$socialpop_path/images/icons/24px_altered/yahoo-buzz.png\" width=\"32\" height=\"32\" alt=\"Yahoo Buzz\" title=\"Yahoo Buzz\" /></a></li>\n";
				break;

		} /* END SWITCH */		
	} /* END FOREACH */
	
	return $list;
}


?>