<?php
/*
Plugin Name: SocialPop
Plugin URI: http://socialpop.lostbeans.com/
Description: A Social Media Plugin for Wordpress
Version: 1.1.2
Author: Danny Carmical
Author URI: http://luckykind.com
Copyright Danny Carmical. All Rights Reserved.
*/
global $socialpop_path;
$socialpop_path = get_settings('home').'/wp-content/plugins/'.dirname(plugin_basename(__FILE__));

global $socialpops;
$socialpops = array( 'sps_id_bebo' => array('file' => 'bebo', 'name' => 'Bebo'),
					 'sps_id_delicious' => array('file' => 'delicious', 'name' => 'Delicious'),
					 'sps_id_digg' => array('file' => 'digg', 'name' => 'Digg'),
					 'sps_id_email' => array('file' => 'email', 'name' => 'E-Mail'),
					 'sps_id_facebook' => array('file' => 'facebook', 'name' => 'Facebook'),
					 'sps_id_friendfeed' => array('file' => 'friendfeed', 'name' => 'FriendFeed'),
					 'sps_id_google' => array('file' => 'google', 'name' => 'Google'),
					 'sps_id_google-buzz' => array('file' => 'google-buzz', 'name' => 'Google Buzz'),
					 'sps_id_google-reader' => array('file' => 'google-reader', 'name' => 'Google Reader'),
					 'sps_id_identi' => array('file' => 'identi', 'name' => 'Identi.ca'),
					 'sps_id_linkedin' => array('file' => 'linkedin', 'name' => 'LinkedIn'),
					 'sps_id_mixx' => array('file' => 'mixx', 'name' => 'Mixx'),
					 'sps_id_myspace' => array('file' => 'myspace', 'name' => 'Myspace'),
					 'sps_id_netvibes' => array('file' => 'netvibes', 'name' => 'Netvibes'),
					 'sps_id_newsvine' => array('file' => 'newsvine', 'name' => 'Newsvine'),
					 'sps_id_posterous' => array('file' => 'posterous', 'name' => 'Posterous'),
					 'sps_id_reddit' => array('file' => 'reddit', 'name' => 'Reddit'),
					 'sps_id_slashdot' => array('file' => 'slashdot', 'name' => 'Slashdot'),
					 'sps_id_squidoo' => array('file' => 'squidoo', 'name' => 'Squidoo'),
					 'sps_id_stumbleupon' => array('file' => 'stumbleupon', 'name' => 'StumbleUpon'),
					 'sps_id_technorati' => array('file' => 'technorati', 'name' => 'Technorati'),
					 'sps_id_tumblr' => array('file' => 'tumblr', 'name' => 'Tumblr'),
					 'sps_id_twitter' => array('file' => 'twitter', 'name' => 'Twitter'),
					 'sps_id_microsoft' => array('file' => 'microsoft', 'name' => 'Windows Live'),
					 'sps_id_yahoo' => array('file' => 'yahoo', 'name' => 'Yahoo'),
					 'sps_id_yahoo-buzz' => array('file' => 'yahoo-buzz', 'name' => 'Yahoo Buzz')
					);

function load_jquery(){
	wp_enqueue_script("jquery");
}

add_action('init', 'load_jquery');

function socialpop_setup() {
		global $socialpops;
		global $socialpop_path;
		include 'socialpop-functions.php';
		
		$sps_options['style'] = get_option('sps_opt_style');
		$sps_options['box'] = get_option('sps_opt_box');
		$sps_options['boxfloat'] = get_option('sps_opt_box_pos');		
		$sps_options['title'] = get_option('sps_opt_title');
		$sps_options['notitle'] = get_option('sps_opt_no_title');
		$sps_options['holder'] = get_option('sps_opt_holder');
		$sps_options['bgcolor'] = get_option('sps_opt_bgcolor');
		
	?>
	<link rel="stylesheet" href="<?php echo $socialpop_path; ?>/socialpop-styles.css" type="text/css" media="screen" title="no title" charset="utf-8" />
	<script type="text/javascript">
	<!--
		<?php
			foreach ($sps_options as $spo_key => $spo_val) {
				echo "var sps_$spo_key = \"$spo_val\";\n";
			}
		?>
	-->
	</script>
	<script src="<?php echo $socialpop_path; ?>/socialpop.js" type="text/javascript" charset="utf-8"></script>
	<script src="<?php echo $socialpop_path; ?>/script.js" type="text/javascript" charset="utf-8"></script>
    <?php	
}

global $same_id;
function socialpop_display($content) {
	global $socialpops;
	global $same_id;

	$options['sps-opt-posts'] = get_option('sps_opt_posts');
	$options['sps-opt-pages'] = get_option('sps_opt_pages');
	
	$options['sps-opt-exclude-posts'] = array_keys(get_option('sps_opt_exclude_posts', array()));
	$options['sps-opt-exclude-pages'] = array_keys(get_option('sps_opt_exclude_pages', array()));
		
	$sp_get = explode(',',get_option('sps_showcase'));
	$sp_showcase = array();
		
	foreach($sp_get as $spg){
		array_push($sp_showcase,$socialpops[$spg]);
	}
	
	global $sps_the_ID;
	$sps_the_ID = get_the_ID();

	$the_title = get_the_title();
	$the_link = get_permalink();
		
	if($same_id!=null) { //If more than one on page... skip it...
		return $content;		
	} else { // Continue loading for first instance
		$same_id = $sps_the_ID;
	}
	
	if (!empty($sp_showcase[0]) && (is_single() && $options['sps-opt-posts'] && !in_array($sps_the_ID,$options['sps-opt-exclude-posts']) && $sps_the_ID!=0) || (is_page() && $options['sps-opt-pages'] && !in_array($sps_the_ID,$options['sps-opt-exclude-pages']) && $sps_the_ID!=0)) {
		$icons = "<div id=\"lk-plugin\"><div class=\"socialpop-container sps-solo\">\n<ul class=\"socialpop-list\">\n" . get_socialpop($sp_showcase, $the_title, $the_link) . "\n</ul>\n</div></div>";
		return $content . $icons;
	} else {
		return $content;
	}
}

function socialpop_settings() {
	global $socialpop_path;
	global $socialpops;
	
	if ($_POST['action'] == 'update') {
		$current = get_option('sps_showcase');
		$pattern = '/^([a-z\_\-\,])+$/';
		if(preg_match($pattern, $_POST['socialpop-showcase']) || $_POST['socialpop-showcase']==''){
			update_option('sps_showcase', $_POST['socialpop-showcase']);
		} else {
			update_option('sps_showcase', $current);						
			$message .= '<div id="message" class="error fade"><p><strong>Error: Unknown Social Media Icons. Please Try Again.</strong></p></div>';
		}
		
		
		$_POST['sps-opt-pages'] == 'on' ? update_option('sps_opt_pages', 'checked="checked"') : update_option('sps_opt_pages', '');
		$_POST['sps-opt-posts'] == 'on' ? update_option('sps_opt_posts', 'checked="checked"') : update_option('sps_opt_posts', '');
		
		//Setup excluded posts
		
		if(!empty($_POST['exposts']) || !empty($_POST['sps-opt-exclude-posts'])) {
			$exclude_posts = $_POST['exposts'] . ' ' . $_POST['sps-opt-exclude-posts'];

			$exclude_posts = preg_replace('/[^0-9]+/',' ',$exclude_posts);
			$exclude_posts = array_unique(explode(' ',$exclude_posts));

			$exclude = array();

			if(!empty($exclude_posts)) {
					$args = array('post_type'=>'post','include'=>$exclude_posts,'post_status' => 'publish,private');
					$the_post = get_posts($args);
					if(!empty($the_post)) {
						foreach($the_post as $post) {
							$exclude[$post->ID] = $post->post_title;							
						}
					}
			}

			update_option('sps_opt_exclude_posts',$exclude);
			
		} else {
			update_option('sps_opt_exclude_posts',array());
			
		}
		
		//Setup excluded pages
		if(!empty($_POST['expages']) || !empty($_POST['sps-opt-exclude-pages'])) {
			$exclude_pages = $_POST['expages'] . ' ' . $_POST['sps-opt-exclude-pages'];			

			$exclude_pages = preg_replace('/[^0-9]+/',' ',$exclude_pages);
			$exclude_pages = array_unique(explode(' ',$exclude_pages));

			$exclude = array();

			if(!empty($exclude_pages)) {
					$args = array('post_type'=>'page','include'=>$exclude_pages,'post_status' => 'publish,private');
					$the_page = get_posts($args);
										
					if(!empty($the_page)) {
						foreach($the_page as $page) {
							$exclude[$page->ID] = $page->post_title;							
						}
					}
			}
			
			update_option('sps_opt_exclude_pages',$exclude);
			
		} else {
			update_option('sps_opt_exclude_pages',array());			
		}
		
		if(in_array($_POST['sps-opt-style'],array('popup','popdown','popleft','popright'))){
			update_option('sps_opt_style', $_POST['sps-opt-style']);
		} else {
			update_option('sps_opt_style', 'popup');
			$message .= '<div id="message" class="error fade"><p><strong>Error: Bad Pop Style. Please Try Again.</strong></p></div>';
		}

		$_POST['sps-opt-box'] == 'yes' ? update_option('sps_opt_box', 'yes') : update_option('sps_opt_box', 'no');
		
		if(in_array($_POST['sps-opt-box-pos'],array('none','left','right'))) {
			update_option('sps_opt_box_pos', $_POST['sps-opt-box-pos']);
		}  else {
			update_option('sps_opt_box_pos', 'none');
			$message .= '<div id="message" class="error fade"><p><strong>Error: Bad Box Pos. Please Try Again.</strong></p></div>';
		}
		
		$_POST['sps-opt-title'] == '' ? update_option('sps_opt_title', 'Share!') : update_option('sps_opt_title', $_POST['sps-opt-title']);
		$_POST['sps-opt-no-title'] == 'on' ? update_option('sps_opt_no_title', 'yes') : update_option('sps_opt_no_title', 'no' );

		if(in_array($_POST['sps-opt-holder'],array('none','gray','blue','purple','pink','orange','yellow','green','red'))){
			update_option('sps_opt_holder', $_POST['sps-opt-holder']);
		} else {
			update_option('sps_opt_holder', 'none');
			$message .= '<div id="message" class="error fade"><p><strong>Error: Bad Holder Style. Please Try Again.</strong></p></div>';
		}

		$current = get_option('sps_opt_bgcolor');
		$new_bgcolor = preg_replace('/\#/','',$_POST['sps-opt-bgcolor']);
		$pattern = '/^\#?([abcdefABCDEF0123456789]){6}$/';
		if(preg_match($pattern, $_POST['sps-opt-bgcolor'])){
			update_option('sps_opt_bgcolor', $new_bgcolor);
		} else if(($_POST['sps-opt-bgcolor']=='') || ($_POST['sps-opt-bgcolor']=='#')) {
			update_option('sps_opt_bgcolor', 'ffffff');
		} else {
			update_option('sps_opt_bgcolor', $current);						
			$message .= '<div id="message" class="error fade"><p><strong>Error: Bad Background Color. Please Use a 6 Digit Alphanumeric Hex Value.</strong></p></div>';
		}
		
		if(empty($message)){
			$message = '<div id="message" class="updated fade"><p><strong>Options Saved</strong></p></div>';			
		}
	
	}
	
	$options['sp-showcase'] = get_option('sps_showcase');
	$options['sps-opt-posts'] = get_option('sps_opt_posts');
	$options['sps-opt-pages'] = get_option('sps_opt_pages');

	$options['sps-opt-exclude-posts'] = get_option('sps_opt_exclude_posts');
	$options['sps-opt-exclude-pages'] = get_option('sps_opt_exclude_pages');

	$options['sps-use-bitly'] = get_option('sps_use_bitly','false');
	$options['sps-opt-bitly-username'] = get_option('sps_opt_bitly_username','');
	$options['sps-opt-bitly-api-key'] = get_option('sps_opt_bitly_api_key','');
	
	$style_value = get_option('sps_opt_style','popup');
	$options["sps-opt-style-$style_value"] = 'checked="checked"'; 

	$box_value = get_option('sps_opt_box','no');
	$options["sps-opt-box-$box_value"] = 'checked="checked"'; 

	$box_pos_value = get_option('sps_opt_box_pos','none');
	$options["sps-opt-box-pos-$box_pos_value"] = 'checked="checked"'; 

	$options['sps-opt-title'] = stripslashes(get_option('sps_opt_title','Share!'));	
	get_option('sps_opt_no_title') == 'yes' ? $options['sps-opt-no-title'] = 'checked="checked"' : $options['sps-opt-no-title'] = '';	

	$holder_value = get_option('sps_opt_holder','none');
	$options["sps-opt-holder-$holder_value"] = 'checked="checked"'; 
	
	$options['sps-opt-bgcolor'] = get_option('sps_opt_bgcolor','ffffff');	
	
	$sps_standard = array("sps_id_twitter","sps_id_facebook","sps_id_digg","sps_id_stumbleupon",
	                      "sps_id_delicious","sps_id_google-buzz","sps_id_linkedin","sps_id_email");
	$sps_standard_count = 0;
	
	if(!empty($options['sp-showcase'])) {
		$sps_disabled = explode(",", $options['sp-showcase']);	
		if(count($sps_disabled)==count($socialpops)) {
			$sps_lazy_add_disabled = " style=\"opacity: 0.3;\" class=\"ui-draggable ui-draggable-disabled ui-state-disabled drop-disabled\"";			
			$sps_lazy_standard_disabled = " style=\"opacity: 0.3;\" class=\"ui-draggable ui-draggable-disabled ui-state-disabled drop-disabled\"";			
		} else {
			$sps_lazy_add_disabled = " class=\"drop-enabled\"";			

			// Check to sse if the Add Standards option needs to be disabled.
			foreach($sps_disabled as $spsd) {
				if(in_array($spsd, $sps_standard)) {
					$sps_standard_count++;
				}
			}

			if($sps_standard_count==8){
				$sps_lazy_standard_disabled = " style=\"opacity: 0.3;\" class=\"ui-draggable ui-draggable-disabled ui-state-disabled drop-disabled\"";			
			} else {
				$sps_lazy_standard_disabled = " class=\"drop-enabled\"";			
			}

		}		

		$sps_lazy_remove_disabled = " class=\"drop-enabled\"";
		
		
	} else {
		$sps_disabled = array();
		$sps_lazy_add_disabled = " class=\"drop-enabled\"";
		$sps_lazy_remove_disabled = " style=\"opacity: 0.3;\" class=\"ui-draggable ui-draggable-disabled ui-state-disabled drop-disabled\"";
		$sps_lazy_standard_disabled = " class=\"drop-enabled\"";
	}
	
	$count = 0;
	
?>
	<div class="wrap">
		<?php echo $message ?>
		<div id="icon-options-general" class="icon32"><br /></div>
		<h2>SocialPop Settings</h2>
		<div id="sps-settings-nav">
			<ul>
				<li id="sps-show-main-tab" class="focus-tab">Display Settings</li>
				<li id="sps-show-manual-tab" class="focusoff-tab">Manual Insert Settings</li>
				<li id="sps-show-shortlink-tab" class="focusoff-tab">Bit.ly Settings</li>
				<li id="sps-show-extra-tab" class="focusoff-tab">Extra</li>
			</ul>
		</div>
		<div id="sps-settings">
		<div id="sps-main-settings">		
		<form method="post" action="">
			<div class="socialpop-save-top">
				<input type="submit" class="button-primary" value="Save Changes" />
			</div>
		<input type="hidden" name="action" value="update" />
		<input type="hidden" name="socialpop-showcase" value="<?php echo $options['sp-showcase'] ?>" />		
		<input type="hidden" name="socialpop-manual-showcase" value="<?php echo $options['sp-showcase'] ?>" />		
		<div id="socialpop-options">
			<div class="sps-options-sec">
				<div class="input-text">
					<input name="sps-opt-posts" type="checkbox" id="sps-opt-posts" <?php echo $options['sps-opt-posts'] ?> /> Show on Posts<br />					
					<div>
						<h5>Enter Post ID's you want to exclude:</h5>
						<input name="sps-opt-exclude-posts" type="text" id="sps-opt-exclude-posts" value="" />					
						<div class="sps-tip">(separate post ID's by commas)</div>
					</div>
					<?php if(!empty($options['sps-opt-exclude-posts'])) { ?>
					<div  id="show-ex-posts" class="exclude-list">
						<h5>Show Excluded Posts</h5>
						<div class="excluded">
							<span class="save-ex-posts">Make sure to save your changes!</span>
							<ul>
								<?php
									$exposts = array();
									foreach($options['sps-opt-exclude-posts'] as $e_key => $e_val) {
										if(!empty($e_val)) {
											echo "<li><a href=\"#\" id=\"remove_$e_key\" class=\"exposts-remove-icon\">x</a> $e_val</li>";
											array_push($exposts,$e_key); 									
										}
									}
								?>						
							</ul>							
							<?php
								$exclude_posts = implode(' ',$exposts);
								echo "<input type=\"hidden\" name=\"exposts\" value=\"$exclude_posts\" />";							
							?>
						</div>
					</div>
					<?php } ?>
				</div>
				<div class="input-text">
					<input name="sps-opt-pages" type="checkbox" id="sps-opt-pages" <?php echo $options['sps-opt-pages'] ?> /> Show on Pages				
					<div>
						<h5>Enter Page ID's you want to exclude:</h5>
						<input name="sps-opt-exclude-pages" type="text" id="sps-opt-exclude-pages" value="" />					
						<div class="sps-tip">(separate page ID's by commas)</div>
					</div>
					<?php if(!empty($options['sps-opt-exclude-pages'])) { ?>
					<div id="show-ex-pages" class="exclude-list">
						<h5>Show Excluded Pages</h5>
						<div class="excluded">
							<span class="save-ex-pages">Make sure to save your changes!</span>
							<ul>
								<?php
									$expages = array();
									foreach($options['sps-opt-exclude-pages'] as $e_key => $e_val) {
										if(!empty($e_val)) {
											echo "<li><a href=\"#\" id=\"remove_$e_key\" class=\"expages-remove-icon\">x</a> $e_val</li>";
											array_push($expages,$e_key); 									
										}
									}
								?>						
							</ul>	
							<?php
								$exclude_pages = implode(' ',$expages);
								echo "<input type=\"hidden\" name=\"expages\" value=\"$exclude_pages\" />";
							?>						
						</div>
					</div>
					<?php } ?>
				</div>								
			</div>	
			<div class="sps-options-sec">
				<div>
					<h4>Style</h4>
					<input type="radio" name="sps-opt-style" value="popup" id="sps-opt-style-popup" <?php echo $options['sps-opt-style-popup'] ?> /> <label for="sps-opt-style-popup">Pop-Up</label><br />
					<input type="radio" name="sps-opt-style" value="popdown" id="sps-opt-style-popdown" <?php echo $options['sps-opt-style-popdown'] ?> /> <label for="sps-opt-style-popdown">Pop-Down</label><br />
					<input type="radio" name="sps-opt-style" value="popleft" id="sps-opt-style-popleft" <?php echo $options['sps-opt-style-popleft'] ?> /> <label for="sps-opt-style-popleft">Pop-Left</label><br />
					<input type="radio" name="sps-opt-style" value="popright" id="sps-opt-style-popright" <?php echo $options['sps-opt-style-popright'] ?> /> <label for="sps-opt-style-popright">Pop-Right</label><br />					
				</div>
				<div>
					<h4>Box</h4>
					<input type="radio" name="sps-opt-box" value="yes" id="sps-opt-box-yes" <?php echo $options['sps-opt-box-yes'] ?> /> <label for="sps-opt-box-yes">Yes</label><br />
					<input type="radio" name="sps-opt-box" value="no" id="sps-opt-box-no" <?php echo $options['sps-opt-box-no'] ?> /> <label for="sps-opt-box-no">No</label><br /><br />		
					<h4>Position</h4>
					<input type="radio" name="sps-opt-box-pos" value="none" id="sps-opt-box-pos-none" <?php echo $options['sps-opt-box-pos-none'] ?> /> <label for="sps-opt-box-no">Center</label><br />		
					<input type="radio" name="sps-opt-box-pos" value="left" id="sps-opt-box-pos-left" <?php echo $options['sps-opt-box-pos-left'] ?> /> <label for="sps-opt-box-no">Left</label><br />										
					<input type="radio" name="sps-opt-box-pos" value="right" id="sps-opt-box-pos-right" <?php echo $options['sps-opt-box-pos-right'] ?> /> <label for="sps-opt-box-no">Right</label><br />										
				</div>
				<div>
					<h4>Holder Style</h4>
					<input type="radio" name="sps-opt-holder" value="none" id="sps-opt-holder-none" <?php echo $options['sps-opt-holder-none'] ?> /> <label for="sps-opt-holder-none">None</label><br />
					<input type="radio" name="sps-opt-holder" value="gray" id="sps-opt-holder-gray" <?php echo $options['sps-opt-holder-gray'] ?> /> <label for="sps-opt-holder-gray"><img src="<?php echo $socialpop_path; ?>/images/popup-overlay-gray.png" alt="Gray" /></label><br />
					<input type="radio" name="sps-opt-holder" value="blue" id="sps-opt-holder-blue" <?php echo $options['sps-opt-holder-blue'] ?> /> <label for="sps-opt-holder-blue"><img src="<?php echo $socialpop_path; ?>/images/popup-overlay-blue.png" alt="Blue" /></label><br />
					<input type="radio" name="sps-opt-holder" value="purple" id="sps-opt-holder-purple" <?php echo $options['sps-opt-holder-purple'] ?> /> <label for="sps-opt-holder-purple"><img src="<?php echo $socialpop_path; ?>/images/popup-overlay-purple.png" alt="Purple" /></label><br />
					<input type="radio" name="sps-opt-holder" value="pink" id="sps-opt-holder-pink" <?php echo $options['sps-opt-holder-pink'] ?> /> <label for="sps-opt-holder-pink"><img src="<?php echo $socialpop_path; ?>/images/popup-overlay-pink.png" alt="Pink" /></label><br />
					<input type="radio" name="sps-opt-holder" value="yellow" id="sps-opt-holder-yellow" <?php echo $options['sps-opt-holder-yellow'] ?> /> <label for="sps-opt-holder-yellow"><img src="<?php echo $socialpop_path; ?>/images/popup-overlay-yellow.png" alt="Yellow" /></label><br />
					<input type="radio" name="sps-opt-holder" value="orange" id="sps-opt-holder-orange" <?php echo $options['sps-opt-holder-orange'] ?> /> <label for="sps-opt-holder-orange"><img src="<?php echo $socialpop_path; ?>/images/popup-overlay-orange.png" alt="Orange" /></label><br />
					<input type="radio" name="sps-opt-holder" value="green" id="sps-opt-holder-green" <?php echo $options['sps-opt-holder-green'] ?> /> <label for="sps-opt-holder-green"><img src="<?php echo $socialpop_path; ?>/images/popup-overlay-green.png" alt="Green" /></label><br />
					<input type="radio" name="sps-opt-holder" value="red" id="sps-opt-holder-red" <?php echo $options['sps-opt-holder-red'] ?> /> <label for="sps-opt-holder-red"><img src="<?php echo $socialpop_path; ?>/images/popup-overlay-red.png" alt="Red" /></label><br />
				</div>
				<div class="input-text">
					<h4>Background Color</h4>
					<p>If no "Holder Style", specify a 6 digit alphanumeric hex value associated with the color behind the social media icons.<br /><br /> Defaults to white</p>
					<input type="text" name="sps-opt-bgcolor" value="#<?php echo $options['sps-opt-bgcolor'] ?>" id="sps-opt-bgcolor" />
				</div>
				<div class="input-text">
					<h4>Title</h4>
					<input type="text" name="sps-opt-title" value="<?php echo $options['sps-opt-title'] ?>" id="sps-opt-title" /><br />
					<input name="sps-opt-no-title" type="checkbox" id="sps-opt-no-title" <?php echo $options['sps-opt-no-title'] ?> /> No Title
				</div>
			</div>
		</div>

		<div id="socialpop-select">
				<div class="input-text sps-doc">
					<h3>Choose Which Social Media Icons to Display</h3>
					<p>Drag the icons from the left, to the white "Active Social Media Icons" box on the right and order them how you like.</p>
				</div>
				<div id="socialpop-dad">
					<div id="all-message">
						<h3>"social junkies" everywhere are going to love you!</h3>
					</div>
					<div id="none-message">
						<h3>WARNING: dropping this in the active list will remove all icons!</h3>
					</div>
					<div id="standard-message">
						<h3>The Usual Suspects</h3>
						<img src="<?php echo $socialpop_path; ?>/images/icons/16px/delicious.png" alt="Delicious" />
						<img src="<?php echo $socialpop_path; ?>/images/icons/16px/digg.png" alt="Digg" />
						<img src="<?php echo $socialpop_path; ?>/images/icons/16px/email.png" alt="E-mail" />
						<img src="<?php echo $socialpop_path; ?>/images/icons/16px/facebook.png" alt="Facebook" />
						<img src="<?php echo $socialpop_path; ?>/images/icons/16px/google-buzz.png" alt="Google Buzz" />
						<img src="<?php echo $socialpop_path; ?>/images/icons/16px/linkedin.png" alt="LinkedIn" />
						<img src="<?php echo $socialpop_path; ?>/images/icons/16px/stumbleupon.png" alt="StumbleUpon" />
						<img src="<?php echo $socialpop_path; ?>/images/icons/16px/twitter.png" alt="Twitter" />
					</div>
						<div id="socialpop-lazy">
							<ul>
								<li<?php echo $sps_lazy_add_disabled; ?> id="sps-add"><img src="<?php echo $socialpop_path; ?>/images/icons/16px/add-all.png" alt="Add All" /> Add All</li>
								<li<?php echo $sps_lazy_standard_disabled; ?> id="sps-standard"><img src="<?php echo $socialpop_path; ?>/images/icons/16px/add-standard.png" alt="Add Standard" /> Add Standard</li>
							</ul>
							<ul>
								<li<?php echo $sps_lazy_remove_disabled; ?> id="sps-remove"><img src="<?php echo $socialpop_path; ?>/images/icons/16px/remove-all.png" alt="Remove All" /> Remove All</li>
							</ul>
						</div>
						<div id="socialpop-drag">
							<ul>
					<?php
						foreach($socialpops as $sps_key => $sps_value) {
							if($count >= 13) {
								echo "</ul>\n<ul>";
								$count = 0;
							}
							if(in_array($sps_key, $sps_disabled)){
								$disabled = " style=\"opacity: 0.3;\" class=\"ui-draggable ui-draggable-disabled ui-state-disabled drop-disabled\"";
							} else {
								$disabled = " class=\"drop-enabled\"";
							}
								echo '<li' . $disabled . ' id="' . $sps_key .'"><img src="' . $socialpop_path . '/images/icons/16px/' . $sps_value['file'] .'.png" alt="' . $sps_value['name'] .'" /> ' . $sps_value['name'] .'</li>'."\n";	
								$count++;			
						}
					?>				
							</ul>
						</div>

						<div id="socialpop-drop">
							<h3>Active Social Media Icons</h3>
							<ul>
								<?php
									if(!empty($sps_disabled)){
										foreach($sps_disabled as $spsd) {
											echo '<li id="dropped_' . $spsd .'"><img src="' . $socialpop_path . '/images/icons/16px/' . $socialpops[$spsd]['file'] .'.png" alt="' . $socialpops[$spsd]['name'] .'" /> ' . $socialpops[$spsd]['name'] .' <a href="" class="remove-icon">remove</a></li>'."\n";				
										}						
									} else {
										echo '<li id="placeholder"></li>';						
									}
								?>				
							</ul>
							<h5>Drag &amp; Sort Icons Above.</h5>					
						</div>			
				</div>

			</div>	
			<div class="socialpop-save">
				<input type="submit" class="button-primary" value="Save Changes" />
			</div>

			</form>
			</div>		
			<div id="sps-manual-settings">
				<div class="input-text">
					<form action="" method="post" accept-charset="utf-8">
						<label for="get-manual-id">Page or Post ID:</label><br />
						<input type="text" name="get-manual-id" value="" id="get-manual-id" /><br />
						<strong>OR</strong><br />
						<label for="get-manual-title">Enter a Title:</label><br />
						<input type="text" name="get-manual-title" value="" id="get-manual-title" /><br />
						<label for="get-manual-url">Enter a URL:</label><br />
						<input type="text" name="get-manual-url" value="" id="get-manual-url" /><br />

						<input type="submit" class="sps-btn" id="get-manual-insert-btn" value="Get Code" />
					</form>
				</div>
				<div id="manual-insert">
					<div id="manual-insert-code"><p>Enter a Page or Post ID, or a custom Title and URL. Then click "Get Code".</p><p>All Social Media Icons will link to your custom settings and then just copy and paste the results where ever you want in your theme template. It's that easy!</p></div>
					<div id="manual-insert-code-tip">Copy &amp; Paste the Above Code Anywhere You Want!</div>					
				</div>				
				<div id="socialpop-manual-select">
						<div class="input-text sps-doc">
							<h3>Choose Which Social Media Icons to Display</h3>
							<p>Drag the icons from the left, to the white "Active Social Media Icons" box on the right and order them how you like.</p>
							<p><em>Currently pre-filled with your saved settings, however you can change them for manual insert without effecting your saved settings.</em></p>							
						</div>
						<div id="socialpop-manual-dad">
							<div id="all-manual-message">
								<h3>"social junkies" everywhere are going to love you!</h3>
							</div>
							<div id="none-manual-message">
								<h3>WARNING: dropping this in the active list will remove all icons!</h3>
							</div>
							<div id="standard-manual-message">
								<h3>The Usual Suspects</h3>
								<img src="<?php echo $socialpop_path; ?>/images/icons/16px/delicious.png" alt="Delicious" />
								<img src="<?php echo $socialpop_path; ?>/images/icons/16px/digg.png" alt="Digg" />
								<img src="<?php echo $socialpop_path; ?>/images/icons/16px/email.png" alt="E-mail" />
								<img src="<?php echo $socialpop_path; ?>/images/icons/16px/facebook.png" alt="Facebook" />
								<img src="<?php echo $socialpop_path; ?>/images/icons/16px/google-buzz.png" alt="Google Buzz" />
								<img src="<?php echo $socialpop_path; ?>/images/icons/16px/linkedin.png" alt="LinkedIn" />
								<img src="<?php echo $socialpop_path; ?>/images/icons/16px/stumbleupon.png" alt="StumbleUpon" />
								<img src="<?php echo $socialpop_path; ?>/images/icons/16px/twitter.png" alt="Twitter" />
							</div>
								<div id="socialpop-manual-lazy">
									<ul>
										<li<?php echo $sps_lazy_add_disabled; ?> id="sps-manual-add"><img src="<?php echo $socialpop_path; ?>/images/icons/16px/add-all.png" alt="Add All" /> Add All</li>
										<li<?php echo $sps_lazy_standard_disabled; ?> id="sps-manual-standard"><img src="<?php echo $socialpop_path; ?>/images/icons/16px/add-standard.png" alt="Add Standard" /> Add Standard</li>
									</ul>
									<ul>
										<li<?php echo $sps_lazy_remove_disabled; ?> id="sps-manual-remove"><img src="<?php echo $socialpop_path; ?>/images/icons/16px/remove-all.png" alt="Remove All" /> Remove All</li>
									</ul>
								</div>
								<div id="socialpop-manual-drag">
									<ul>
							<?php
								$count = 0;

								foreach($socialpops as $sps_key => $sps_value) {
									if($count >= 13) {
										echo "</ul>\n<ul>";
										$count = 0;
									}
									if(in_array($sps_key, $sps_disabled)){
										$disabled = " style=\"opacity: 0.3;\" class=\"ui-draggable ui-draggable-disabled ui-state-disabled drop-disabled\"";
									} else {
										$disabled = " class=\"drop-enabled\"";
									}
										echo '<li' . $disabled . ' id="manual_' . $sps_key .'"><img src="' . $socialpop_path . '/images/icons/16px/' . $sps_value['file'] .'.png" alt="' . $sps_value['name'] .'" /> ' . $sps_value['name'] .'</li>'."\n";	
										$count++;			
								}
							?>				
									</ul>
								</div>

								<div id="socialpop-manual-drop">
									<h3>Active Social Media Icons</h3>
									<ul>
										<?php
											if(!empty($sps_disabled)){
												foreach($sps_disabled as $spsd) {
													echo '<li id="dropped_manual_' . $spsd .'"><img src="' . $socialpop_path . '/images/icons/16px/' . $socialpops[$spsd]['file'] .'.png" alt="' . $socialpops[$spsd]['name'] .'" /> ' . $socialpops[$spsd]['name'] .' <a href="" class="remove-icon">remove</a></li>'."\n";				
												}						
											} else {
												echo '<li id="placeholder-manual"></li>';						
											}
										?>				
									</ul>
									<h5>Drag &amp; Sort Icons Above.</h5>					
								</div>			
						</div>
					</div>				
			</div><!-- End Manual Settings-->
			<div id="sps-shortlink-settings">
				<div class="input-text sps-doc">
					<p>To use Bit.ly short links with your social media sharing icons, just enter in your Bit.ly Username and <a href="http://bit.ly/a/your_api_key" onclick="window.open(this.href);return false;">API Key</a> and then click the "Validate" button.</p>
					<p>If your username and api key validate, your social media sharing icons will now use Bit.ly short links.</p>
				</div>
				<div class="input-text">
					<h4>Use Bit.ly Links</h4>
					<div>
						<h5>Bit.ly Username:</h5>
						<input name="sps-opt-bitly-username" type="text" id="sps-opt-bitly-username" value="<?php echo $options['sps-opt-bitly-username']; ?>" />					
					</div>
					<div>
						<h5>Bit.ly API Key:</h5>
						<input name="sps-opt-bitly-api-key" type="text" id="sps-opt-bitly-api-key" value="<?php echo $options['sps-opt-bitly-api-key'] ?>" />					
					</div>
					<div id="is-valid-bitly" class="valid"></div>
					<div>
						<input type="hidden" name="use-bitly" value="<?php echo $options['sps-use-bitly'] ?>" id="use-bitly" />
						<input type="button" class="sps-btn" name="bitly-clear-btn" value="Clear" id="bitly-clear-btn" />
						<input type="button" class="sps-btn" name="bitly-validate-btn" value="Validate" id="bitly-validate-btn" />
						<input type="button" class="sps-btn" name="bitly-reset-btn" value="Change" id="bitly-reset-btn" />
					</div>
				</div>
				<div class="clear"></div>
			</div><!-- End Shortlink Settings-->
			<div id="sps-extra-settings">
				<div class="input-text">
					<p>Thank you so much for purchasing the SocialPop Wordpress plugin! I've spent a lot of time building and updating it, so I appreciate your purchase and will work hard to keep it updated with fixes and feature requests so that it remains one of your favorite Wordpress plugins.</p>
					<p>When you downloaded the plugin, you were given the choice to rate it 1-5 stars. <strong>If you haven't already, and are happy with the plugin please rate it the full 5 stars.</strong> High ratings help to further promote the plugin as well as allow me to continue further developing it for you, with updates and feature requests.</p>
					<p>If you have any questions or concerns, please feel free to contact me on the form on <a href="http://codecanyon.net/user/luckykind" onclick="window.open(this.href);return false;">this page</a> and I'll be happy to answer any of your questions as soon as possible.</p>
					<p>Thanks again for your purchase and be sure to follow me on the <a href="http://themeforest.net/user/luckykind/follow" onclick="window.open(this.href);return false;">Envato Marketplaces</a> or on <a href="http://twitter.com/luckykind" onclick="window.open(this.href);return false;">Twitter</a> to get the latest updates and new item information!</p>
				</div>	
				<div class="input-text sps-doc">
					<p>If you like this plugin, you may like some of my other work at:</p> 
					<ul>
						<li><a href="http://themeforest.net/user/luckykind/portfolio" onclick="window.open(this.href);return false;">Themeforest.net</a></li>
						<li><a href="http://graphicriver.net/user/luckykind/portfolio" onclick="window.open(this.href);return false;">GraphicRiver.net</a></li>
						<li><a href="http://codecanyon.net/user/luckykind/portfolio" onclick="window.open(this.href);return false;">CodeCanyon.net</a></li>
					</ul>
					<p>As well as on my personal site at <a href="http://luckykind.com" onclick="window.open(this.href);return false;">LuckyKind.com</a>.</p>
					<p>The icons used and provided in this plugin are provided by <a href="http://icondock.com" onclick="window.open(this.href);return false;">IconDock</a> under a <a href="http://creativecommons.org/licenses/by-sa/3.0/" onclick="window.open(this.href);return false;">Creative Commons Attribution-Share Alike 3.0 Unported License</a>
					</p>
				</div>	
				<div id="extra-ad">
					<a href="http://bit.ly/upnext"><img src="http://www.lostbeans.com/images/upnext.png" alt="UpNext" /></a>
				</div>
				<div class="clear"></div>							
			</div><!-- End Extra Settings -->
			</div><!-- End Settings -->
		</div>
<?php
	
}

function socialpop_admin_menu() {
	$sp_page = add_options_page('SocialPop', 'SocialPop', 9, basename(__FILE__), 'socialpop_settings');
	add_action( "admin_print_scripts-$sp_page", 'socialpop_admin_setup' );
	}

add_action('wp_ajax_manual_insert', 'sps_get_manual_insert');
add_action('wp_ajax_use_bitly', 'sps_use_bitly');

function sps_use_bitly() {
	if($_POST['check']==false) {
		update_option('sps_use_bitly',"false");
		update_option('sps_opt_bitly_username','');			
		update_option('sps_opt_bitly_api_key','');			
		die();
	}


	$login = $_POST['username'];
	$api_key = $_POST['apikey'];
	
	/* Grab bitly link */
	$version = 'v3';
	$format = 'json';
	$data = file_get_contents('http://api.bit.ly/'.$version.'/validate?x_login='.$login.'&x_apiKey='.$api_key.'&apiKey=R_bd7e4bb34dcc44db37b05699afcbd8bd&login=socialpop&format='.$format);
	$json = json_decode($data, true);
	$bitly_validate = $json['data']['valid'];
	
	if($bitly_validate) {
		update_option('sps_use_bitly',"true");
		update_option('sps_opt_bitly_username',$login);			
		update_option('sps_opt_bitly_api_key',$api_key);			
	} else {
		update_option('sps_use_bitly',"false");
		update_option('sps_opt_bitly_username','');			
		update_option('sps_opt_bitly_api_key','');			
	}
	
	echo $bitly_validate;
	die();
}

function sps_get_manual_insert() {
	global $wpdb; // this is how you get access to the database
	global $socialpops;
	include 'socialpop-functions.php';
	
	$sp_get = $_POST['man_icons'];
	$sp_get = explode(',',$sp_get);
	
	$sp_showcase = array();
		
	foreach($sp_get as $spg){
		if(preg_match('/^manual_manual_/',$spg)) {
			$spg = substr($spg,14);			
		}
		array_push($sp_showcase,$socialpops[$spg]);
	}
	
	if(empty($sp_showcase[0])) {
		$success = array('success' => false, 'message' => "<strong>No Social Media Icons Selected!</strong> Please make sure you've added Social Media Icons to your saved settings.");
		echo json_encode($success);
		die();
	}
	
	if(preg_match('/^[^0][0-9]*$/',$_POST['man_id'])) {
		$man_id = $_POST['man_id'];		
	}

	$man_title = $_POST['man_title'];
	
	if(preg_match('@^(https?://([-\w\.]+)+(:\d+)?(/([\w/_\.]*(\?\S+)?)?)?)@',$_POST['man_url'])){
		$man_link = rtrim($_POST['man_url']);		
	}

	if(!empty($man_id)) {
		$args = array('include'=>$man_id,'post_status' => 'publish,private', 'post_type' => 'any');
		$the_post = get_posts($args);
		if(!empty($the_post)) {
			foreach ($the_post as $post) {
				$man_title = $post->post_title;
				$man_link = get_permalink($post->ID);
			}
			$icons = "<div id=\"lk-plugin\"><div class=\"socialpop-container sps-solo\">\n<ul class=\"socialpop-list\">\n" . get_socialpop($sp_showcase, $man_title, $man_link) . "\n</ul>\n</div></div>";
			$icons = htmlentities($icons);
			$success = array('success' => true, 'message' => $icons);
			echo json_encode($success);
		} else {
			$success = array('success' => false, 'message' => "Could not find a <strong>Post</strong> or <strong>Page</strong> associated with <strong>ID $man_id</strong>");
			echo json_encode($success);
		}
		
	} else if(!empty($man_title) && !empty($man_link)) {
		$icons = "<div id=\"lk-plugin\"><div class=\"socialpop-container sps-solo\">\n<ul class=\"socialpop-list\">\n" . get_socialpop($sp_showcase, $man_title, $man_link) . "\n</ul>\n</div></div>";
		$icons = htmlentities($icons);
		$success = array('success' => true, 'message' => $icons);
		echo json_encode($success);
	} else {
		$success = array('success' => false, 'message' => "Your entered information is invalid. Make sure you enter either a Post/Page ID <strong>OR</strong> a Title <strong>AND</strong> a URL");
		echo json_encode($success);
	}

	die();
}


function socialpop_admin_setup() {
	global $socialpop_path;	
	wp_enqueue_script('socialpop-admin-js', $socialpop_path . '/socialpop-admin-script.js', array('jquery-ui-core', 'jquery-ui-draggable', 'jquery-ui-droppable', 'jquery-ui-sortable'));
	?>
	<link rel="stylesheet" href="<?php echo $socialpop_path; ?>/socialpop-admin-styles.css" type="text/css" media="screen" title="no title" charset="utf-8" />
	<script type="text/javascript">
	<!--
		<?php
			echo "var sps_path = \"$socialpop_path\";\n";
		?>
	-->
	</script>	
    <?php		
}

add_action('wp_head', 'socialpop_setup');
add_action('the_content','socialpop_display');
add_action('admin_menu', 'socialpop_admin_menu');

?>
