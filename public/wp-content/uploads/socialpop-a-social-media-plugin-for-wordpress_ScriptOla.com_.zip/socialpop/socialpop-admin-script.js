<!--
/*!
 **************************************************
 * Copyright 2010 - Danny Carmical
 * http://luckykind.com
 **************************************************/

var $j = jQuery.noConflict();


$j(document).ready(function() {
	var sp_title = $j('#sps-opt-title');
	var no_title = $j('#sps-opt-no-title');

	if(no_title.attr('checked')){
		sp_title.attr("disabled", true).animate({opacity:0.5},1);
	}
	
	no_title.click(function(){
		if($j(this).attr('checked')){
			sp_title.attr("disabled", true).animate({opacity:0.5},300);
		} else {
			sp_title.removeAttr("disabled").animate({opacity:1},300);
		}
	});
	
/*******************************************************
 *
 * Auto Insert Settings
 *
 *******************************************************/
	
	var sp_lazy = $j('#socialpop-lazy');
	var sp_drag = $j('#socialpop-drag');
	var sp_drop = $j('#socialpop-drop');
	var sp_showcase = $j('input[name=socialpop-showcase]');
	var sp_value = $j('input[name=socialpop-showcase]').val();
	
	var sp_standard = new Array("sps_id_twitter","sps_id_facebook","sps_id_digg","sps_id_stumbleupon",
	                            "sps_id_delicious","sps_id_google-buzz","sps_id_linkedin","sps_id_email");
	
	var all_message = $j('#all-message');
	var none_message = $j('#none-message');
	var standard_message = $j('#standard-message');
	var placeholder = $j("#placeholder");
	
	
		
	placeholder.stop().animate({
		opacity: 0.2
	}, 1);	
	
	$j("ul > li",sp_drag).draggable({ 
			revert: 'invalid',
			helper: 'clone',
			containment: '#socialpop-dad'
		});
	 
	$j("ul > li",sp_lazy).draggable({ 
			revert: 'invalid',
			helper: 'clone',
			containment: '#socialpop-dad',
			start: function(ev, ui) {
				if(ui.helper.attr('id') == 'sps-add') {
					all_message.stop().animate({
						opacity: 0.9
					}, 500);
				} else if(ui.helper.attr('id') == 'sps-remove'){
					none_message.stop().animate({
						opacity: 0.9,
					}, 500);
				} else if(ui.helper.attr('id') == 'sps-standard'){
					standard_message.stop().animate({
						opacity: 0.9,
					}, 500);
				}
			},
			stop: function(ev, ui) {
				if(ui.helper.attr('id') == 'sps-add') {
					all_message.stop().animate({
						opacity: 0
					}, 200);
				} else if(ui.helper.attr('id') == 'sps-remove'){
					none_message.stop().animate({
						opacity: 0
					}, 200);
				} else if(ui.helper.attr('id') == 'sps-standard'){
					standard_message.stop().animate({
						opacity: 0
					}, 200);
				}
			}
		});
		
	$j("ul",sp_drop).droppable({ 
			accept: '#socialpop-drag ul li, #socialpop-lazy ul li',
			hoverClass: 'drop-highlight',
			activate: function(ev, ui) {
				placeholder.stop().animate({
					opacity: 0.9
				}, 500);
			},
			deactivate: function(ev, ui) {
				placeholder.stop().animate({
					opacity: 0.2
				}, 500);
			},
			drop: function(ev, ui) {
				$j(this).find('#placeholder').remove();
				var sp_standard_count = 0;
				var spv_split;
				
				if(ui.draggable.attr('id') == 'sps-add') {					
					if(sp_value == undefined) {
						spv_split = new Array();
					} else {
						spv_split = sp_value.split(',');
					}

					$j.each($j("ul > li",sp_drag), function(){
						if(jQuery.inArray($j(this).attr('id'), spv_split) < 0) {
							var this_sps = $j(this);
							$j("<li></li>").attr('id', 'dropped_' + this_sps.attr('id')).html(this_sps.html() + ' <a href="" class="remove-icon">remove</a>').appendTo($j("ul",sp_drop));
							sp_drag.find('#' + this_sps.attr('id')).draggable( "disable" ).removeClass('drop-enabled').addClass('drop-disabled').animate({
								opacity:0.3
							},300);
						}
					});
					sp_lazy.find('#sps-add').draggable( "disable" ).removeClass('drop-enabled').addClass('drop-disabled').animate({
						opacity:0.3
					},300);
					sp_lazy.find('#sps-remove').draggable( "enable" ).removeClass('drop-disabled').addClass('drop-enabled').animate({
						opacity:1
					},300);
					
					sp_lazy.find('#sps-standard').draggable( "disable" ).removeClass('drop-enabled').addClass('drop-disabled').animate({
						opacity:0.3
					},300);											
					
				} else if(ui.draggable.attr('id') == 'sps-remove') {
					$j(this).children().remove();
					$j.each($j("ul > li",sp_drag), function(){
						$j(this).draggable( "enable" ).removeClass('drop-disabled').addClass('drop-enabled').animate({
							opacity:1
						},300);
					});				
					sp_lazy.find('#sps-add').draggable( "enable" ).removeClass('drop-disabled').addClass('drop-enabled').animate({
						opacity:1
					},300);
					sp_lazy.find('#sps-standard').draggable( "enable" ).removeClass('drop-disabled').addClass('drop-enabled').animate({
						opacity:1
					},300);
					sp_lazy.find('#sps-remove').draggable( "disable" ).removeClass('drop-enabled').addClass('drop-disabled').animate({
						opacity:0.3
					},300);
				} else if(ui.draggable.attr('id') == 'sps-standard') {
					if(sp_value == undefined) {
						spv_split = new Array();						
					} else {
						spv_split = sp_value.split(',');
					}

					$j.each($j("ul > li",sp_drag), function(){
						if(jQuery.inArray($j(this).attr('id'), sp_standard) >=0 && jQuery.inArray($j(this).attr('id'), spv_split) < 0) {
							var this_sps = $j(this);
							$j("<li></li>").attr('id', 'dropped_' + this_sps.attr('id')).html(this_sps.html() + ' <a href="" class="remove-icon">remove</a>').appendTo($j("ul",sp_drop));
							sp_drag.find('#' + this_sps.attr('id')).draggable( "disable" ).removeClass('drop-enabled').addClass('drop-disabled').animate({
								opacity:0.3
							},300);

						}
					});
					if(($j("ul",sp_drag).children().length - 1) == $j("ul",sp_drop).children().length) {
						sp_lazy.find('#sps-add').draggable( "disable" ).removeClass('drop-enabled').addClass('drop-disabled').animate({
							opacity:0.3
						},300);
					} else {
						sp_lazy.find('#sps-add').draggable( "enable" ).removeClass('drop-disabled').addClass('drop-enabled').animate({
							opacity:1
						},300);
					}
					
					sp_lazy.find('#sps-standard').draggable( "disable" ).removeClass('drop-enabled').addClass('drop-disabled').animate({
						opacity:0.3
					},300);					
						
					sp_lazy.find('#sps-remove').draggable( "enable" ).removeClass('drop-disabled').addClass('drop-enabled').animate({
						opacity:1
					},300);
						
				} else {					
					$j("<li></li>").attr('id', 'dropped_' + ui.draggable.attr('id')).html(ui.draggable.html() + ' <a href="" class="remove-icon">remove</a>').prependTo(this);
					sp_drag.find('#' + ui.draggable.attr('id')).draggable( "disable" ).removeClass('drop-enabled').addClass('drop-disabled').animate({
						opacity:0.3
					},300);					
					sp_lazy.find('#sps-remove').draggable( "enable" ).removeClass('drop-disabled').addClass('drop-enabled').animate({
						opacity:1
					},300);
					
					if(($j("ul",sp_drag).children().length - 1) == $j("ul",sp_drop).children().length) {
						sp_lazy.find('#sps-add').draggable( "disable" ).removeClass('drop-enabled').addClass('drop-disabled').animate({
							opacity:0.3
						},300);						
					}
					
					$j.each($j("ul > li",sp_drop), function(){
						if(jQuery.inArray($j(this).attr('id').substr(8), sp_standard) >= 0) {
							sp_standard_count++;
						}
					});
					
					if(sp_standard_count==8){
						sp_lazy.find('#sps-standard').draggable( "disable" ).removeClass('drop-enabled').addClass('drop-disabled').animate({
							opacity:0.3
						},300);											
					} else {
						sp_lazy.find('#sps-standard').draggable( "enable" ).removeClass('drop-disabled').addClass('drop-enabled').animate({
							opacity:1
						},300);						
					}
				}
				set_sp_value();
			}
			
		}).sortable({
			items: 'li:not(#placeholder)',
			placeholder: 'sort-highlight',
			cursor: 'move',
			containment: 'parent',
			axis: 'y',
			update: function(event, ui) {
				set_sp_value();
			}
		});
	
	$j('.remove-icon').live('click', function(){
		var show_drag = $j(this).parent().attr('id').substr(8);
		var remove_drop = $j(this).parent().attr('id');

		sp_lazy.find('#sps-add').draggable( "enable" ).removeClass('drop-disabled').addClass('drop-enabled').animate({
			opacity:1
		},300);
		
		sp_drag.find('#' + show_drag).draggable( "enable" ).removeClass('drop-disabled').addClass('drop-enabled').animate({
			opacity:1
		},300, function(){
			
			if(jQuery.inArray(show_drag, sp_standard) >= 0) {
				sp_lazy.find('#sps-standard').draggable( "enable" ).removeClass('drop-disabled').addClass('drop-enabled').animate({
					opacity:1
				},300);									
			}

			sp_drop.find('#' + remove_drop).remove();
			set_sp_value();
		});
		

		return false;
	});

	function set_sp_value() {
		sp_value = null;
		var the_list = $j("ul", sp_drop);
				
		if(the_list.children().length == 0) {
			the_list.append('<li id="placeholder" style="opacity: 0.2;"></li>');
		} else {
			$j.each($j("li", the_list), function(){
				if(sp_value == undefined) {
					sp_value = $j(this).attr('id').substr(8);			
				} else {
					sp_value += ',' + $j(this).attr('id').substr(8);						
				}			
			});			
		}
		sp_showcase.val(sp_value);
	}

/*******************************************************
 *
 * Manual Insert Settings
 *
 *******************************************************/

	var sp_m_lazy = $j('#socialpop-manual-lazy');
	var sp_m_drag = $j('#socialpop-manual-drag');
	var sp_m_drop = $j('#socialpop-manual-drop');
	var sp_m_showcase = $j('input[name=socialpop-manual-showcase]');
	var sp_m_value = $j('input[name=socialpop-manual-showcase]').val();
	
	var sp_m_standard = new Array("manual_sps_id_twitter","manual_sps_id_facebook","manual_sps_id_digg","manual_sps_id_stumbleupon",
	                            "manual_sps_id_delicious","manual_sps_id_google-buzz","manual_sps_id_linkedin","manual_sps_id_email");
	
	var all_m_message = $j('#all-manual-message');
	var none_m_message = $j('#none-manual-message');
	var standard_m_message = $j('#standard-manual-message');
	var placeholder_m = $j("#placeholder-manual");
			
	placeholder_m.stop().animate({
		opacity: 0.2
	}, 1);	
	
	$j("ul > li",sp_m_drag).draggable({ 
			revert: 'invalid',
			helper: 'clone',
			containment: '#socialpop-manual-dad'
		});
	 
	$j("ul > li",sp_m_lazy).draggable({ 
			revert: 'invalid',
			helper: 'clone',
			containment: '#socialpop-manual-dad',
			start: function(ev, ui) {
				if(ui.helper.attr('id') == 'sps-manual-add') {
					all_m_message.stop().animate({
						opacity: 0.9
					}, 500);
				} else if(ui.helper.attr('id') == 'sps-manual-remove'){
					none_m_message.stop().animate({
						opacity: 0.9,
					}, 500);
				} else if(ui.helper.attr('id') == 'sps-manual-standard'){
					standard_m_message.stop().animate({
						opacity: 0.9,
					}, 500);
				}
			},
			stop: function(ev, ui) {
				if(ui.helper.attr('id') == 'sps-manual-add') {
					all_m_message.stop().animate({
						opacity: 0
					}, 200);
				} else if(ui.helper.attr('id') == 'sps-manual-remove'){
					none_m_message.stop().animate({
						opacity: 0
					}, 200);
				} else if(ui.helper.attr('id') == 'sps-manual-standard'){
					standard_m_message.stop().animate({
						opacity: 0
					}, 200);
				}
			}
		});
		
	$j("ul",sp_m_drop).droppable({ 
			accept: '#socialpop-manual-drag ul li, #socialpop-manual-lazy ul li',
			hoverClass: 'drop-highlight',
			activate: function(ev, ui) {
				placeholder_m.stop().animate({
					opacity: 0.9
				}, 500);
			},
			deactivate: function(ev, ui) {
				placeholder_m.stop().animate({
					opacity: 0.2
				}, 500);
			},
			drop: function(ev, ui) {
				$j(this).find('#placeholder-manual').remove();
				var sp_m_standard_count = 0;
				var spv_m_split;
				
				if(ui.draggable.attr('id') == 'sps-manual-add') {					
					if(sp_m_value == undefined) {
						spv_m_split = new Array();
					} else {
						spv_m_split = sp_value.split(',');
					}

					$j.each($j("ul > li",sp_m_drag), function(){
						if(jQuery.inArray($j(this).attr('id'), spv_m_split) < 0) {
							var this_m_sps = $j(this);
							$j("<li></li>").attr('id', 'dropped_manual_' + this_m_sps.attr('id')).html(this_m_sps.html() + ' <a href="" class="remove-icon">remove</a>').appendTo($j("ul",sp_m_drop));
							sp_m_drag.find('#manual_' + this_m_sps.attr('id')).draggable( "disable" ).removeClass('drop-enabled').addClass('drop-disabled').animate({
								opacity:0.3
							},300);
						}
					});
					sp_m_lazy.find('#sps-manual-add').draggable( "disable" ).removeClass('drop-enabled').addClass('drop-disabled').animate({
						opacity:0.3
					},300);
					sp_m_lazy.find('#sps-manual-remove').draggable( "enable" ).removeClass('drop-disabled').addClass('drop-enabled').animate({
						opacity:1
					},300);
					
					sp_m_lazy.find('#sps-manual-standard').draggable( "disable" ).removeClass('drop-enabled').addClass('drop-disabled').animate({
						opacity:0.3
					},300);											
					
				} else if(ui.draggable.attr('id') == 'sps-manual-remove') {
					$j(this).children().remove();
					$j.each($j("ul > li",sp_m_drag), function(){
						$j(this).draggable( "enable" ).removeClass('drop-disabled').addClass('drop-enabled').animate({
							opacity:1
						},300);
					});				
					sp_m_lazy.find('#sps-manual-add').draggable( "enable" ).removeClass('drop-disabled').addClass('drop-enabled').animate({
						opacity:1
					},300);
					sp_m_lazy.find('#sps-manual-standard').draggable( "enable" ).removeClass('drop-disabled').addClass('drop-enabled').animate({
						opacity:1
					},300);
					sp_m_lazy.find('#sps-manual-remove').draggable( "disable" ).removeClass('drop-enabled').addClass('drop-disabled').animate({
						opacity:0.3
					},300);
				} else if(ui.draggable.attr('id') == 'sps-manual-standard') {
					if(sp_m_value == undefined) {
						spv_m_split = new Array();						
					} else {
						spv_m_split = sp_value.split(',');
					}

					$j.each($j("ul > li",sp_m_drag), function(){
						if(jQuery.inArray($j(this).attr('id'), sp_m_standard) >=0 && jQuery.inArray($j(this).attr('id'), spv_m_split) < 0) {
							var this_m_sps = $j(this);
							$j("<li></li>").attr('id', 'dropped_manual_' + this_m_sps.attr('id')).html(this_m_sps.html() + ' <a href="" class="remove-icon">remove</a>').appendTo($j("ul",sp_m_drop));
							sp_m_drag.find('#manual_' + this_m_sps.attr('id')).draggable( "disable" ).removeClass('drop-enabled').addClass('drop-disabled').animate({
								opacity:0.3
							},300);

						}
					});
					if(($j("ul",sp_m_drag).children().length - 1) == $j("ul",sp_m_drop).children().length) {
						sp_m_lazy.find('#sps-manual-add').draggable( "disable" ).removeClass('drop-enabled').addClass('drop-disabled').animate({
							opacity:0.3
						},300);
					} else {
						sp_m_lazy.find('#sps-manual-add').draggable( "enable" ).removeClass('drop-disabled').addClass('drop-enabled').animate({
							opacity:1
						},300);
					}
					
					sp_m_lazy.find('#sps-manual-standard').draggable( "disable" ).removeClass('drop-enabled').addClass('drop-disabled').animate({
						opacity:0.3
					},300);					
						
					sp_m_lazy.find('#sps-manual-remove').draggable( "enable" ).removeClass('drop-disabled').addClass('drop-enabled').animate({
						opacity:1
					},300);
						
				} else {					
					$j("<li></li>").attr('id', 'dropped_manual_' + ui.draggable.attr('id')).html(ui.draggable.html() + ' <a href="" class="remove-icon">remove</a>').prependTo(this);
					sp_m_drag.find('#manual_' + ui.draggable.attr('id')).draggable( "disable" ).removeClass('drop-enabled').addClass('drop-disabled').animate({
						opacity:0.3
					},300);					
					sp_m_lazy.find('#sps-manual-remove').draggable( "enable" ).removeClass('drop-disabled').addClass('drop-enabled').animate({
						opacity:1
					},300);
					
					if(($j("ul",sp_m_drag).children().length - 1) == $j("ul",sp_m_drop).children().length) {
						sp_m_lazy.find('#sps-add').draggable( "disable" ).removeClass('drop-enabled').addClass('drop-disabled').animate({
							opacity:0.3
						},300);						
					}
					
					$j.each($j("ul > li",sp_m_drop), function(){
						if(jQuery.inArray($j(this).attr('id').substr(8), sp_m_standard) >= 0) {
							sp_m_standard_count++;
						}
					});
					
					if(sp_m_standard_count==8){
						sp_m_lazy.find('#sps-manual-standard').draggable( "disable" ).removeClass('drop-enabled').addClass('drop-disabled').animate({
							opacity:0.3
						},300);											
					} else {
						sp_m_lazy.find('#sps-manual-standard').draggable( "enable" ).removeClass('drop-disabled').addClass('drop-enabled').animate({
							opacity:1
						},300);						
					}
				}
				set_sp_m_value();
			}
			
		}).sortable({
			items: 'li:not(#placeholder-manual)',
			placeholder: 'sort-highlight',
			cursor: 'move',
			containment: 'parent',
			axis: 'y',
			update: function(event, ui) {
				set_sp_m_value();
			}
		});
	
	$j('.remove-manual-icon').live('click', function(){
		var show_m_drag = $j(this).parent().attr('id').substr(8);
		var remove_m_drop = $j(this).parent().attr('id');

		sp_m_lazy.find('#sps-manual-add').draggable( "enable" ).removeClass('drop-disabled').addClass('drop-enabled').animate({
			opacity:1
		},300);
		
		sp_m_drag.find('#manual_' + show_m_drag).draggable( "enable" ).removeClass('drop-disabled').addClass('drop-enabled').animate({
			opacity:1
		},300, function(){
			
			if(jQuery.inArray(show_m_drag, sp_m_standard) >= 0) {
				sp_m_lazy.find('#sps-manual-standard').draggable( "enable" ).removeClass('drop-disabled').addClass('drop-enabled').animate({
					opacity:1
				},300);									
			}

			sp_m_drop.find('#manual_' + remove_m_drop).remove();
			set_sp_m_value();
		});
		

		return false;
	});

	function set_sp_m_value() {
		sp_m_value = null;
		var the_m_list = $j("ul", sp_m_drop);
				
		if(the_m_list.children().length == 0) {
			the_m_list.append('<li id="placeholder-manual" style="opacity: 0.2;"></li>');
		} else {
			$j.each($j("li", the_m_list), function(){
				if(sp_m_value == undefined) {
					sp_m_value = $j(this).attr('id').substr(8);			
				} else {
					sp_m_value += ',' + $j(this).attr('id').substr(8);						
				}			
			});			
		}
		sp_m_showcase.val(sp_m_value);
	}
	
	/*******************************************************
	 * Integrating Manual Insert
	 *******************************************************/
		var manual_btn = $j('#get-manual-insert-btn');
		var manual_id_text = $j('#get-manual-id');
		var manual_title_text = $j('#get-manual-title');
		var manual_url_text = $j('#get-manual-url');
		var manual_insert_code = $j('#manual-insert-code');
		var code_tip = $j('#manual-insert-code-tip');

		
		manual_insert_code.bind('click',function(){
			select_text('manual-insert-code');
		})
		
		manual_btn.bind('click',function(e){
			e.preventDefault();
			var data = {
				action: 'manual_insert',
				man_id: manual_id_text.val(), 
				man_title: manual_title_text.val(), 
				man_url: manual_url_text.val(), 
				man_icons: sp_m_value
			};

			$j.post(ajaxurl, data, function(response) {				
				manual_insert_code.html(response.message);
				if(response.success) {
					select_text('manual-insert-code');
					code_tip.fadeIn();					
				} else {
					code_tip.fadeOut();
				}
			}, "json");			
		});
	
		function select_text(element) {
		    var text = document.getElementById(element);
		    if ($j.browser.msie) {
		        var range = document.body.createTextRange();
		        range.moveToElementText(text);
		        range.select();
		    } else if ($j.browser.mozilla || $.browser.opera) {
		        var selection = window.getSelection();
		        var range = document.createRange();
		        range.selectNodeContents(text);
		        selection.removeAllRanges();
		        selection.addRange(range);
		    } else if ($j.browser.safari) {
		        var selection = window.getSelection();
		        selection.setBaseAndExtent(text, 0, text, 1);
		    }
		}


/*******************************************************
 *
 * Update excluded pages and posts
 *
 *******************************************************/	
	var expages = $j('input[name=expages]');

	$j('.expages-remove-icon').live('click', function(){		
		$j(this).parent('li').fadeOut(500);
		var chop = $j(this).attr('id').substr(7);
		var new_ex = new String;
		
		var expages_value = expages.val().split(' ');
		$j.each(expages_value, function(key,val){
			if(chop!=val) {
				new_ex += ' ' + val;
			}
		});
		
		if(new_ex!=null) {
			new_ex = new_ex.substr(1);			
			expages.val(new_ex);
		} else {
			expages.val('');
		}
		
		$j('.save-ex-pages').fadeIn(500);
		return false;
	});
	
	var exposts = $j('input[name=exposts]');
	
	$j('.exposts-remove-icon').live('click', function(){		
		$j(this).parent('li').fadeOut(500);
		var chop = $j(this).attr('id').substr(7);
		var new_ex = new String;

		var exposts_value = exposts.val().split(' ');
		$j.each(exposts_value, function(key,val){
			if(chop!=val) {
				new_ex += ' ' + val;
			}
		});

		if(new_ex!=null) {
			new_ex = new_ex.substr(1);			
			exposts.val(new_ex);
		} else {
			exposts.val('');
		}

		$j('.save-ex-posts').fadeIn(500);
		return false;
	});
		
	var show_ex_posts = $j('#show-ex-posts');
	var show_ex_posts_div = $j('#show-ex-posts div');
	
	if(show_ex_posts!=null) {
		show_ex_posts.children('h5').toggle(
			function(){
				show_ex_posts_div.slideDown();
				$j(this).html('Hide Excluded Posts');
			},
			function(){
				show_ex_posts_div.slideUp();
				$j(this).html('Show Excluded Posts');
			}
		);		
	}
	
	var show_ex_pages = $j('#show-ex-pages');
	var show_ex_pages_div = $j('#show-ex-pages div');

	if(show_ex_pages!=null) {
		show_ex_pages.children('h5').toggle(
			function(){
				show_ex_pages_div.slideDown();
				$j(this).html('Hide Excluded Pages');
			},
			function(){
				show_ex_pages_div.slideUp();
				$j(this).html('Show Excluded Pages');
			}
		);		
	}
	
	/*******************************************************
	 *
	 * Integrating Bitly 
	 *
	 *******************************************************/
	
	
	var bitly_validate_btn = $j('#bitly-validate-btn');
	var bitly_reset_btn = $j('#bitly-reset-btn');
	var bitly_clear_btn = $j('#bitly-clear-btn');
	var is_valid_bitly = $j('#is-valid-bitly');
	var use_bitly = $j('#use-bitly');
	var bitly_username = $j('input[name=sps-opt-bitly-username]');
	var bitly_api = $j('input[name=sps-opt-bitly-api-key]');
	
	bitly_username.focus(function(){
		is_valid_bitly.slideUp();
	});

	bitly_api.focus(function(){
		is_valid_bitly.slideUp();
	});
	
	function approve_bitly_links(success) {
		var check_use = use_bitly.val();
		if(check_use=="true"){
			bitly_username.attr("disabled", true); 
			bitly_api.attr("disabled", true); 
			bitly_validate_btn.hide();
			bitly_reset_btn.show();
		}
		if(success) {
			is_valid_bitly.removeClass('not-valid').html("Validated! Your links will now be shortened via Bit.ly").slideDown().delay(5000).slideUp();																	
		}
	}
	
	approve_bitly_links();

	bitly_clear_btn.bind('click',function(){
		bitly_username.attr("disabled", false).val(''); 
		bitly_api.attr("disabled", false).val(''); 
		bitly_reset_btn.fadeOut(1,function(){
			bitly_validate_btn.fadeIn(1);
		});
		use_bitly.val("false");		
		is_valid_bitly.slideUp();		
	
		var data = {
			action: 'use_bitly',
			check: false
		};

		is_valid_bitly.removeClass('not-valid').html("Cleared! Your links will NO longer be shortened via Bit.ly").slideDown().delay(5000).slideUp();

		$j.post(ajaxurl, data);
	});
			
	
	bitly_reset_btn.bind('click',function(){
		bitly_username.attr("disabled", false); 
		bitly_api.attr("disabled", false); 
		bitly_reset_btn.fadeOut(300,function(){
			bitly_validate_btn.fadeIn(300);
		});
		use_bitly.val("false");		
		is_valid_bitly.slideUp();		
	});
	
	bitly_validate_btn.bind('click',function(){
		var data = {
			action: 'use_bitly',
			check: true,
			username: bitly_username.val(),
			apikey: bitly_api.val(),
		};

		$j.post(ajaxurl, data, function(response) {
			if(response==1) {
				use_bitly.val("true");
				approve_bitly_links("true");
			} else {
				use_bitly.val("false");
				is_valid_bitly.addClass('not-valid').html("Username &amp; API Key Do Not Validate. Please Check and Retry.").slideDown();														
			}
		});
		return false;
	});
	
	var save_btn = $j('.button-primary');
	
	save_btn.bind('click',function(){
		bitly_username.attr("disabled", false); 
		bitly_api.attr("disabled", false); 		
	});
	
	
	
	/*******************************************************
	 *
	 * Tabs
	 *
	 *******************************************************/
	 var sps_tabs = $j('#sps-settings-nav ul li');
	 var sps_sections = {};
	 sps_sections['sps-show-main-tab'] = $j('#sps-main-settings');
	 sps_sections['sps-show-manual-tab'] = $j('#sps-manual-settings');
	 sps_sections['sps-show-shortlink-tab'] = $j('#sps-shortlink-settings');
	 sps_sections['sps-show-extra-tab'] = $j('#sps-extra-settings');
	 var current_tab = 'sps-show-main-tab';
	
	 sps_tabs.bind('click', function(){
		var go_tab = $j(this).attr('id');

		$j.each(sps_tabs,function(){
			$j(this).removeClass('focus-tab').addClass('focusoff-tab');			
			if($j(this).attr('id')==go_tab){
				$j(this).removeClass('focusoff-tab').addClass('focus-tab');							
			}
		});
		if(go_tab!=current_tab){
			$j.each(sps_sections,function(key,val){
				if(go_tab==key) {
					val.show();
					current_tab = key;
				} else {
					val.hide();
				}
			})
		}
	 });


});

-->	