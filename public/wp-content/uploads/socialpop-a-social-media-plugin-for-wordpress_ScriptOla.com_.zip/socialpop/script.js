<!--
/*!
 **************************************************
 * Copyright 2010 - Danny Carmical
 * http://luckykind.com
 **************************************************/

var $j = jQuery.noConflict();

$j(document).ready(function() {		
	$j('.socialpop-list').socialpop({
		style: sps_style,
		box: sps_box,
		boxfloat: sps_boxfloat,
		title: sps_title,
		notitle: sps_notitle,
		holder: sps_holder,
		bgcolor: sps_bgcolor
	});							
});

-->	