=== Event Espresso Requirements Check ===
Contributors: Seth Shoultes
Donate link: http://eventespresso.com/
Tags: event registration, forms, events, event management, email, captcha
Requires at least: 2.8
Tested up to: 2.8
Stable tag: 0.1

This plugin checks your web hosting environment to ensure compatibility with Event Espresso, the premium event management plugin for WordPress. 

== Description ==

This plugin checks your web hosting environment to ensure compatibility with Event Espresso, the premium event management plugin for WordPress.

Event Espresso requires WordPress 2.8+, MySQL 5+ and PHP 5+ in order to function.

Event Espresso is the premier event management solution for WordPress.  The Advanced Events Registration plugin provides an easy to use interface for creating and managing event registrations within the WordPress Administration Panel. Create a event in minutes!

* Seamless Integration with WordPress 2.8+
* Visually create events with our sleek editor
* Protect your data from spam with reCAPTCHA
* Easily embed an event into to your posts or pages
* Export registration data to CSV
* View registration summary from the Dashboard

See the official [Advanced Events Registration website](http://eventespresso.com/) for more details.

== Frequently Asked Questions ==

= Is this the Event Espresso plugin? =

No, this is a plugin that allows you to test your system configuration and hosting to tell if you meet the Event Espresso plugin minimum requirements.

See the official [Event Espresso website](http://eventespresso.com/) for more details.

== Installation ==

To install the plugin and verify your web hosting environment is compatible with Event Espresso:

- Upload the plugin to /wp-content/plugins
- Activate the plugin via the Plugins menu
- A message will appear notifying you if your hosting is compatible.  If Event Espresso is not compatible, you will be notified which requirements failed.

See the official [Event Espresso](http://eventespresso.com/) for more details.

== Changelog ==

See the official [Event Espresso website](http://eventespresso.com/change-log/) for more details.

== Screenshots ==

See the official [Event Espresso website](http://eventespresso.com/) for more details.