<?php
/*
Plugin Name: Event Espresso - Calendar
Plugin URI: http://www.eventespresso.com
Description: A full calendar addon for Event Espresso. Includes month, week, and day views. Add [ESPRESSO_CALENDAR] to any page or post to display a calendar of Event Espresso events.
Version: 1.1
Author: Seth Shoultes
Author URI: http://www.shoultes.net
Copyright 2010  Seth Shoultes  (email : seth@eventespresso.com)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License, version 2, as 
    published by the Free Software Foundation.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

//Define the version of the plugin
function espresso_calendar_version() {
	return '1.1';
}
define("ESPRESSO_CALENDAR_VERSION", espresso_calendar_version() );

//Define the plugin directory and path
define("ESPRESSO_CALENDAR_PLUGINPATH", "/" . plugin_basename( dirname(__FILE__) ) . "/");
define("ESPRESSO_CALENDAR_PLUGINFULLPATH", WP_PLUGIN_DIR . ESPRESSO_CALENDAR_PLUGINPATH  );
define("ESPRESSO_CALENDAR_PLUGINFULLURL", WP_PLUGIN_URL . ESPRESSO_CALENDAR_PLUGINPATH );

//Globals
global $espresso_calendar;
$espresso_calendar = get_option('espresso_calendar_settings');

//Install the plugin
function espresso_calendar_install(){
	//Install Facebook Options
	$espresso_calendar = array(
					'espresso_calendar_header' => "left: 'prev, today', center: 'title', right: 'month,agendaWeek,agendaDay,next'",
					'espresso_calendar_buttonText' => "left: 'prev, today', center: 'title', right: 'month,agendaWeek,agendaDay,next'",
					'espresso_calendar_firstday' => '0',
					'espresso_calendar_weekends' => 'true',
					'espresso_calendar_height' => '650',
					'espresso_calendar_width' => '2',
					'espresso_calendar_titleFormat' => "month: 'MMMM yyyy', week: \"MMM d[ yyyy]{ '—'[ MMM] d yyyy}\", day: 'dddd, MMM d, yyyy'",
					'espresso_calendar_columnFormat' => "month: 'ddd', week: 'ddd M/d', day: 'dddd M/d'",
					'espresso_calendar_monthNames' => "'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'",
					'espresso_calendar_monthNamesShort' => "'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'",
					'espresso_calendar_dayNames' => "'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'",
					'espresso_calendar_dayNamesShort' => "'Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'"
				);
	add_option( 'espresso_calendar_settings', $espresso_calendar );
}
register_activation_hook(__FILE__,'espresso_calendar_install');

function espresso_calendar_config_mnu()	{
	global $wpdb, $espresso_twitter, $espresso_calendar;
	
	/*Facebok*/
	function espresso_calendar_updated(){
	return __('Calendar details saved.','event_espresso');
	}
	
	if (isset($_POST['update_calendar'])) {
		$espresso_calendar['espresso_calendar_header'] = $_POST['espresso_calendar_header'];
		$espresso_calendar['espresso_calendar_buttonText'] = $_POST['espresso_calendar_buttonText'];
		$espresso_calendar['espresso_calendar_firstday'] = $_POST['espresso_calendar_firstday'];
		$espresso_calendar['espresso_calendar_weekends'] = $_POST['espresso_calendar_weekends'];
		$espresso_calendar['espresso_calendar_height'] = $_POST['espresso_calendar_height'];
		$espresso_calendar['espresso_calendar_width'] = $_POST['espresso_calendar_width'];
		$espresso_calendar['espresso_calendar_titleFormat'] = $_POST['espresso_calendar_titleFormat'];
		$espresso_calendar['espresso_calendar_columnFormat'] = $_POST['espresso_calendar_columnFormat'];
		$espresso_calendar['espresso_calendar_monthNames'] = $_POST['espresso_calendar_monthNames'];
		$espresso_calendar['espresso_calendar_monthNamesShort'] = $_POST['espresso_calendar_monthNamesShort'];
		$espresso_calendar['espresso_calendar_dayNames'] = $_POST['espresso_calendar_dayNames'];
		$espresso_calendar['espresso_calendar_dayNamesShort'] = $_POST['espresso_calendar_dayNamesShort'];
		
		update_option( 'espresso_calendar_settings', $espresso_calendar);
		add_action( 'admin_notices', 'espresso_calendar_updated');
	}
	$espresso_calendar = get_option('espresso_calendar_settings');
	
	?>
<div id="configure_organization_form" class="wrap meta-box-sortables ui-sortable">
  <div id="icon-options-event" class="icon32"> </div>
  <h2>
    <?php _e('Event Espresso - Calendar Settings','event_espresso'); ?>
  </h2>
  <div id="event_espresso-col-left">
  <form class="espresso_form" method="post" action="<?php echo $_SERVER['REQUEST_URI']?>">
      <ul id="event_espresso-sortables">
        <li>
          <div class="box-mid-head">
            <h2 class="fugue f-wrench">
              <?php _e('Calendar Settings','event_espresso'); ?>
            </h2>
          </div>
          <div class="box-mid-body" id="toggle2">
            <div class="padding">
              <ul>
              	
              
             
                <li>
                  <label for="espresso_calendar_firstday">
                    <?php _e('First Day of the Week:','event_espresso'); ?>
                  </label>
                 <?php _e('(Sunday=0, Monday=1, Tuesday=2, etc.)', 'event_espresso'); ?><br />
                  <input type="text" name="espresso_calendar_firstday" size="10" maxlength="1" value="<?php echo $espresso_calendar['espresso_calendar_firstday'];?>" />
                </li>
                
                <li>
                  <label for="espresso_calendar_weekends">
                    <?php _e('Show Weekends:','event_espresso'); ?>
                  </label>
                 <?php
						$values=array(					
							array('id'=>'true','text'=> __('Yes','event_espresso')),
							array('id'=>'false','text'=> __('No','event_espresso'))
						);				
							echo select_input('espresso_calendar_weekends', $values, $espresso_calendar['espresso_calendar_weekends']);
					?>
                </li>
                <li>
                  <label for="espresso_calendar_height">
                    <?php _e('Height:','event_espresso'); ?>
                  </label><?php _e('Will make the entire calendar (including header) a pixel height.', 'event_espresso'); ?><br />
                   <input type="text" name="espresso_calendar_height" size="100" maxlength="100" value="<?php echo $espresso_calendar['espresso_calendar_height'];?>" />
                </li>
                <li>
                  <input class="button-primary" type="submit" name="save_calendar_settings" value="<?php _e('Save Calendar Options', 'event_espresso'); ?>" id="save_calendar_settings2" />
                </li>
                <li>
                  <h3><?php _e('Advanced Settings', 'event_espresso'); ?></h3>
<table width="100%" border="0" cellpadding="20" cellspacing="5">
  <tr>
    <td align="left" valign="top">
   <p> <strong><?php _e('Header Style:','event_espresso'); ?></strong><br /><?php _e('Defines the buttons and title at the top of the calendar.', 'event_espresso'); ?></p><textarea name="espresso_calendar_header" id="espresso_calendar_header" cols="30" rows="5"><?php echo stripslashes_deep($espresso_calendar['espresso_calendar_header']) ?></textarea></td>
    <td align="left"  valign="top"><p><strong><?php _e('Example:', 'event_espresso'); ?></strong></p><p>left: 'prev,<br />today', <br />center: 'title', <br />right: 'month,agendaWeek,agendaDay,next'</p></td>
  </tr>
  <tr>
    <td align="left" valign="top">
   <p> <strong><?php _e('Button Text:','event_espresso'); ?></strong><br /><?php _e('Text that will be displayed on buttons of the header.', 'event_espresso'); ?></p><textarea name="espresso_calendar_buttonText" id="espresso_calendar_buttonText" cols="30" rows="5"><?php echo stripslashes_deep($espresso_calendar['espresso_calendar_buttonText']) ?></textarea></td>
    <td align="left"  valign="top"><p><strong><?php _e('Example:', 'event_espresso'); ?></strong></p>
      <p>prev:     '&amp;nbsp;&amp;#9668;&amp;nbsp;',  <span class="red_text">(Eg. left triangle)</span><br />
next:     '&amp;nbsp;&amp;#9658;&amp;nbsp;',<span class="red_text"> (Eg. right triangle)</span><br />
prevYear: '&amp;nbsp;&amp;lt;&amp;lt;&amp;nbsp;', <span class="red_text">(Eg. &lt;&lt; )</span><br />
nextYear: '&amp;nbsp;&amp;gt;&amp;gt;&amp;nbsp;', <span class="red_text">(Eg. &gt;&gt; )</span><br />
today:    'today',<br />
month:    'month',<br />
week:     'week',<br />
day:      'day'</p></td>
  </tr>
  <tr>
    <td align="left" valign="top">
   <p> <strong><?php _e('Title Format:','event_espresso'); ?></strong><br />
<?php _e('For date formatting options.', 'event_espresso'); ?></p><textarea name="espresso_calendar_titleFormat" id="espresso_calendar_titleFormat" cols="30" rows="5"><?php echo stripslashes_deep($espresso_calendar['espresso_calendar_titleFormat']) ?></textarea></td>
    <td align="left" valign="top"><p><strong><?php _e('Example:', 'event_espresso'); ?></strong></p><p>month: 'MMMM yyyy', <span class="red_text">(Eg. September 2009)</span><br />week: "MMM d[ yyyy]{ '&#8212;'[ MMM] d yyyy}", <span class="red_text">(Eg. Sep 7 - 13 2009)</span><br />day: 'dddd, MMM d, yyyy' <span class="red_text">(Eg. Tuesday, Sep 8, 2009)</span></p></td>
  </tr>
  <tr>
    <td align="left" valign="top">
   <p> <strong><?php _e('Column Format:','event_espresso'); ?></strong><br />
<?php _e('For date formatting options.', 'event_espresso'); ?></p><textarea name="espresso_calendar_columnFormat" id="espresso_calendar_columnFormat" cols="30" rows="5"><?php echo stripslashes_deep($espresso_calendar['espresso_calendar_columnFormat']) ?></textarea></td>
    <td align="left" valign="top"><p><strong><?php _e('Example:', 'event_espresso'); ?></strong></p><p>month: 'ddd', <span class="red_text">(Eg. Mon) </span><br />week: 'ddd M/d', <span class="red_text">(Eg. Mon 9/7) </span><br />day: 'dddd M/d' <span class="red_text">(Eg. Monday 9/7)</span></p></td>
  </tr>
   <tr>
    <td align="left" valign="top">
   <p> <strong><?php _e('Month Names:','event_espresso'); ?></strong><br />
<?php _e('Full names of months.', 'event_espresso'); ?></p><textarea name="espresso_calendar_monthNames" id="espresso_calendar_monthNames" cols="30" rows="5"><?php echo stripslashes_deep($espresso_calendar['espresso_calendar_monthNames']) ?></textarea><br /><?php _e('Full names of months.', 'event_espresso'); ?></td>
    <td align="left" valign="top"><p><strong><?php _e('Example:', 'event_espresso'); ?></strong></p><p>'January', 'February', 'March', <br />'April', 'May', 'June', <br />'July', 'August', 'September', 'October', <br />'November', 'December'</p></td>
  </tr>
   <tr>
    <td align="left" valign="top">
   <p> <strong><?php _e('Month Names Short:','event_espresso'); ?></strong><br />
<?php _e('Abbreviated names of months.', 'event_espresso'); ?></p><textarea name="espresso_calendar_monthNamesShort" id="espresso_calendar_monthNamesShort" cols="30" rows="5"><?php echo stripslashes_deep($espresso_calendar['espresso_calendar_monthNames']) ?></textarea><br /><?php _e('Short names of months.', 'event_espresso'); ?></td>
    <td align="left" valign="top"><p><strong><?php _e('Example:', 'event_espresso'); ?></strong></p><p>'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'</p></td>
  </tr>
   <tr>
    <td align="left" valign="top">
   <p> <strong><?php _e('Day Names:','event_espresso'); ?></strong><br />
<?php _e('Full names of days-of-week.', 'event_espresso'); ?></p><textarea name="espresso_calendar_monthNames" id="espresso_calendar_monthNames" cols="30" rows="5"><?php echo stripslashes_deep($espresso_calendar['espresso_calendar_monthNames']) ?></textarea><br /><?php _e('Full names of months.', 'event_espresso'); ?></td>
    <td align="left" valign="top"><p><strong><?php _e('Example:', 'event_espresso'); ?></strong></p><p>'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'</p></td>
  </tr>
   <tr>
    <td align="left" valign="top">
   <p> <strong><?php _e('Day Names Short:','event_espresso'); ?></strong><br />
<?php _e('Abbreviated names of days-of-week.', 'event_espresso'); ?></p><textarea name="espresso_calendar_monthNames" id="espresso_calendar_monthNames" cols="30" rows="5"><?php echo stripslashes_deep($espresso_calendar['espresso_calendar_monthNames']) ?></textarea></td>
    <td align="left" valign="top"><p><strong><?php _e('Example:', 'event_espresso'); ?></strong></p><p>'Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'</p></td>
  </tr>
</table>
                </li>
                 <?php /*?><li>
                  <label for="espresso_calendar_width">
                    <?php _e('Width:','event_espresso'); ?>
                  </label>
                   <input type="text" name="espresso_calendar_width" size="100" maxlength="100" value="<?php echo $espresso_calendar['espresso_calendar_width'];?>" />
                </li><?php */?>
                <li><input type="hidden" name="update_calendar" value="update" />
      <p>
        <input class="button-primary" type="submit" name="Submit" value="<?php _e('Save Calendar Options', 'event_espresso'); ?>" id="save_calendar_settings_1" />
      </p></li>
              </ul>
            </div>
          </div>
        </li>
        </ul>
 </form>
 </div>
        </div><?php event_espresso_display_right_column ();?>
<?php
}
 
//Load the scripts and css
function espresso_init_calendar() {
	wp_enqueue_script('jquery');
	wp_enqueue_script('fullcalendar-min-js',  ESPRESSO_CALENDAR_PLUGINFULLURL.'scripts/fullcalendar.min.js', array('jquery') );//core calendar script
	//wp_enqueue_script('jquery-ui-custom-js',  ESPRESSO_CALENDAR_PLUGINFULLURL.'scripts/jquery-ui-custom.js', array('jquery') );//calendar ui script
	//wp_enqueue_style('redmond', ESPRESSO_CALENDAR_PLUGINFULLURL.'redmond/theme.css');//calendar alternate style
	wp_enqueue_style('calendar', ESPRESSO_CALENDAR_PLUGINFULLURL.'calendar.css');//calendar core style
}
add_action('init', 'espresso_init_calendar');

//Build the short code
//[ESPRESSO_CALENDAR]
function espresso_calendar (){
	global $wpdb, $org_options, $espresso_calendar;;
	 	
	$sql = "SELECT e.*  FROM ". EVENTS_DETAIL_TABLE . " e ";
	//$sql .= " JOIN " . EVENTS_START_END_TABLE . " ese ON e.id = ese.event_id ";
	$sql .= " WHERE is_active = 'Y' ";
	$sql .= " AND event_status != 'D' ";
	//$sql .= " AND start_date >= '".date ( 'Y-m-d' )."' ";
	//$sql .= " AND e.registration_start <= '".date ( 'Y-m-d' )."' ";
	//$sql .= " AND e.registration_end >= '".date ( 'Y-m-d' )."' ";
	//$sql .= " ORDER BY date(e.start_date), id ";
	
	$events_data = $wpdb->get_results($sql);
	
	$events = array();

	foreach ($events_data as $event){
		$eventArray['id'] = $event->id;
		$eventArray['title'] = $event->event_name;
		//important! time must be in iso8601 format 2010-05-10T08:30  !!
		//$start_date = strtotime($event->start_date . ' ' .event_espresso_no_format_date($event->start_date . ' ' .date('h:i:s', event_espresso_get_time($event->id)), 'c'));
		//$end_date = strtotime($event->end_date . ' ' .event_espresso_get_time($event->id, 'end_time'));
		//$eventArray['start'] = event_espresso_no_format_date($event->start_date . ' ' .date(event_espresso_get_time($event->id, 'start_time')), 'c');
		//$eventArray['end'] = event_espresso_no_format_date($event->end_date . ' ' .date(event_espresso_get_time($event->id, 'end_time')), 'c');
		
		//Abel
        $eventArray['start'] = date("c", strtotime($event->start_date . ' ' . event_espresso_get_time($event->id, 'start_time')));
		$eventArray['end'] = date("c", strtotime($event->end_date . ' ' . event_espresso_get_time($event->id, 'end_time')));

		$eventArray['allDay'] = FALSE;

        $eventArray['url'] = get_option('siteurl'). '/?page_id=' . $org_options['event_page_id'] . '&regevent_action=register&event_id=' . $event->id . '&name_of_event=' . stripslashes_deep($event->event_name);
		$eventArray['description'] = $event->event_desc;
		
		
		$events[] = $eventArray;
	}
	//Check te results of the code above
	//echo json_encode($events);
?>
<script type="text/javascript">

	$jaer = jQuery.noConflict();
	jQuery(document).ready(function($jaer) {
        
            $jaer('#calendar').fullCalendar({
                
				/** 
				* General Display
				* http://arshaw.com/fullcalendar/docs/text/ 
				**/
				
				//Defines the buttons and title at the top of the calendar.
				header: { //Settings: http://arshaw.com/fullcalendar/docs/display/header/
                    <?php echo stripslashes_deep($espresso_calendar['espresso_calendar_header']) ?>
                },
				
				/**
				* Theme Settings
				*
				* Once you enable theming with true, you still need to include the CSS file for the theme you want. 
				* For example, if you just downloaded a theme from the jQuery UI Themeroller, you need to put a <link> tag in your page's <head>.
				**/
				
				//Enables/disables use of jQuery UI theming.
				//theme: true, //Settings: http://arshaw.com/fullcalendar/docs/display/theme/
				
				//This option only applies to calendars that have jQuery UI theming enabled with the theme option.
				/*buttonIcons:{ //Settings: http://arshaw.com/fullcalendar/docs/display/buttonIcons/
					prev: 'circle-triangle-w',
					next: 'circle-triangle-e'
				},*/
		
				//The day that each week begins.
				//The value must be a number that represents the day of the week.
				//Sunday=0, Monday=1, Tuesday=2, etc.
				firstDay:<?php echo $espresso_calendar['espresso_calendar_firstday'];?>, //Settings: http://arshaw.com/fullcalendar/docs/display/firstDay/
				
				//Displays the calendar in right-to-left mode.
				isRTL: false,
				
				//Whether to include Saturday/Sunday columns in any of the calendar views.
				weekends: <?php echo $espresso_calendar['espresso_calendar_weekends'];?>,
				
				//Determines the number of weeks displayed in a month view. Also determines each week's height.
				weekMode:'fixed', //Settings: http://arshaw.com/fullcalendar/docs/display/weekMode/
				
				//Will make the entire calendar (including header) a pixel height.
				height:<?php echo $espresso_calendar['espresso_calendar_height'];?>, //Settings: http://arshaw.com/fullcalendar/docs/display/height/
				
				//Will make the calendar's content area a pixel height.
				//contentHeight: 600, //Settings: http://arshaw.com/fullcalendar/docs/display/contentHeight/

				//Determines the width-to-height aspect ratio of the calendar.
				//aspectRatio: 2, /?Settings: http://arshaw.com/fullcalendar/docs/display/aspectRatio/
				
				/** 
				* Agenda Options
				* http://arshaw.com/fullcalendar/docs/agenda/ 
				* Note: These ptions that apply to the agendaWeek and agendaDay views, and have beft out intentionally. 
				* Please refer to the URL above to add.manage your agenda views.
				**/

				/** 
				* Text/Time Customization Settings
				* http://arshaw.com/fullcalendar/docs/text/ 
				**/
				
				//Determines the time-text that will be displayed on each event.
				timeFormat:{ //Settings: http://arshaw.com/fullcalendar/docs/text/timeFormat/
					// for agendaWeek and agendaDay
					agenda: 'h:mm{ - h:mm}', // 5:00 - 6:30
				
					// for all other views
					'': 'h(:mm)t'            // 7p
				},
				
				//Determines the text that will be displayed on the calendar's column headings.
				columnFormat:{ //Settings: http://arshaw.com/fullcalendar/docs/text/columnFormat/
					<?php echo stripslashes_deep($espresso_calendar['espresso_calendar_columnFormat']);?>
					/*month: 'ddd',    // Mon
					week: 'ddd M/d', // Mon 9/7
					day: 'dddd M/d'  // Monday 9/7*/
				},
				
				//For date formatting options, please refer to: http://arshaw.com/fullcalendar/docs/utilities/formatDate/
				titleFormat:{ //Settings: http://arshaw.com/fullcalendar/docs/text/columnFormat/
					<?php echo stripslashes_deep($espresso_calendar['espresso_calendar_titleFormat']);?>
					/*month: 'MMMM yyyy',                             // September 2009
					week: "MMM d[ yyyy]{ '&#8212;'[ MMM] d yyyy}", // Sep 7 - 13 2009
					day: 'dddd, MMM d, yyyy'                  // Tuesday, Sep 8, 2009*/
				},
				
				//Text that will be displayed on buttons of the header.
				buttonText: { //Settings: http://arshaw.com/fullcalendar/docs/text/buttonText/
					<?php echo stripslashes_deep($espresso_calendar['espresso_calendar_buttonText']);?>
					/*prev:     '&nbsp;&#9668;&nbsp;',  // left triangle
					next:     '&nbsp;&#9658;&nbsp;',  // right triangle
					prevYear: '&nbsp;&lt;&lt;&nbsp;', // <<
					nextYear: '&nbsp;&gt;&gt;&nbsp;', // >>
					today:    'today',
					month:    'month',
					week:     'week',
					day:      'day'*/
				},
				
				//Full names of months.
				monthNames: [<?php echo stripslashes_deep($espresso_calendar['espresso_calendar_monthNames']);?>/*'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'*/],
				
				//Abbreviated names of months.
				monthNamesShort: [<?php echo stripslashes_deep($espresso_calendar['espresso_calendar_monthNamesShort']);?>/*'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'*/],
				
				//Full names of days-of-week.
				dayNames: [<?php echo stripslashes_deep($espresso_calendar['espresso_calendar_dayNames']);?>/*'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'*/],
				
				//Abbreviated names of days-of-week.
				dayNamesShort: [<?php echo stripslashes_deep($espresso_calendar['espresso_calendar_dayNamesShort']);?>/*'Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'*/],
				
				//Load the events into json srrsy
                events: <?php echo json_encode($events)?>,
                loading: function(bool) {
                    if (bool) $('#loading').show();
                    else $jaer('#loading').hide();
                }
                
            });
            
        });
    
</script>
    <div id='calendar'></div>
<?php

}
add_shortcode('ESPRESSO_CALENDAR', 'espresso_calendar');