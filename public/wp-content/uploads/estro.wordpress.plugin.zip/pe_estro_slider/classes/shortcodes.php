<?php
	
	add_shortcode("pe_estro_slider", "pe_estro_slider_handler");
	
	function pe_estro_slider_handler() {
		return "IT WORKS";
	}
	
?>