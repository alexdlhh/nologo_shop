=== WP-Backgrounds Lite ===
Contributors: InoPlugs
Donate link: http://inoplugs.com/donate
Tags: background, images, fullsize, post, page, wordpress, photos, photo, image
Requires at least: 3.0
Tested up to: 3.2 Beta 2
Stable tag: 1.4

Set fullscreen background images for all posts and pages. Compatible with all major browsers and very easy to install.

== Description ==

Set fullscreen background images for all posts and pages. Compatible with all major browsers and very easy to install.


*    Set fullscreen background images for posts and pages
*    Option to deactivate WP-Backgrounds Lite for certain pages and posts
*    Compatible with all major browsers like IE7, IE8, IE9, Firefox, Opera, Safari, Chrome and other modern browsers.
*    Can be used with nearly every theme (premium and free ones). For the most themes it works out of the box (i.e. for TwentyTen or boxed themes). A z-index and a background color option helps you to adjust the background layer and the color.
*    Vertical & horizontal image centering
*    Small fingerprint, only a few kb filesize
*    Easy installation, works out of the box
*    Option to adjust the background layer (z-index).


Live demo of WP-Backgrounds can be found here: <a href="http://demo.inoplugs.com">InoPlugs Demo Website</a>.

**The newest versions of this plugin can be found here: <a href="http://inoplugs.com/projects/wp-backgrounds-lite-version/">WP-Backgrounds Lite</a>. I'll try to keep the repository up to date but it's easier to host updates on my site. You'll get support there too (just leave a comment).**

**This plugin is the free lite version of WP-Backgrounds Premium which you can download here: <a href="http://inoplugs.com/projects/wp-backgrounds-plugin/">WP-Backgrounds Premium</a> - it offers a lot more features (flickr support, background slideshow, pattern, custom login panel, etc.).**



== Installation ==

How to install the plugin and get it working.

1. Upload `wp-backgrounds-lite` to the `/wp-content/plugins/` directory or use the WordPress plugin installer to install the plugin.
1. Activate the plugin through the 'Plugins' menu in WordPress
1. If required you can change the background layer (z-index), the background color and the credit option in inoplugs_background_plugin.php. Use the plugin editor to edit inoplugs_background_plugin.php. 

*    If the background image doesn't show up set $ino_zindex to an higher value (i.e. to -1, 0 or 1). Please keep in mind that fullwidth themes (themes without boxed layout) may require some css changes too.
*    You can chnge the body background color by setting a value for $ino_bg_color. It's empty by default, however you can enter any hexdezimal color value - like #000000.
*    The $ino_credit variable is set to true by default. You can set it to false to deactivate credits.

== Frequently Asked Questions ==

= The background doesn't show up =

First check if your theme has a boxed layout (like TwentyTen, the default WP theme) or if your theme has a fullwidth layout. If it has a fullwidth layout you may want to use semi-transparent background images for the content area so that the vistors can see the fullwidth background images.
You can use the z-index option in inoplugs_background_plugin.php to adjust the background layer. If the background image doesn't show up increase the value from -999 to -1. If that doesn't help try 0 or a positive value like 1.


== Changelog ==

= 1.0 =
* Initial release - some features coming, stay tuned.

= 1.1 =
* Fixed meta box bug on pages & posts.

= 1.2 =
* Improved meta box code for pages & posts.

= 1.3 =
* Fixed some php warning messages and decreased background image js/css file size. Fixed meta box caption typo. Compatible with WordPress 3.2 beta2.

= 1.4 =
* Fixed bug with rtl direction websites.

= 1.5 =
* Updated background image javascript function - solves various display errors with IE7+ and mobile devices.

== Upgrade Notice ==

Just upload the new plugin files and delete the old plugin files.
