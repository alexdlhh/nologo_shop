<?php
/**
 *  Plugin Name: WP-Backgrounds Lite
 *  Plugin URI: http://inoplugs.com
 *  Description: Set fullsize background images for Posts | Get the Premium version here: <a href="http://inoplugs.com/projects/wp-backgrounds-plugin/">Premium Version</a>
 *  Author: InoPlugs | Peter Schoenmann
 *  Version: 1.5.0.0
 *  Author URI: http://inoplugs.com
 */

	require_once('inoplugs_classes/inoplugs_background_display.php');

	//	create objects for handlers
	$inoplugs_wp_backgrounds_display = new inoplugs_background_display();

    # Add the options/actions to WordPress (if they doesn't exist)
	add_action('init', array (&$inoplugs_wp_backgrounds_display, 'handler_frontend_includes'));
	add_action('wp_head', array (&$inoplugs_wp_backgrounds_display, 'handler_add_background_slideshow'));
	
	
	//options
	$ino_zindex = '-999';
	$ino_bg_color = '';
	
	if (function_exists('register_uninstall_hook')){
		register_uninstall_hook(__FILE__, 'deinstall_inoplugs_wp_backgrounds');
	}
	
	function deinstall_inoplugs_wp_backgrounds() {
		delete_option('inoplugs_bg_options');
		
		$allposts = get_posts('numberposts=-1&post_type=post&post_status=any');

		foreach( $allposts as $postinfo) {
			delete_post_meta($postinfo->ID, 'ino_upload_image');
			delete_post_meta($postinfo->ID, 'ino_deactivate');
		}
	}

	//metabox
	$prefix = 'ino_';
			 
			$meta_box = array(
                            $meta_box_post = array(
											'id' => 'ino-meta-box_post',
											'title' => 'InoPlugs WP-Background Image',
											'page' => 'post',
											'context' => 'normal',
											'priority' => 'high',
											'fields' => array(
												array(
													'name' => 'Background Image',
													'desc' => 'Select an Image (internal or external url)',
													'id' => 'upload_image',
													'type' => 'text',
													'std' => ''
												),
														array(
													'name' => '',
													'desc' => 'Upload Image',
													'id' => 'upload_image_button',
													'type' => 'button',
													'std' => 'Select Background Image'
												)
										)
                            ),
                            
                            $meta_box_page = array(
											'id' => 'ino-meta-box_page',
											'title' => 'InoPlugs WP-Background Image',
											'page' => 'page',
											'context' => 'normal',
											'priority' => 'high',
											'fields' => array(
												array(
													'name' => 'Background Image',
													'desc' => 'Select a Image (internal or external url)',
													'id' => 'upload_image',
													'type' => 'text',
													'std' => ''
												),
														array(
													'name' => '',
													'desc' => 'Upload Image',
													'id' => 'upload_image_button',
													'type' => 'button',
													'std' => 'Select Background Image'
													),
													
													array(
													'name' => '',
													'desc' => 'Apply Link to Background - Use following url',
													'id' => 'url',
													'type' => 'text',
													'std' => ''
													)
												)	
										)
							);
			
			 
			add_action('admin_menu', 'ino_add_box');
			 
			// Add meta box
			function ino_add_box() {
                            global $meta_box;
                            foreach($meta_box as $box){
				add_meta_box($box['id'], $box['title'], 'ino_show_box', $box['page'], $box['context'], $box['priority']);                 
                            }
                        }
			 
		 
			// Callback function to show fields in meta box
			function ino_show_box() {
				global $meta_box, $post;
			 
				// Use nonce for verification
				echo '<input type="hidden" name="ino_meta_box_nonce" value="', wp_create_nonce(basename(__FILE__)), '" />';
			 
				echo '<table class="form-table">';
			 
				foreach ($meta_box[0]['fields'] as $field) {
					// get current post meta data
					$meta = get_post_meta($post->ID, $field['id'], true);
			 
					echo '<tr>',
							'<th style="width:20%"><label for="', $field['id'], '">', $field['name'], '</label></th>',
							'<td>';
					switch ($field['type']) {
			 
			 
			 
			 
			//If Text		
						case 'text':
							echo '<input type="text" name="', $field['id'], '" id="', $field['id'], '" value="', $meta ? $meta : $field['std'], '" size="30" style="width:97%" />',
								'<br />', $field['desc'];
							break;
			 
			 
			//If Text Area			
						case 'textarea':
							echo '<textarea name="', $field['id'], '" id="', $field['id'], '" cols="60" rows="4" style="width:97%">', $meta ? $meta : $field['std'], '</textarea>',
								'<br />', $field['desc'];
							break;
			 
			 
			//If Button	
			 
							case 'button':
							echo '<input type="button" name="', $field['id'], '" id="', $field['id'], '"value="', $meta ? $meta : $field['std'], '" />';
							break;
					}
					echo 	'<td>',
						'</tr>';
				}
			 
				echo '</table>';
			}
			 
			add_action('save_post', 'ino_save_data');
			 
			 
			// Save data from meta box
			function ino_save_data($post_id) {
				global $meta_box;
			 
				// verify nonce
				if (!wp_verify_nonce($_POST['ino_meta_box_nonce'], basename(__FILE__))) {
					return $post_id;
				}
			 
				// check autosave
				if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
					return $post_id;
				}
			 
				// check permissions
				if ('page' == $_POST['post_type']) {
					if (!current_user_can('edit_page', $post_id)) {
						return $post_id;
					}
				} elseif (!current_user_can('edit_post', $post_id)) {
					return $post_id;
				}
			 
				foreach ($meta_box[0]['fields'] as $field) {
					$old = get_post_meta($post_id, $field['id'], true);
					$new = $_POST[$field['id']];
			 
					if ($new && $new != $old) {
						update_post_meta($post_id, $field['id'], $new);
					} elseif ('' == $new && $old) {
						delete_post_meta($post_id, $field['id'], $old);
					}
				}
			}
			 
			function ino_admin_scripts() {
			wp_enqueue_script('media-upload');
			wp_enqueue_script('thickbox');
			wp_register_script('my-upload', WP_PLUGIN_URL.'/wp-backgrounds-lite/includes/script.js', array('jquery','media-upload','thickbox'));
			wp_enqueue_script('my-upload');
			}
			function ino_admin_styles() {
			wp_enqueue_style('thickbox');
			}
			add_action('admin_print_scripts', 'ino_admin_scripts');
			add_action('admin_print_styles', 'ino_admin_styles');
                        
?>
