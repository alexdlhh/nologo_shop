<?php 
//This is a premium feature, please upgrade
function event_espresso_discount_config_mnu(){
	echo espresso_premium_feature(); 
}
//The files for this feature are stored in the "includes/admin-files/email-manager" directory
?>