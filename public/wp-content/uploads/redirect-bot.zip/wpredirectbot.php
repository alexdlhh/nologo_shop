<?
/*
Plugin Name: WP Redirect Bot
Plugin URI: http://www.paulmihaipavel.com/wp-redirect-bot/
Description: WP Redirect Bot helps you in redirecting user to an external link. No technical knowledge required, no inconvenient shorteners... just enter the Web address and you're done.
Version: 1.0
Author: Paul Mihai Pavel
Author URI: http://www.paulmihaipavel.com
*/
?>
<?
function wpm_showoptions(){
	global $post;	
	echo '<input type="hidden" name="enableredirect_noncename" id="enableredirect_noncename" value="' . wp_create_nonce( plugin_basename(__FILE__) ) . '" />';
	
	echo '<input type="hidden" name="redirectcount_noncename" id="redirectcount_noncename" value="' . wp_create_nonce( plugin_basename(__FILE__) ) . '" />'; 	?>
		
	<?php
			$enableredirect = get_post_meta($post->ID,'enableredirect',true);
			$redirectcount = get_post_meta($post->ID,'redirectcount',true);
	?>
		<p>
		<label for="enableredirect"><strong>Redirect to this URL?</strong></label>
		<input type="text" id="enableredirect" name="enableredirect" maxlength="255" size="60" value="<?php echo $enableredirect;?>">
		</p>
		
		<p>
		<label for="enableredirect"><strong>Users Redirected So Far...</strong></label>
		<input type="text" readonly id="redirectcount" name="redirectcount" maxlength="255" size="5" value="<?php echo $redirectcount;?>">
		</p>
		
	<?php
}
?>
<?
function wpm_display() {
  echo '<div class="dbx-b-ox-wrapper">' . "\n";
  echo '<fieldset id="myplugin_fieldsetid" class="dbx-box">' . "\n";
  echo '<div class="dbx-h-andle-wrapper"><h3 class="dbx-handle">' . 
        __( 'Redirect to URL', 'wordpress-post-tabs' ) . "</h3></div>";
  echo '<div class="dbx-c-ontent-wrapper"><div class="dbx-content">';
  wpm_showoptions();
  echo "</div></div></fieldset></div>\n";
}

function wpm_addoptionbox() {
	if( function_exists( 'add_meta_box' ) ) {
		add_meta_box( 'wpm_box1', __( 'Redirect to URL' ), 'wpm_showoptions', 'post', 'side','high' );
		add_meta_box( 'wpm_box2', __( 'Redirect to URL' ), 'wpm_showoptions', 'page', 'advanced' );
	} else {
		add_action('dbx_post_advanced', 'myplugin_old_custom_box' );
		add_action('dbx_page_advanced', 'myplugin_old_custom_box' );
	}
}
add_action('admin_menu', 'wpm_addoptionbox');
add_action('template_redirect','do_redirect', 1, 2);
?>
<?

function do_redirect(){
		global $post,$wp_query,$ppr_active,$wpdb;
		
		$post_id = $post->ID;

		$enableredirect = get_post_meta($post->ID,'enableredirect',true);
		
		if (!empty($enableredirect)) {
			
			//update the hit counter
			$redirectcount = get_post_meta($post->ID,'redirectcount',true);
			
			if($redirectcount != '')
			{
				$redirectcount = $redirectcount + 1;
				update_post_meta($post_id, 'redirectcount', $redirectcount);
			}
			else
			{
				$redirectcount = 1;
				update_post_meta($post_id, 'redirectcount', $redirectcount);
			}
				
				
			header ('HTTP/1.1 301 Moved Permanently');
			header ('Location: ' . $enableredirect);
			exit();
			}
		}

function wpm_save()
{
	global $post;
	$post_id = $post->ID;
	if ( !wp_verify_nonce( $_POST['enableredirect_noncename'], plugin_basename(__FILE__) )) 
	{
		return $post_id;
	}
	if ( defined('DOING_AUTOSAVE') && DOING_AUTOSAVE ) 
		return $post_id;

	if ( 'page' == $_POST['post_type'] ) 
	{
		if ( !current_user_can( 'edit_page', $post_id ) )
		return $post_id;
	} 
	else 
	{
		if ( !current_user_can( 'edit_post', $post_id ) )
		return $post_id;
	}

	$data =  $_POST['enableredirect'];
	update_post_meta($post_id, 'enableredirect', $data);
	
	
	$data1 =  $_POST['redirectcount'];
	update_post_meta($post_id, 'redirectcount', $data1);

	
	return $data;
}
add_action('save_post', 'wpm_save');
?>
<?
function wpm_init() {
	if(is_singular()) {
		global $post,$wpm;
		$enableredirect = get_post_meta($post->ID, 'enableredirect', true);
		$redirectcount = get_post_meta($post->ID, 'redirectcount', true);
		
		if( (is_page() and ((!empty($enablewpts) and $enablewpts=='1') or  $wpm['pages'] != '0'  ) ) 
			or (is_single() and ((!empty($enablewpts) and $enablewpts=='1') or $wpm['posts'] != '0'  ) ) ) 
		{
			global $wpm_count,$wpm_tab_count,$wpm_content;
			$wpm_count=0;
			$wpm_tab_count=0;
			$wpm_content=array();
		}
	}
}
add_action('wp','wpm_init');
?>
<?
function wpRedirect_install()
{
	//do nothing
}
register_activation_hook(__FILE__,'wpRedirect_install');
?>