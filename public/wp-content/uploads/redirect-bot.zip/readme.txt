WP Redirect Bot Installation

You can install the plugin the same way you install any other
plugins, either using the built-in uploader or using FTP.

If you do not know how to install a WordPress Plugin please visit

http://codex.wordpress.org/Managing_Plugins

After that, go to the plugins page and activate the plugin.

Once you have activated the plugin you can define the redirector 
URL when creating a post or a page as displayed to the included 
image

IMPORTANT NOTE:

If you are using the WP Redirect Bot to redirect a post, you should use
the included WP Hide Post to hide that post at least on the front page,
otherwise all the visitors of your blog will be redirected to the specified
URL...

Enjoy!

Paul Mihai Pavel
http://paulmihaipavel.com